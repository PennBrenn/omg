#!/usr/bin/env bash
# =============================================================================
# scan_library.sh — audit an MP3 library for the exact issues that break
# PennP3Player: non-48kHz files (forces a live I2S reinstall — audible glitch,
# and if the file is ALSO corrupt, can poison the output driver's rate state
# for every track after it) and files ffprobe flags as corrupt/unreadable
# (a likely source of "never reports EOF" / runs to 99:99 forever).
#
# Usage:
#   chmod +x scan_library.sh
#   ./scan_library.sh /path/to/sdcard/mp3s > report.txt
#
# Requires ffprobe (part of ffmpeg). Read-only — makes no changes to any file.
# =============================================================================

set -uo pipefail

DIR="${1:-.}"
BAD_RATE=0
CORRUPT=0
TOTAL=0

echo "Scanning: $DIR"
echo "-----------------------------------------------------------------------"

while IFS= read -r -d '' f; do
    TOTAL=$((TOTAL + 1))
    name=$(basename "$f")

    # ffprobe: pull sample rate, bitrate, duration, and codec in one call.
    # If ffprobe itself errors out or returns nothing, the file is likely
    # corrupt/unreadable — exactly the kind of file that can decode forever
    # without a clean EOF on-device.
    info=$(ffprobe -v error -select_streams a:0 \
        -show_entries stream=sample_rate,bit_rate,codec_name \
        -show_entries format=duration \
        -of default=noprint_wrappers=1 "$f" 2>&1)

    if [ -z "$info" ] || echo "$info" | grep -qi "error\|invalid"; then
        echo "[CORRUPT?]  $name"
        echo "            $info" | head -3
        CORRUPT=$((CORRUPT + 1))
        continue
    fi

    rate=$(echo "$info" | grep -m1 '^sample_rate=' | cut -d= -f2)

    if [ -n "$rate" ] && [ "$rate" != "48000" ]; then
        echo "[RATE=$rate]  $name"
        BAD_RATE=$((BAD_RATE + 1))
    fi
done < <(find "$DIR" -maxdepth 1 -iname "*.mp3" -print0)

echo "-----------------------------------------------------------------------"
echo "Scanned $TOTAL files: $BAD_RATE non-48kHz, $CORRUPT possibly corrupt/unreadable"
echo ""
echo "To fix a non-48kHz or corrupt file, re-encode it cleanly:"
echo '  ffmpeg -i "in.mp3" -ar 48000 -c:a libmp3lame -q:a 2 "in_fixed.mp3"'
echo "(re-encoding through ffmpeg also repairs most corrupt/malformed frames"
echo " as a side effect, since it fully re-decodes and re-writes the audio)"