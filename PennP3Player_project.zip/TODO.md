# PennP3Player TODO

This file tracks the requested playback fixes and a small utility menu for the
sleep timer, music folder selection, and library reindexing. Keep the player
usable with the existing encoder, toggle, display, and SD-card workflow while
making these changes.


### 1. Add a utility menu with sleep timer, music folder selection, and reindex

**Priority:** Medium  
**Relevant code:** `src/main.cpp` owns the regular loop; `src/ui.cpp` owns
playback/menu state and input dispatch; `src/state.h` defines audio commands.

Replace the current settings menu with a small utility menu containing **Sleep
timer**, **Music folder**, **Reindex all**, and **Back**. The sleep timer lets
playback continue for a chosen interval and then pauses the player. Use
elapsed-time arithmetic based on `millis()` so the timer works across the
fast-polling loop and does not depend on blocking delays. The timer must not
interfere with the audio task or hold up input polling.

**Implementation plan:**

- Keep a short encoder-button press as play/pause. A one-second hold opens the
  utility menu; use encoder rotation to navigate and a short press to select.
  A longer press backs out or returns to playback according to the existing
  menu interaction conventions. Remove the 15-second hold gesture for
  reindexing; reindexing is selected from the utility menu.
- The **Sleep timer** submenu has exactly these choices: **Off**, **5 min**,
  **30 min**, and **1 hour**. Selecting a duration starts or replaces the
  countdown; **Off** cancels it. Show a concise indication of the active timer
  or remaining time on the player screen, and show the active choice when the
  submenu is opened again.
- Selecting a timer choice applies it immediately and returns to the utility
  menu or now-playing screen. Do not require a second confirmation step.
- At expiration, pause playback rather than stopping or powering off the
  player. Keep the timer running across track changes; if playback is already
  paused at expiration, clear the timer without resuming playback.
- Represent timer state explicitly: inactive/active, deadline or start time
  plus duration, and the selected interval if it needs to be displayed.
- Start or update the deadline from a nonblocking UI action.
- Check expiry from the regular Core 1 loop/UI tick using wrap-safe unsigned
  elapsed-time comparisons. On expiry, send the existing `PAUSE` audio command
  once, clear the active timer, and update the display to match actual playback
  state.
- Define behavior for track changes and already-paused playback. The timer
  continues counting across track changes; it should not send repeated pause
  commands after expiring. Selecting **Off** clears the deadline.
- Keep the timer volatile across reboot unless persistence is explicitly
  required; avoid adding flash writes for a short-lived timer.
- **Music folder** lists only the immediate subfolders of the configured music
  root. It does not browse nested folders. Selecting a folder makes its MP3s
  the active playlist, starts playback at that folder's first track, and keeps
  next/previous within that folder. Persist the selected folder path so startup
  restores the same playlist.
- Default the configured music root to the SD card root, so folders such as
  `/Main`, `/CU`, and `/MC` appear in the picker. If the card is instead
  organized as `/Music/<playlist>/`, change the configured music root to
  `/Music`; keep the index file in the SD root (for example,
  `/music_index.bin`) in either layout. The picker should list only folders
  directly under the configured music root.
- **Reindex all** scans MP3s in every immediate subfolder of the configured
  music root, rebuilds the persistent index, and refreshes the active playlist.
  Store full SD paths in the index so playback can open files from any listed
  folder. Ensure the index filename is excluded from music-folder discovery.
- Keep library scanning and index I/O safe while the audio task may be reading
  from the SD card. Show progress and completion feedback, and restore a valid
  track in the selected folder after reindexing.

**Acceptance checks:**

- A short press still toggles playback; a one-second hold opens the utility
  menu, and no 15-second hold action is required.
- Sleep timer offers exactly Off, 5 min, 30 min, and 1 hour; selecting a
  duration starts or replaces the countdown, and Off cancels it.
- Music folder lists only immediate subfolders of the configured music root;
  selecting one switches playback to that folder, including next/previous.
- Reindex all discovers every eligible folder and its MP3s, stores full paths,
  and leaves the active folder and selected track valid.
- Starting a timer does not block audio or input handling.
- The timer can be canceled with Off or replaced with another preset.
- At expiry, playback pauses once, including when the player has changed
  tracks since the timer was started.
- A timer does not unexpectedly resume playback, survive reboot, or trigger
  repeatedly after it expires.

### 2. Remove settings-only controls while keeping the utility menu

**Priority:** Medium  
**Current code:** `MenuItem`, menu input handling, and menu drawing are in
`src/ui.h` and `src/ui.cpp`; audio-setting commands and configuration state are
defined across `src/state.h`, `src/main.cpp`, and `src/audio.cpp`.

Remove the settings menu's audio and diagnostic controls, but retain a menu for
the three requested player utilities. Audit each current menu entry:

- EQ preset selection and its submenu.
- Balance adjustment.
- Battery detail entry (keep the normal battery indicator if it remains part
  of the now-playing screen).
- Rebuild Index remains available as **Reindex all** in the utility menu.
- Retain the menu navigation and menu-only input context for the utility menu.

**Implementation plan:**

- Inventory settings-only state, drawing code, input mappings, audio commands,
  persistence, and labels before deleting code. Keep volume, play/pause,
  next/previous track, boot recovery, and the now-playing display working.
- Retain the menu screen and navigation path, but replace its settings entries
  with Sleep timer, Music folder, Reindex all, and Back.
- Remove setting controls from the UI and input router. Remove EQ/balance
  audio commands and state only if no other code path still uses them; avoid
  leaving unreachable menu state or dead command handlers behind.
- Keep the existing one-second hold as the menu-entry gesture. Remove the
  special 15-second hold handling and route reindexing through the menu.
- Preserve the normal battery status display and playback behavior. Keep SD
  access safe relative to active playback during reindexing, and restore a
  valid selected track after the index is rebuilt.
- Review the resulting screen and button behavior as one coherent minimal
  player flow, including boot, no-card/no-tracks errors, playback, pause, and
  track changes, menu navigation, folder switching, and timer expiration.

**Acceptance checks:**

- EQ, balance, and battery-detail settings are removed, with no orphaned
  setting labels, input routes, or audio command handlers.
- Volume, play/pause, next/previous, and the now-playing screen still work.
- The one-second hold opens the utility menu; reindexing is available from
  that menu and has no long-hold gesture.
- The menu contains Sleep timer, Music folder, Reindex all, and Back, with the
  configured music-root behavior reflected consistently in scanning and UI.

