#!/usr/bin/env bash
# =============================================================================
# fix_library_rates.sh — batch re-encode every non-48kHz MP3 in a folder to
# 48kHz, matching what PennP3Player expects. Companion to scan_library.sh.
#
# Safety: nothing is deleted. Originals are moved into a "originals_backup/"
# subfolder alongside the source files, and the fixed file takes the
# ORIGINAL filename/location — so your persistent index on the SD card
# (/music_index.bin, keyed by filename+path) doesn't need touching or
# rebuilding, and boot behavior is unaffected.
#
# Usage:
#   chmod +x fix_library_rates.sh
#   ./fix_library_rates.sh /path/to/sdcard/mp3s
#
# Requires ffmpeg. Dry-run first if you want to double check:
#   ./fix_library_rates.sh /path/to/sdcard/mp3s --dry-run
# =============================================================================

set -uo pipefail

DIR="${1:-.}"
DRY_RUN="${2:-}"
BACKUP_DIR="$DIR/originals_backup"
FIXED=0
SKIPPED=0
FAILED=0

mkdir -p "$BACKUP_DIR"

echo "Scanning + fixing: $DIR"
[ "$DRY_RUN" = "--dry-run" ] && echo "(DRY RUN — no files will be changed)"
echo "-----------------------------------------------------------------------"

while IFS= read -r -d '' f; do
    name=$(basename "$f")

    rate=$(ffprobe -v error -select_streams a:0 \
        -show_entries stream=sample_rate \
        -of default=noprint_wrappers=1:nokey=1 "$f" 2>/dev/null)

    if [ -z "$rate" ]; then
        echo "[SKIP - unreadable]  $name"
        SKIPPED=$((SKIPPED + 1))
        continue
    fi

    if [ "$rate" = "48000" ]; then
        continue  # already correct, nothing to do
    fi

    echo "[FIX $rate -> 48000]  $name"

    if [ "$DRY_RUN" = "--dry-run" ]; then
        FIXED=$((FIXED + 1))
        continue
    fi

    tmpfile="${f}.tmp_48k.mp3"

    if ffmpeg -y -loglevel error -i "$f" -ar 48000 -c:a libmp3lame -q:a 2 "$tmpfile"; then
        mv "$f" "$BACKUP_DIR/$name"
        mv "$tmpfile" "$f"
        FIXED=$((FIXED + 1))
    else
        echo "         ffmpeg failed on this file — leaving original untouched"
        rm -f "$tmpfile"
        FAILED=$((FAILED + 1))
    fi
done < <(find "$DIR" -maxdepth 1 -iname "*.mp3" -print0)

echo "-----------------------------------------------------------------------"
echo "Fixed: $FIXED   Skipped (unreadable): $SKIPPED   Failed: $FAILED"
echo "Originals backed up to: $BACKUP_DIR"
echo ""
echo "Filenames are unchanged, so your existing /music_index.bin on the SD"
echo "card is still valid — no rescan/rebuild needed on next boot."