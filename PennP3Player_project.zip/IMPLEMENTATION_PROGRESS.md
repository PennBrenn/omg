# Implementation progress

## Checkpoint 1 — Baseline review

- Read `TODO.md` and mapped the requested utility menu, sleep timer, folder playlist, and reindex behavior to the existing UI, input, storage, audio, and main-loop modules.
- Confirmed the current firmware sources and many generated/dependency files were already modified before this implementation. Those changes are the baseline and are being preserved.
- Current gaps: the menu contains EQ/balance/battery/rebuild entries; storage only indexes MP3s at the SD root; reindex blocks the UI; no timer or selected-folder persistence exists.

## Checkpoint 2 — Main implementation pass

- Replaced settings entries and submenus with Utilities, Sleep timer, Music folder, Reindex all, and Back.
- Added the four required timer presets, immediate apply/cancel behavior, selected-preset marker, player-screen remaining-time indicator, and wrap-safe deadline expiry that queues one pause only when playback is active.
- Changed storage indexing to scan immediate SD-root folders, preserve full MP3 paths, persist the active folder, and expose a folder-filtered playlist to the existing playback controls.
- Added an SD mutex shared by folder/index operations and audio file reads; index format version is now 5 and the index is explicitly replaced on write.
- Removed the retired EQ/balance menu command and playback state routes while retaining the audio DSP's fixed flat EQ processing.
- Reindex displays progress updates and completion feedback, and restores the selected folder's playlist.

## Checkpoint 3 — Build and final review

- Added `MUSIC_ROOT` (default `/`) so a card using `/Music/<playlist>/` can switch the configured root without moving `/music_index.bin`.
- Kept the Off preset visibly selected when the timer is inactive and guarded next/previous/track advance for an empty selected playlist.
- Verified the firmware with `./.venv/bin/pio run`; the ESP32-S3 build completed successfully (RAM 9.0%, flash 39.6%).
- Reviewed input mappings and menu labels: short press remains play/pause in playback, the one-second hold opens Utilities, and no 15-second reindex route remains.
- Hardware interaction with the encoder, SD card, and e-paper display has not been exercised in this environment.
