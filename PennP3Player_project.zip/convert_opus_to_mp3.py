#!/usr/bin/env python3
"""Convert all .opus files in the Casualties: Unknown OST 'cu' folder to .mp3."""
import glob
import os
import subprocess

import imageio_ffmpeg as iio

CU = "/home/penn/.config/Claude/scratch-workspaces/c5ca3b78-b27f-4b9e-962a-0d886862d94e/756829ff-7da7-4730-a134-411302ace863/scratch-2026-11-15-987483/music/cu"

FFMPEG = iio.get_ffmpeg_exe()
print(f"Using ffmpeg: {FFMPEG}\n")

opus_files = sorted(glob.glob(os.path.join(CU, "*.opus")))
print(f"Found {len(opus_files)} opus files\n")

converted = skipped = failed = 0
for src in opus_files:
    dst = os.path.splitext(src)[0] + ".mp3"
    if os.path.exists(dst):
        print(f"SKIP (exists): {os.path.basename(dst)}")
        skipped += 1
        continue
    r = subprocess.run(
        [FFMPEG, "-y", "-i", src, "-vn", "-c:a", "libmp3lame", "-q:a", "2", dst],
        capture_output=True, text=True,
    )
    if r.returncode == 0 and os.path.exists(dst):
        print(f"OK: {os.path.basename(dst)} ({os.path.getsize(dst)//1024} KiB)")
        converted += 1
    else:
        print(f"FAIL: {os.path.basename(src)}")
        if r.stderr:
            print("  " + r.stderr.strip().splitlines()[-1])
        failed += 1

print(f"\n=== DONE: converted={converted}, skipped={skipped}, failed={failed}, total={len(opus_files)} ===")
