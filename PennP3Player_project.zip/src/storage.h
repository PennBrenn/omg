#pragma once
// =============================================================================
// storage.h — Full library index and selected-folder playlist from SD
// =============================================================================
// Design: At boot, load a persistent index of full paths from immediate
//   playlist folders below MUSIC_ROOT, then expose the selected folder as
//   the active playlist.
//
//   PSRAM budget: 500 tracks × 160 bytes = 80 KB. 2 MB PSRAM available.
//   If PSRAM is absent, fall back to a fixed 500-entry heap array.
// =============================================================================

#include <Arduino.h>
#include "config.h"

// ---------------------------------------------------------------------------
// Index entry — one per track, fixed size
// ---------------------------------------------------------------------------
// PATH_LEN: FAT32 filenames can be up to 255 chars + leading '/'.
//           288 gives full coverage with margin to spare.
// TITLE_LEN: Bumped from 128 — some ID3 TIT2 titles run well past that
//            (long remix/feat. titles), and were being silently truncated.
// ARTIST_LEN: Bumped from 64 for the same reason (long "feat." credits).
//
// Memory budget: 500 tracks × 680 bytes ≈ 332 KB in PSRAM (2 MB available).
// Changing these values changes sizeof(IndexEntry), which is caught by the
// entrySize check in storageLoadIndex() AND by the INDEX_FORMAT_VERSION bump
// below — either one alone is enough to force a one-time automatic rebuild
// of /music_index.bin on next boot.
// ---------------------------------------------------------------------------
#define PATH_LEN   288
#define TITLE_LEN  256
#define ARTIST_LEN 128

struct IndexEntry {
    char path[PATH_LEN];          // 288 bytes
    char title[TITLE_LEN];        // 256 bytes
    char artist[ARTIST_LEN];      // 128 bytes
    uint32_t durationMs;          //   4 bytes
    uint8_t _pad[4];              //   4 bytes — padding, harmless under packed layout
} __attribute__((packed));

// Total: 288 + 256 + 128 + 4 + 4 = 680 bytes
#define INDEX_ENTRY_SIZE sizeof(IndexEntry)

// Bump this whenever IndexEntry's layout/size changes. storageLoadIndex()
// rejects (and storageBuildList() regenerates) any on-SD index whose header
// reports a different version, independent of the entrySize check.
//
// Version 4: ID3 metadata parsing removed.  title and artist are now derived
//   exclusively from filename at scan time.  Stale v3 indices are rejected
//   and automatically rebuilt on next boot.
#define INDEX_FORMAT_VERSION 5

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

// Init SD card and mount filesystem. Returns true on success.
bool storageInit();

// Returns true if SD is mounted.
bool sdMounted();

// Rebuild the persistent full-library index and active playlist.
// Returns the number of tracks in the selected playlist.
int storageBuildList();
int storageReindexAll(void (*progress)(int indexedTracks) = nullptr);
int storageFolderCount();
bool storageGetFolderName(int index, char* name, size_t nameLen);
bool storageSelectFolder(const char* folderName);
const char* storageSelectedFolder();

// Try loading track list from persistent binary index file on SD.
// Returns true if valid index was successfully loaded.
bool storageLoadIndex();

// Get the total number of tracks in the list.
int getTrackCount();

// Get the IndexEntry for track at given index (0-based). Returns false if out of range.
bool getIndexEntry(int index, IndexEntry& out);

// Convenience: copy track path into buf. Returns false if out of range.
bool getTrackPath(int index, char* buf, size_t bufLen);

// ---------------------------------------------------------------------------
// NVS Persistence — save/restore last-played track, position, and volume
// ---------------------------------------------------------------------------
void saveLastPlayed(int trackIndex, uint32_t positionMs);
void loadLastPlayed(int& trackIndex, uint32_t& positionMs);
void saveVolume(int vol);
int  loadVolume();
