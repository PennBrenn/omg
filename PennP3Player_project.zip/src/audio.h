#pragma once
// =============================================================================
// audio.h — Core 0 audio task: SD read → MP3 decode → EQ → I2S output
// =============================================================================
// This module runs entirely on Core 0 and must never block on display I/O.
//
// Library dependency: ESP8266Audio (available via Arduino Library Manager)
//   - AudioFileSourceSD (file source)
//   - AudioDecoderMP3 (helix-based decoder — good quality, ~40 KB RAM)
//   - AudioOutputI2S (I2S DMA output)
//
// ⚠ FLAG (PCM5102 I2S config): The PCM5102A is a "hardware default" DAC:
//   FMT pin tied to GND → I2S standard (Philips) format
//   FLT pin tied to GND → Normal latency filter
//   DEMP pin tied to GND → De-emphasis disabled
//   XSMT pin pulled HIGH → Soft-mute disabled (tie to 3.3V in hardware)
//   No register or SPI configuration needed — confirmed against PCM5102A
//   datasheet Table 2 (Hardware Control Mode).
//   I2S format: standard (not LSB-justified), 16-bit or 32-bit frames both
//   work; we use 16-bit here since the helix decoder outputs 16-bit PCM.
//
// ⚠ FLAG (volume): PCM5102A has no software volume register in hardware
//   mode.  Volume is implemented as digital scaling of the PCM samples
//   before they are written to I2S.  This introduces quantisation noise at
//   low volumes but is the only option without putting a separate analog
//   attenuator in the signal path.

#include <Arduino.h>
#include "state.h"
#include "storage.h"

// ---------------------------------------------------------------------------
// Launch the audio task (pinned to Core 0).
// Call once from setup() after queues are created.
// ---------------------------------------------------------------------------
void audioTaskStart();

// ---------------------------------------------------------------------------
// Returns true once the audio task has completed initialization and the I2S
// driver is ready to accept commands.  Core 1 polls this before sending the
// initial PLAY_TRACK command — replaces non-deterministic delay() waits.
// ---------------------------------------------------------------------------
bool audioIsReady();

// ---------------------------------------------------------------------------
// Internal — the FreeRTOS task function (do not call directly)
// ---------------------------------------------------------------------------
void audioTaskFn(void* pvParams);
