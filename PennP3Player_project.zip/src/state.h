#pragma once
// =============================================================================
// state.h — Shared data types, IPC message definitions, global queue handles
// =============================================================================
// All inter-core communication goes through FreeRTOS queues declared here.
// Never access shared state directly across cores without going through these
// queues — that is the rule this whole architecture is built on.

#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>
#include "config.h"

// ---------------------------------------------------------------------------
// Top-level player states
// ---------------------------------------------------------------------------
enum class PlayerState : uint8_t {
    BOOT,
    NOW_PLAYING,
    MENU,
    ERROR_NO_SD,
    ERROR_NO_TRACKS,
    REBUILDING_INDEX,   // actively scanning SD and writing /index.bin
};

// ---------------------------------------------------------------------------
// Playback status (read by Core 1 UI, written by Core 0 audio)
// ---------------------------------------------------------------------------
enum class PlaybackStatus : uint8_t {
    STOPPED,
    PLAYING,
    PAUSED,
};

// Internal DSP preset type; the player UI no longer exposes preset controls.
enum class EQPreset : uint8_t { FLAT = 0, BASS_BOOST, TREBLE_BOOST, VOCAL_BOOST, _COUNT };

// ---------------------------------------------------------------------------
// Shuffle / repeat modes
// ---------------------------------------------------------------------------
enum class RepeatMode : uint8_t {
    NONE = 0,
    REPEAT_ONE,
    REPEAT_ALL,
    SHUFFLE,
    _COUNT
};

// ---------------------------------------------------------------------------
// Commands sent from Core 1 → Core 0 (audio task)
// ---------------------------------------------------------------------------
enum class AudioCmdType : uint8_t {
    PLAY_TRACK,       // play track at index .trackIndex
    PAUSE,
    RESUME,
    SET_VOLUME,       // .value = 0-100
    NEXT_TRACK,
    PREV_TRACK,
    SEEK_PERCENT,     // .value = 0-100 seek position (future use)
    STOP,
};

struct AudioCmd {
    AudioCmdType type;
    int32_t      trackIndex;  // used by PLAY_TRACK
    int32_t      value;       // multipurpose integer param
};

// ---------------------------------------------------------------------------
// Events sent from Core 0 → Core 1 (UI task)
// These report what ACTUALLY happened in the audio task, so the UI stays synced.
// ---------------------------------------------------------------------------
enum class AudioEventType : uint8_t {
    TRACK_STARTED,    // .trackIndex = new track, .positionMs = 0
    TRACK_ENDED,
    PLAYBACK_PAUSED,
    PLAYBACK_RESUMED,
    POSITION_UPDATE,  // .positionMs updated
    VOLUME_CHANGED,   // .value = new volume 0-100
    ERROR_FILE,       // file open/read error
};

struct AudioEvent {
    AudioEventType type;
    int32_t        trackIndex;
    uint32_t       positionMs;
    uint32_t       durationMs;
    int32_t        value;
};

// ---------------------------------------------------------------------------
// Volatile playback state (written by Core 0, read by Core 1 under mutex)
// ---------------------------------------------------------------------------
struct PlaybackState {
    volatile PlaybackStatus status;
    volatile int32_t        currentTrackIndex;
    volatile uint32_t       positionMs;
    volatile uint32_t       durationMs;
    volatile int32_t        volume;      // 0–100
};

// ---------------------------------------------------------------------------
// Global queues (extern declarations; defined in pennp3.ino)
// ---------------------------------------------------------------------------
extern QueueHandle_t gAudioCmdQueue;   // Core 1 → Core 0
extern QueueHandle_t gAudioEvtQueue;   // Core 0 → Core 1
extern SemaphoreHandle_t gPlaybackMutex;
extern SemaphoreHandle_t gSdMutex; // serializes SD access between UI/storage and audio task

// ---------------------------------------------------------------------------
// Shared playback state (protected by gPlaybackMutex)
// ---------------------------------------------------------------------------
extern PlaybackState gPlayback;

// ---------------------------------------------------------------------------
// Player configuration (owned by Core 1, never touched by Core 0)
// ---------------------------------------------------------------------------
struct PlayerConfig {
    RepeatMode repeatMode;
    bool       displayBrightnessAvailable;  // e-paper almost certainly false
};

extern PlayerConfig gConfig;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
inline bool sendAudioCmd(AudioCmdType t, int32_t idx = 0, int32_t val = 0) {
    AudioCmd cmd = {t, idx, val};
    return xQueueSend(gAudioCmdQueue, &cmd, pdMS_TO_TICKS(10)) == pdTRUE;
}

inline bool recvAudioCmd(AudioCmd& out, uint32_t waitMs = 0) {
    return xQueueReceive(gAudioCmdQueue, &out, pdMS_TO_TICKS(waitMs)) == pdTRUE;
}

inline void postAudioEvent(AudioEventType t, int32_t idx = 0,
                            uint32_t pos = 0, uint32_t dur = 0, int32_t val = 0) {
    AudioEvent evt = {t, idx, pos, dur, val};
    xQueueSend(gAudioEvtQueue, &evt, pdMS_TO_TICKS(5));
}

inline bool recvAudioEvent(AudioEvent& out, uint32_t waitMs = 0) {
    return xQueueReceive(gAudioEvtQueue, &out, pdMS_TO_TICKS(waitMs)) == pdTRUE;
}
