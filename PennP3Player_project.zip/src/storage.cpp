// =============================================================================
// storage.cpp — In-memory track list in PSRAM, scanned from SD at boot
// =============================================================================
// Design: scan immediate playlist folders below MUSIC_ROOT, sort full paths,
//   and store all tracks in a PSRAM-allocated array. 500 × 680 bytes ≈ 332 KB
//   (2 MB available).  If no PSRAM, uses heap (still fine for 500 tracks).
//
//   Persistent binary index on SD (/music_index.bin) avoids a full ID3
//   rescan on every boot — see storageLoadIndex()/storageReindexAll().
// =============================================================================

#include "storage.h"
#include <SD.h>
#include <SPI.h>
#include <Preferences.h>
#include <Arduino.h>
#include "config.h"
#include "state.h"

// ---------------------------------------------------------------------------
// Module state
// ---------------------------------------------------------------------------
#define MAX_TRACKS 650

static bool        s_mounted   = false;
static int         s_trackCount = 0;
static IndexEntry* s_tracks    = nullptr;  // all indexed tracks
static int s_activeIndices[MAX_TRACKS];
static int s_activeCount = 0;
static char s_selectedFolder[PATH_LEN] = "/";
static Preferences s_prefs;

static const char* INDEX_FILE_PATH = "/music_index.bin";

struct SdAccessGuard {
    bool locked;
    explicit SdAccessGuard(uint32_t timeoutMs = 5000)
        : locked(gSdMutex && xSemaphoreTake(gSdMutex, pdMS_TO_TICKS(timeoutMs)) == pdTRUE) {}
    ~SdAccessGuard() { if (locked) xSemaphoreGive(gSdMutex); }
};

struct IndexHeader {
    char     magic[4];     // "P3IX"
    uint32_t version;      // INDEX_FORMAT_VERSION (see storage.h)
    uint32_t entrySize;    // sizeof(IndexEntry) — currently 680
    uint32_t trackCount;   // number of tracks
};

static void allocateTracks() {
    if (s_tracks) return;
    if (psramFound()) {
        s_tracks = (IndexEntry*)ps_malloc(MAX_TRACKS * sizeof(IndexEntry));
    } else {
        s_tracks = (IndexEntry*)malloc(MAX_TRACKS * sizeof(IndexEntry));
    }
}

// ---------------------------------------------------------------------------
// SD init — cold-start handshake, mount
// ---------------------------------------------------------------------------
bool storageInit() {
    // Cold-start handshake per SD Physical Layer Spec §7.1.1
    pinMode(PIN_SD_MISO, INPUT_PULLUP);
    pinMode(PIN_SD_CS, OUTPUT);
    digitalWrite(PIN_SD_CS, HIGH);
    delay(1);

    // 80 idle SCK cycles with CS high
    SPI.beginTransaction(SPISettings(100000, MSBFIRST, SPI_MODE0));
    for (int i = 0; i < 10; i++) {
        SPI.transfer(0xFF);
    }
    SPI.endTransaction();

    Serial.println("[storage] SD.begin(CS=4, SPI, 20MHz)...");
    if (!SD.begin(PIN_SD_CS, SPI, 20000000)) {
        Serial.println("[storage] SD.begin failed");
        s_mounted = false;
        return false;
    }
    if (SD.cardType() == CARD_NONE) {
        Serial.println("[storage] No card inserted");
        s_mounted = false;
        return false;
    }
    Serial.printf("[storage] SD mounted, %llu MB\n", SD.cardSize() / (1024ULL * 1024ULL));
    s_mounted = true;
    return true;
}

bool sdMounted() { return s_mounted; }

// ---------------------------------------------------------------------------
// Comparison function for sorting by filename (qsort)
// ---------------------------------------------------------------------------
static int cmpEntry(const void* a, const void* b) {
    return strcmp(((const IndexEntry*)a)->path, ((const IndexEntry*)b)->path);
}

// ---------------------------------------------------------------------------
// Filename parsing — NO ID3 METADATA INVOLVED
// ===========================================================================
// Strategy (Option A — Preferred):
//   Filename is the sole source of truth for display titles.  No ID3 parsing
//   is performed at scan time.  This guarantees deterministic, stable display
//   names regardless of tag corruption, encoding issues, or missing tags.
//
//   Parsing rules (safe + deterministic):
//   1. Strip the .mp3 extension from the base filename.
//   2. Normalize: replace '_' with space (common in digital music filenames).
//      The original filesystem character is always recoverable from the path.
//   3. Detect "Artist - Title" pattern (space-hyphen-space separator).
//      - If present: split, trim both sides → artist / title.
//      - If absent:  use full cleaned name as title, artist = empty.
//   4. No other transformations — no bracket stripping, no decode attempts.
//      This keeps the mapping lossless: the base filename is always trivially
//      recoverable from (artist, title) if needed.
// ===========================================================================

// Clean a single token: trim leading/trailing whitespace in-place.
// Works on a mutable C-string, returns pointer to the start.
static char* trimWhitespace(char* s) {
    if (!s) return s;
    // Trim leading
    char* start = s;
    while (*start == ' ' || *start == '\t') start++;
    // Trim trailing
    char* end = start + strlen(start);
    while (end > start && (end[-1] == ' ' || end[-1] == '\t')) end--;
    *end = '\0';
    return start;
}

// Normalize a filename-derived string: replace underscore with space.
// Operates in-place on the mutable buffer.
static void normalizeDisplayName(char* buf, size_t len) {
    if (!buf || len == 0) return;
    for (size_t i = 0; i < len && buf[i] != '\0'; i++) {
        if (buf[i] == '_') buf[i] = ' ';
        // Brackets like [ or ( are left intact — they're human-readable
        // and commonly used for [explicit] or (feat. ...) markers.
    }
}

// Parse filename into title and artist fields.
// ARTIST - TITLE separator is " - " (space-hyphen-space).
// Everything is derived from the base filename alone — NO I/O, NO ID3.
static void parseFilename(const char* baseFilename, char* title, size_t titleLen,
                           char* artist, size_t artistLen) {
    title[0]  = '\0';
    artist[0] = '\0';

    // Copy base filename into a mutable buffer for normalization
    char buf[TITLE_LEN];
    strncpy(buf, baseFilename, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';

    // Normalize: underscores → spaces (in-place)
    normalizeDisplayName(buf, sizeof(buf));

    // Look for " - " separator (artist - title pattern)
    const char* sep = strstr(buf, " - ");
    if (sep) {
        // Split: left side = artist, right side = title
        size_t artistLen_ = sep - buf;
        if (artistLen_ > 0) {
            buf[artistLen_] = '\0';  // terminate at separator
            // Trim and copy to artist
            char* trimmedArtist = trimWhitespace(buf);
            strncpy(artist, trimmedArtist, artistLen - 1);
            artist[artistLen - 1] = '\0';

            // Trim and copy to title
            const char* titleStart = sep + 3;  // skip " - "
            // Skip leading spaces
            while (*titleStart == ' ') titleStart++;
            strncpy(title, titleStart, titleLen - 1);
            title[titleLen - 1] = '\0';
            // Trim trailing space from title
            size_t tl = strlen(title);
            while (tl > 0 && title[tl - 1] == ' ') title[--tl] = '\0';

            return;
        }
    }

    // No " - " separator — use full base as title, artist stays empty
    const char* trimmed = trimWhitespace(buf);
    strncpy(title, trimmed, titleLen - 1);
    title[titleLen - 1] = '\0';

    // Also trim trailing space from title
    size_t tl = strlen(title);
    while (tl > 0 && title[tl - 1] == ' ') title[--tl] = '\0';
}

// ---------------------------------------------------------------------------
// Derive base filename from path (strip directory, strip .mp3)
// ---------------------------------------------------------------------------
static void baseFilenameFromPath(const char* path, char* out, size_t len) {
    const char* slash = strrchr(path, '/');
    const char* base  = slash ? slash + 1 : path;

    char extBuf[PATH_LEN];
    strncpy(extBuf, base, sizeof(extBuf) - 1);
    extBuf[sizeof(extBuf) - 1] = '\0';

    // Strip .mp3 extension
    size_t n = strlen(extBuf);
    if (n > 4 && strcasecmp(extBuf + n - 4, ".mp3") == 0) {
        extBuf[n - 4] = '\0';
    }

    strncpy(out, extBuf, len - 1);
    out[len - 1] = '\0';
}

// ---------------------------------------------------------------------------
// Build in-memory track list: scan root for .mp3, derive title from filename
// ---------------------------------------------------------------------------
static bool isMp3Name(const char* name) {
    size_t n = strlen(name);
    return n > 4 && strcasecmp(name + n - 4, ".mp3") == 0;
}

static void makeMusicChildPath(const char* name, char* out, size_t outLen) {
    if (!name || !out || outLen == 0) return;
    if (name[0] == '/') { snprintf(out, outLen, "%s", name); return; }
    const char* root = MUSIC_ROOT;
    while (*root == '/') ++root;
    size_t rootLen = strlen(root);
    if (rootLen && strncmp(name, root, rootLen) == 0 && name[rootLen] == '/') {
        snprintf(out, outLen, "/%s", name);
        return;
    }
    if (strcmp(MUSIC_ROOT, "/") == 0) snprintf(out, outLen, "/%s", name);
    else snprintf(out, outLen, "%s/%s", MUSIC_ROOT, name);
}

static void rebuildActivePlaylist() {
    s_activeCount = 0;
    for (int i = 0; i < s_trackCount; ++i) {
        const char* slash = strrchr(s_tracks[i].path, '/');
        char parent[PATH_LEN] = "/";
        if (slash && slash != s_tracks[i].path) {
            size_t n = slash - s_tracks[i].path;
            if (n >= sizeof(parent)) n = sizeof(parent) - 1;
            memcpy(parent, s_tracks[i].path, n);
            parent[n] = '\0';
        }
        if (strcmp(parent, s_selectedFolder) == 0)
            s_activeIndices[s_activeCount++] = i;
    }
}

static void chooseAvailableFolderIfEmpty() {
    if (s_activeCount > 0 || s_trackCount == 0) return;
    const char* path = s_tracks[0].path;
    const char* slash = strrchr(path, '/');
    if (!slash || slash == path) return;
    size_t n = slash - path;
    if (n >= sizeof(s_selectedFolder)) n = sizeof(s_selectedFolder) - 1;
    memcpy(s_selectedFolder, path, n);
    s_selectedFolder[n] = '\0';
    s_prefs.begin("pennp3", false);
    s_prefs.putString("folder", s_selectedFolder);
    s_prefs.end();
    rebuildActivePlaylist();
}

int storageReindexAll(void (*progress)(int indexedTracks)) {
    if (!s_mounted) return 0;
    SdAccessGuard sdGuard;
    if (!sdGuard.locked) return 0;
    allocateTracks();
    if (!s_tracks) return 0;

    File root = SD.open(MUSIC_ROOT);
    if (!root || !root.isDirectory()) { root.close(); return 0; }
    int count = 0;
    File folder;
    while ((folder = root.openNextFile()) && count < MAX_TRACKS) {
        if (!folder.isDirectory()) { folder.close(); continue; }
        const char* rawName = folder.name();
        char folderPath[PATH_LEN];
        makeMusicChildPath(rawName, folderPath, sizeof(folderPath));
        folder.close();

        File dir = SD.open(folderPath);
        if (!dir || !dir.isDirectory()) { dir.close(); continue; }
        File item;
        while ((item = dir.openNextFile()) && count < MAX_TRACKS) {
            if (!item.isDirectory() && isMp3Name(item.name())) {
                IndexEntry e = {};
                const char* name = item.name();
                if (name[0] == '/') snprintf(e.path, sizeof(e.path), "%s", name);
                else {
                    const char* rootRel = MUSIC_ROOT;
                    while (*rootRel == '/') ++rootRel;
                    const char* folderBase = strrchr(folderPath, '/');
                    folderBase = folderBase ? folderBase + 1 : folderPath;
                    size_t rootLen = strlen(rootRel);
                    size_t folderLen = strlen(folderBase);
                    if (rootLen && strncmp(name, rootRel, rootLen) == 0 && name[rootLen] == '/')
                        snprintf(e.path, sizeof(e.path), "/%s", name);
                    else if (strncmp(name, folderBase, folderLen) == 0 && name[folderLen] == '/')
                        snprintf(e.path, sizeof(e.path), "%s/%s", folderPath, name + folderLen + 1);
                    else snprintf(e.path, sizeof(e.path), "%s/%s", folderPath, name);
                }
                char base[TITLE_LEN];
                baseFilenameFromPath(e.path, base, sizeof(base));
                parseFilename(base, e.title, sizeof(e.title), e.artist, sizeof(e.artist));
                uint32_t bytes = item.size();
                e.durationMs = bytes ? (uint32_t)(((uint64_t)bytes * 8000ULL) / 128000ULL) : 0;
                s_tracks[count++] = e;
                if (progress && (count == 1 || count % 10 == 0)) progress(count);
            }
            item.close();
        }
        dir.close();
    }
    root.close();

    if (count > 1) qsort(s_tracks, count, sizeof(IndexEntry), cmpEntry);
    s_trackCount = count;

    SD.remove(INDEX_FILE_PATH);
    File f = SD.open(INDEX_FILE_PATH, FILE_WRITE);
    if (f) {
        IndexHeader hdr;
        memcpy(hdr.magic, "P3IX", 4);
        hdr.version = INDEX_FORMAT_VERSION;
        hdr.entrySize = sizeof(IndexEntry);
        hdr.trackCount = count;
        bool ok = f.write((uint8_t*)&hdr, sizeof(hdr)) == sizeof(hdr);
        size_t bytes = count * sizeof(IndexEntry);
        if (ok && bytes) ok = f.write((uint8_t*)s_tracks, bytes) == bytes;
        f.close();
        Serial.printf("[storage] Rebuilt index: %d tracks, write=%s\n", count, ok ? "ok" : "failed");
    } else {
        Serial.println("[storage] Failed to open index file for writing");
    }
    rebuildActivePlaylist();
    chooseAvailableFolderIfEmpty();
    return s_activeCount;
}

int storageBuildList() { return storageReindexAll(); }

int storageFolderCount() {
    if (!s_mounted) return 0;
    SdAccessGuard sdGuard;
    if (!sdGuard.locked) return 0;
    int count = 0;
    File root = SD.open(MUSIC_ROOT);
    if (!root || !root.isDirectory()) { root.close(); return 0; }
    File entry;
    while ((entry = root.openNextFile())) {
        if (entry.isDirectory()) ++count;
        entry.close();
    }
    root.close();
    return count;
}

bool storageGetFolderName(int index, char* name, size_t nameLen) {
    if (!s_mounted || index < 0 || !name || nameLen == 0) return false;
    SdAccessGuard sdGuard;
    if (!sdGuard.locked) return false;
    File root = SD.open(MUSIC_ROOT);
    if (!root || !root.isDirectory()) { root.close(); return false; }
    int found = 0;
    File entry;
    bool result = false;
    while ((entry = root.openNextFile())) {
        if (entry.isDirectory()) {
            if (found++ == index) {
                const char* n = entry.name();
                const char* slash = strrchr(n, '/');
                n = slash ? slash + 1 : n;
                makeMusicChildPath(n, name, nameLen);
                result = true;
                entry.close();
                break;
            }
        }
        entry.close();
    }
    root.close();
    return result;
}

bool storageSelectFolder(const char* folderName) {
    if (!folderName || folderName[0] != '/') return false;
    SdAccessGuard sdGuard;
    if (!sdGuard.locked) return false;
    strncpy(s_selectedFolder, folderName, sizeof(s_selectedFolder) - 1);
    s_selectedFolder[sizeof(s_selectedFolder) - 1] = '\0';
    s_prefs.begin("pennp3", false);
    s_prefs.putString("folder", s_selectedFolder);
    s_prefs.end();
    rebuildActivePlaylist();
    return true;
}

const char* storageSelectedFolder() { return s_selectedFolder; }

// ---------------------------------------------------------------------------
// Try loading track list from persistent binary index file on SD.
// ---------------------------------------------------------------------------
bool storageLoadIndex() {
    if (!s_mounted) return false;
    SdAccessGuard sdGuard;
    if (!sdGuard.locked) return false;

    File f = SD.open(INDEX_FILE_PATH, FILE_READ);
    if (!f) {
        Serial.println("[storage] Index file not found");
        return false;
    }

    IndexHeader hdr;
    if (f.read((uint8_t*)&hdr, sizeof(IndexHeader)) != sizeof(IndexHeader)) {
        Serial.println("[storage] Failed to read index header");
        f.close();
        return false;
    }

    if (strncmp(hdr.magic, "P3IX", 4) != 0) {
        Serial.println("[storage] Index header magic mismatch");
        f.close();
        return false;
    }

    if (hdr.version != INDEX_FORMAT_VERSION) {
        Serial.printf("[storage] Index version mismatch: %u vs %u (will rebuild)\n", hdr.version, INDEX_FORMAT_VERSION);
        f.close();
        return false;
    }

    if (hdr.entrySize != sizeof(IndexEntry)) {
        Serial.printf("[storage] Index entry size mismatch: %u vs %u\n", hdr.entrySize, sizeof(IndexEntry));
        f.close();
        return false;
    }

    if (hdr.trackCount > MAX_TRACKS) {
        Serial.printf("[storage] Index track count exceeds MAX_TRACKS: %u vs %d\n", hdr.trackCount, MAX_TRACKS);
        f.close();
        return false;
    }

    // Verify file size matches expected size
    size_t expectedSize = sizeof(IndexHeader) + hdr.trackCount * sizeof(IndexEntry);
    if (f.size() != expectedSize) {
        Serial.printf("[storage] Index file size mismatch: %llu vs %u\n", f.size(), expectedSize);
        f.close();
        return false;
    }

    allocateTracks();
    if (!s_tracks) {
        Serial.println("[storage] Failed to allocate track list for index");
        f.close();
        return false;
    }

    size_t bytesToRead = hdr.trackCount * sizeof(IndexEntry);
    if (f.read((uint8_t*)s_tracks, bytesToRead) != bytesToRead) {
        Serial.println("[storage] Failed to read index entries");
        f.close();
        return false;
    }

    f.close();
    s_trackCount = hdr.trackCount;
    s_prefs.begin("pennp3", true);
    String folder = s_prefs.getString("folder", "/");
    s_prefs.end();
    strncpy(s_selectedFolder, folder.c_str(), sizeof(s_selectedFolder) - 1);
    s_selectedFolder[sizeof(s_selectedFolder) - 1] = '\0';
    rebuildActivePlaylist();
    chooseAvailableFolderIfEmpty();
    Serial.printf("[storage] Successfully loaded %d tracks (%d active) from binary index\n", s_trackCount, s_activeCount);
    return true;
}

// ---------------------------------------------------------------------------
// Accessors
// ---------------------------------------------------------------------------
int getTrackCount() { return s_activeCount; }

bool getIndexEntry(int index, IndexEntry& out) {
    if (index < 0 || index >= s_activeCount || !s_tracks) return false;
    out = s_tracks[s_activeIndices[index]];
    return true;
}

bool getTrackPath(int index, char* buf, size_t bufLen) {
    IndexEntry e;
    if (!getIndexEntry(index, e)) return false;
    strncpy(buf, e.path, bufLen - 1);
    buf[bufLen - 1] = '\0';
    return true;
}

// ---------------------------------------------------------------------------
// NVS persistence
// ---------------------------------------------------------------------------
void saveLastPlayed(int trackIndex, uint32_t positionMs) {
    s_prefs.begin("pennp3", false);
    s_prefs.putInt("track", trackIndex);
    s_prefs.putUInt("pos", positionMs);
    s_prefs.end();
}

void loadLastPlayed(int& trackIndex, uint32_t& positionMs) {
    s_prefs.begin("pennp3", true);
    trackIndex  = s_prefs.getInt("track", 0);
    positionMs  = s_prefs.getUInt("pos", 0);
    s_prefs.end();
}

void saveVolume(int vol) {
    s_prefs.begin("pennp3", false);
    s_prefs.putInt("vol", vol);
    s_prefs.end();
}

int loadVolume() {
    s_prefs.begin("pennp3", true);
    int vol = s_prefs.getInt("vol", DEFAULT_VOLUME);
    s_prefs.end();
    return constrain(vol, 0, 100);
}


