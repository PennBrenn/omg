#pragma once
// =============================================================================
// battery.h — LiPo voltage sensing via ADC resistor divider
// =============================================================================
#include <Arduino.h>

// Call once from setup() on Core 1.
void batteryInit();

// Sample ADC and update internal state (call periodically, e.g. every 20s).
void batteryUpdate();

// Returns battery voltage in volts (e.g. 3.87).
float batteryGetVolts();

// Returns rough charge percentage (0–100), piecewise LiPo approximation.
int batteryGetPercent();