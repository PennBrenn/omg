#pragma once
// =============================================================================
// display.h — E-paper display wrapper (GxEPD2, SSD1675, 2.13" 250×122)
// =============================================================================
// Hardware confirmed: Waveshare 2.13" e-Paper HAT V4, 250×122, SSD1675.
//   GxEPD2 class: GxEPD2_213_BN (SSD1675 / UC8151D / IL0373 compatible).
//   BUSY polarity: active-HIGH (SSD1675 default).
//   SPI mode 0 (CPOL=0, CPHA=0).
//   Supports partial refresh — use displayPartialRefresh() for fast updates,
//   but force a full refresh every PARTIAL_REFRESH_GHOST_LIMIT partials to
//   prevent ghosting buildup (see config.h).
//
// Library: GxEPD2 by ZinggJM (Arduino Library Manager)
//   Also requires: Adafruit GFX Library

#include <Arduino.h>
#include <GxEPD2_BW.h>
#include <Fonts/FreeSans9pt7b.h>
#include <Fonts/FreeSans12pt7b.h>

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

// Initialise display hardware and perform boot full-refresh.
void displayInit();

// Full refresh — clears to white then redraws.  Causes the characteristic
// e-paper flash.  Use on track change, entering/exiting menu, boot splash.
void displayFullRefresh();

// Partial refresh — updates the full display buffer.  Fast, no flash.
// Internally tracks count and auto-triggers full refresh at ghost limit.
// ⚠ Throttled internally: a partial refresh will fire at most once every
//    REFRESH_THROTTLE_MS milliseconds.  If called again before the throttle
//    interval expires, the refresh is deferred until the throttle lifts.
//    This prevents the e-paper controller from getting confused by rapid
//    back-to-back partial updates (which produce visible artifacts).
void displayPartialRefresh();

// Force a full refresh on the next displayPartialRefresh() call regardless
// of the ghost counter (e.g. after a track change).
void displayRequestFullRefresh();

// Access the underlying GxEPD2 display object for drawing.
// Use display().setFont(), display().print(), display().drawBitmap(), etc.
// Always call display().firstPage() / display().nextPage() or use the
// helper functions below.
GxEPD2_BW<GxEPD2_213_BN, GxEPD2_213_BN::HEIGHT>& display();

// ---------------------------------------------------------------------------
// Drawing helpers (operate on the display's internal buffer)
// ---------------------------------------------------------------------------

// Clear the entire display buffer to white.
void displayClear();

// Draw a string at (x, y) with the given font.
// y is the baseline.
void displayText(int16_t x, int16_t y, const char* str,
                 const GFXfont* font = nullptr, uint16_t color = GxEPD_BLACK);

// Draw a filled rectangle.
void displayFillRect(int16_t x, int16_t y, int16_t w, int16_t h,
                     uint16_t color = GxEPD_BLACK);

// Draw a rectangle outline.
void displayRect(int16_t x, int16_t y, int16_t w, int16_t h,
                 uint16_t color = GxEPD_BLACK);

// Draw a 1-bit bitmap (width × height pixels, row-major, MSB first).
void displayBitmap(int16_t x, int16_t y, int16_t w, int16_t h,
                   const uint8_t* bitmap);

// Measure text width in pixels with the given font.
// ⚠ Saves and restores the previously-set font so callers don't lose their
//    font state.  Callers should still setFont() explicitly before drawing.
int16_t displayTextWidth(const char* str, const GFXfont* font = nullptr);

// Truncate str to fit within maxWidth pixels, appending "..." if needed.
// Writes result into outBuf (size outBufLen).
void displayTruncate(const char* str, int16_t maxWidth,
                     const GFXfont* font,
                     char* outBuf, size_t outBufLen);

// Word-wrap str across up to 2 lines within maxWidth pixels.
//   - If str fits in one line: line1 = str, line2 = "".
//   - If not: split at the last word boundary (space) that fits in maxWidth,
//     put the first part in line1, the remainder in line2.
//   - If line2 is still too wide, ellipsis-truncate it via displayTruncate.
//   - line1/line2 are always null-terminated, length lineLen.
void displayWrapText(const char* str, int16_t maxWidth, const GFXfont* font,
                     char line1[], char line2[], size_t lineLen);