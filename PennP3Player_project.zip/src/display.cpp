// =============================================================================
// display.cpp — GxEPD2 wrapper for SSD1675 2.13" 250×122 e-paper
// =============================================================================
// Driver: GxEPD2_213_BN — SSD1675 / UC8151D / IL0373 (Waveshare 2.13" V4).
//   Pinout (confirmed on actual hardware):
//     DIN=43  CLK=44  CS=13  DC=12  RST=11  BUSY=10
//   Uses a dedicated SPIClass on pins 43/44 — separate from the SD card's
//   SPI bus (SD is on 1/2/3/4 with the default SPIClass).
// =============================================================================

#include "display.h"
#include "config.h"
#include <SPI.h>

// ---------------------------------------------------------------------------
// Display object — SSD1675 controller (Waveshare 2.13" V4)
// GxEPD2_213_BN: 250×122, SPI mode 0, BUSY active-HIGH, partial refresh.
// ---------------------------------------------------------------------------
static GxEPD2_213_BN s_epd(PIN_EPD_CS, PIN_EPD_DC, PIN_EPD_RST, PIN_EPD_BUSY);
static GxEPD2_BW<GxEPD2_213_BN, GxEPD2_213_BN::HEIGHT> s_display(s_epd);

// Dedicated SPIClass for e-paper — separate from SD card's default SPI bus
static SPIClass s_epdSPI(HSPI);

// ---------------------------------------------------------------------------
// Ghost counter + throttle
// ---------------------------------------------------------------------------
static int      s_partialCount      = 0;
static bool     s_forceFullRefresh  = false;
static uint32_t s_lastPartialMs     = 0;
#define REFRESH_THROTTLE_MS 250  // minimum ms between partial refreshes

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
void displayInit() {
    // Start dedicated SPI bus for e-paper
    s_epdSPI.begin(PIN_EPD_CLK, -1, PIN_EPD_DIN, PIN_EPD_CS);
    // Tell GxEPD2 to use our dedicated SPI bus (not the default)
    s_display.epd2.selectSPI(s_epdSPI, SPISettings(4000000, MSBFIRST, SPI_MODE0));
    // Init display (reset + handshake + boot full refresh)
    s_display.init(115200, true, 2, false);
    s_display.setRotation(3);  // rotation 1 = 90° CW = correct orientation but upside down → +2 = 270° CW = 180° flip
    s_display.setTextColor(GxEPD_BLACK);
    s_display.setTextWrap(false);
    Serial.println("[display] Initialized on EPD SPI (43/44)");
}

void displayFullRefresh() {
    s_display.setFullWindow();
    s_display.display(false);
    s_partialCount     = 0;
    s_forceFullRefresh = false;
}

void displayPartialRefresh() {
    if (s_forceFullRefresh || s_partialCount >= PARTIAL_REFRESH_GHOST_LIMIT) {
        displayFullRefresh();
        return;
    }

    // Throttle: don't send updates faster than REFRESH_THROTTLE_MS
    uint32_t now = millis();
    if (now - s_lastPartialMs < REFRESH_THROTTLE_MS) {
        return;  // skip — too soon since last refresh
    }
    s_lastPartialMs = now;

    // Use full-screen partial window — this is the reliable mode for SSD1675.
    // Small region windows cause visible artifacts on this controller.
    s_display.setPartialWindow(0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
    s_display.display(true);
    s_partialCount++;
}

void displayRequestFullRefresh() {
    s_forceFullRefresh = true;
}

GxEPD2_BW<GxEPD2_213_BN, GxEPD2_213_BN::HEIGHT>& display() {
    return s_display;
}

void displayClear() {
    s_display.fillScreen(GxEPD_WHITE);
}

void displayText(int16_t x, int16_t y, const char* str,
                 const GFXfont* font, uint16_t color) {
    s_display.setFont(font);
    s_display.setTextColor(color);
    s_display.setCursor(x, y);
    s_display.print(str);
}

void displayFillRect(int16_t x, int16_t y, int16_t w, int16_t h,
                     uint16_t color) {
    s_display.fillRect(x, y, w, h, color);
}

void displayRect(int16_t x, int16_t y, int16_t w, int16_t h,
                 uint16_t color) {
    s_display.drawRect(x, y, w, h, color);
}

void displayBitmap(int16_t x, int16_t y, int16_t w, int16_t h,
                   const uint8_t* bitmap) {
    s_display.drawBitmap(x, y, bitmap, w, h, GxEPD_BLACK, GxEPD_WHITE);
}

static const GFXfont* s_activeFont = nullptr;

int16_t displayTextWidth(const char* str, const GFXfont* font) {
    // ⚠ getTextBounds() with cursor at (0,0) can return negative x1 for fonts
    //    with negative left-bearing characters (common in proportional fonts).
    //    The actual span from cursor origin to the rightmost pixel is x1 + w.
    //    We use cursor at (0,0) and compute total = x1 + w.
    const GFXfont* prevFont = s_activeFont;
    s_display.setFont(font);
    s_activeFont = font;
    int16_t x1, y1;
    uint16_t w, h;
    s_display.getTextBounds(str, 0, 0, &x1, &y1, &w, &h);
    // Total pixel span from cursor (0) to rightmost pixel:
    //   leftmost = x1, rightmost = x1 + w - 1
    //   total = (x1 + w - 1) - 0 + 1 = x1 + w
    int16_t actual = (int16_t)((int16_t)w + x1);
    s_display.setFont(prevFont);
    s_activeFont = prevFont;
    return actual;
}

void displayTruncate(const char* str, int16_t maxWidth,
                     const GFXfont* font,
                     char* outBuf, size_t outBufLen) {
    if (outBufLen == 0) return;
    strncpy(outBuf, str, outBufLen - 1);
    outBuf[outBufLen - 1] = '\0';
    if (displayTextWidth(outBuf, font) <= maxWidth) return;
    const char* ellipsis = "...";
    int16_t ellW = displayTextWidth(ellipsis, font);
    int16_t budget = maxWidth - ellW;
    if (budget <= 0) {
        strncpy(outBuf, ellipsis, outBufLen - 1);
        outBuf[outBufLen - 1] = '\0';
        return;
    }
    size_t len = strlen(outBuf);
    while (len > 0) {
        outBuf[len] = '\0';
        if (displayTextWidth(outBuf, font) <= budget) break;
        len--;
    }
    strncat(outBuf, ellipsis, outBufLen - strlen(outBuf) - 1);
}

void displayWrapText(const char* str, int16_t maxWidth, const GFXfont* font,
                     char line1[], char line2[], size_t lineLen) {
    line1[0] = '\0';
    line2[0] = '\0';

    if (!str || !*str) return;

    // If it fits in one line, done
    if (displayTextWidth(str, font) <= maxWidth) {
        strncpy(line1, str, lineLen - 1);
        line1[lineLen - 1] = '\0';
        return;
    }

    // Find split point at last space before maxWidth
    const char* split = nullptr;
    const char* lastSpace = nullptr;

    // Find the last space in the entire string
    for (const char* p = str; *p; p++) {
        if (*p == ' ') lastSpace = p;
    }

    // lastSpace is now the last space in the whole string.
    // Walk backward from lastSpace to find where it fits.
    // Start from the last space; if the substring from str to that space fits
    // in maxWidth, split there.  Otherwise try earlier spaces.
    split = lastSpace;
    while (split) {
        // Build substring from str to split (exclusive)
        size_t line1Len = (size_t)(split - str);
        char tmp[256];
        if (line1Len >= sizeof(tmp)) { line1Len = sizeof(tmp) - 1; }
        strncpy(tmp, str, line1Len);
        tmp[line1Len] = '\0';

        if (displayTextWidth(tmp, font) <= maxWidth) {
            break;  // This split works
        }
        // This split doesn't fit — find earlier space
        // Walk backward from split-1 to find previous space
        const char* prev = split - 1;
        while (prev >= str && *prev != ' ') prev--;
        if (prev < str) { split = nullptr; break; }  // No earlier space
        split = prev;
    }

    if (!split) {
        // No space-based split works — force-split at character boundary
        // Find the longest prefix that fits
        size_t prefixLen = strlen(str);
        while (prefixLen > 0) {
            char tmp[256];
            size_t n = (prefixLen < sizeof(tmp)) ? prefixLen : (sizeof(tmp) - 1);
            strncpy(tmp, str, n);
            tmp[n] = '\0';
            if (displayTextWidth(tmp, font) <= maxWidth) break;
            prefixLen--;
        }
        split = str + prefixLen;
    }

    // line1 = substring from str up to split (exclusive)
    size_t line1Len = (size_t)(split - str);
    if (line1Len >= lineLen) line1Len = lineLen - 1;
    strncpy(line1, str, line1Len);
    line1[line1Len] = '\0';

    // Skip leading spaces on line2
    const char* line2start = split;
    while (*line2start == ' ') line2start++;

    // line2 = remainder, truncated if needed
    if (displayTextWidth(line2start, font) <= maxWidth) {
        strncpy(line2, line2start, lineLen - 1);
        line2[lineLen - 1] = '\0';
    } else {
        displayTruncate(line2start, maxWidth, font, line2, lineLen);
    }
}
