#pragma once
// =============================================================================
// input.h — Input system: raw hardware events, context-aware normalization
// =============================================================================
// Architecture:
//   Raw hardware layer → inputPoll() → Raw InputEvent
//   Normalizer layer   → inputNormalize() → Normalized InputEvent
//   Context source     → inputSetContext() / inputGetContext() (simple enum)
//
// The context is a PLAIN enum set by the UI layer when state transitions occur.
// The input system NEVER queries UI state — it only reads its own context var.
// This decouples input routing from UI state machine.
//
// Run: inputPoll() every loop tick → returns raw event (never blocked)
//      inputNormalize(raw)         → context-aware normalized event
//
// Rules:
//   MENU context:    ENC_CW/CCW → NAV_DOWN/UP (optional navigation)
//                    INPUT_UP/DOWN → NAV_UP/DOWN
//                    ENC_SHORT_PRESS → NAV_ENTER
//                    ENC_LONG_PRESS → NAV_BACK
//                    No event may affect volume, track, or playback state.
//
//   PLAYBACK context: ENC_CW/CCW → VOLUME_UP/DOWN (dispatched in main.cpp fast path)
//                     INPUT_UP/DOWN → TRACK_PREV/NEXT
//                     ENC_SHORT_PRESS → PLAY_PAUSE
//                     ENC_LONG_PRESS → SHOW_MENU
//                     No event may trigger menu navigation.

#include <Arduino.h>
#include "state.h"

// ---------------------------------------------------------------------------
// Input context — authoritative routing source, NEVER queried from UI state
// ---------------------------------------------------------------------------
enum class InputContext : uint8_t {
    PLAYBACK,  // NOW_PLAYING
    MENU,      // MENU
    OTHER,     // BOOT, ERROR, REBUILDING
};

// ---------------------------------------------------------------------------
// Input event types
// ---------------------------------------------------------------------------
enum class InputEvent : uint8_t {
    // --- Raw hardware events (output of inputPoll()) ---
    NONE = 0,
    ENC_CW,            // encoder turned clockwise one detent
    ENC_CCW,           // encoder turned counter-clockwise one detent
    ENC_SHORT_PRESS,   // encoder button: short press released
    ENC_LONG_PRESS,    // encoder button: held >LONG_PRESS_MS

    // --- Generic directional events (replaces toggle-specific semantics) ---
    // These are context-independent: INPUT_DOWN always means "next item
    // in current context direction".  Mapping to specific actions is done
    // by inputNormalize().
    INPUT_UP,          // direction up / prev (from toggle switch "prev" side)
    INPUT_DOWN,        // direction down / next (from toggle switch "next" side)
    INPUT_REPEAT_UP,   // held auto-repeat up
    INPUT_REPEAT_DOWN, // held auto-repeat down
    INPUT_RELEASE,     // toggle returned to center

    // --- Normalized events (output of inputNormalize()) ---
    // These are context-routed semantic actions consumed by main.cpp and uiTick().
    NAV_UP,            // move cursor up (menu) / no effect in playback
    NAV_DOWN,          // move cursor down (menu) / no effect in playback
    NAV_ENTER,         // select / confirm (menu)
    NAV_BACK,          // go back / exit (menu)
    VOLUME_UP,         // increase volume (playback context only)
    VOLUME_DOWN,       // decrease volume (playback context only)
    TRACK_NEXT,        // next track (playback context only)
    TRACK_PREV,        // previous track (playback context only)
    PLAY_PAUSE,        // toggle play/pause (playback context only)
    SHOW_MENU,         // enter menu from playback
};

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

// Call once from setup() on Core 1.
void inputInit();

// Call every loop tick on Core 1.  Returns the next pending RAW event (or NONE).
// This never blocks — always callable.
InputEvent inputPoll();

// Set the input routing context.  Called by UI layer on state transitions.
void inputSetContext(InputContext ctx);

// Get the current input routing context.  Plain enum, not a UI state query.
InputContext inputGetContext();

// Normalize a raw InputEvent into a context-dependent normalized event.
// This is the central input router.  Consumes the current context set by
// inputSetContext().  Never calls UI state functions.
InputEvent inputNormalize(InputEvent raw);