// =============================================================================
// audio.cpp — Core 0 audio task
// =============================================================================
// Runs forever on Core 0.  Reads commands from gAudioCmdQueue, drives MP3
// decode through the ESP8266Audio pipeline, applies EQ, scales for volume,
// and feeds I2S DMA buffers.  Posts AudioEvents back to Core 1.
//
// ⚠ FLAG: ESP8266Audio's AudioOutputI2S internally uses the ESP-IDF I2S
//   driver.  If you hit conflicts with another I2S instance elsewhere in your
//   sketch, pass useInternalDAC=false and externalDACBits=16 to the constructor
//   explicitly, matching the PCM5102 pin map in config.h.
// =============================================================================

#include "audio.h"
#include "eq.h"
#include "config.h"
#include "state.h"

struct AudioSdGuard {
    bool locked;
    explicit AudioSdGuard(uint32_t timeoutMs = 5000)
        : locked(gSdMutex && xSemaphoreTake(gSdMutex, pdMS_TO_TICKS(timeoutMs)) == pdTRUE) {}
    ~AudioSdGuard() { if (locked) xSemaphoreGive(gSdMutex); }
};
#include "storage.h"

#include <math.h>
#include <stdio.h>  // SEEK_SET, used by skipID3v2Tag()

// ESP8266Audio library headers
#include <AudioFileSourceSD.h>
#include <AudioOutputI2S.h>
#include <AudioGeneratorMP3.h>

#include <driver/i2s.h>
#include <SD.h>
#include <esp_task_wdt.h>
#include <esp_heap_caps.h>

// ---------------------------------------------------------------------------
// Task stack size — MP3 decode is stack-hungry; 8 KB minimum, 12 KB safer.
// ⚠ FLAG: Increase to 16384 if you see stack-overflow panics.
// ---------------------------------------------------------------------------
// ⚠ PRIORITY FIX (stability pass): AudioTask (decode/producer) is now the
//    LOWER-priority task on Core 0; I2SFeedTask (consumer) is the HIGHEST.
//    This was backwards before — decode could preempt the feeder mid-burst
//    and delay it past its DMA deadline, reintroducing exactly the jitter
//    the ring buffer was meant to absorb.
//
//    This is safe specifically because the feeder spends almost all of its
//    time *blocked* inside i2s_write(), waiting for DMA buffer room — a
//    blocked high-priority task yields the CPU completely; it only preempts
//    decode at the instant it actually has work to do (DMA freed a slot),
//    which is exactly when it must run to avoid underrun. Decode, as the
//    lower-priority task, simply gets preempted for the few µs the feeder
//    needs each time and resumes — it has ~742ms of ring buffer margin to
//    absorb that, so it is never starved in practice.
//
//    Still leaves room for the IDLE task to feed the WDT: with WDT disabled
//    on Core 0 (see disableCore0WDT() in main.cpp) this is moot here, but
//    AUDIO_TASK_PRIORITY is kept at configMAX_PRIORITIES-3 rather than -2 so
//    there's still headroom below the feeder for anything else.
// ---------------------------------------------------------------------------
#define AUDIO_TASK_STACK   12288
#define AUDIO_TASK_PRIORITY  (configMAX_PRIORITIES - 4)

// ---------------------------------------------------------------------------
// I2S feeder task — highest-priority real-time task on Core 0. Drains the
// PCM ring buffer into i2s_write() continuously, decoupled from the decode
// loop. See AUDIO_TASK_PRIORITY comment above for why higher-than-decode
// priority is safe here rather than risky.
// ---------------------------------------------------------------------------
#define FEEDER_TASK_STACK    4096
#define FEEDER_TASK_PRIORITY (configMAX_PRIORITIES - 3)

// ---------------------------------------------------------------------------
// PCM ring buffer — elastic buffer between bursty MP3 decode and continuous
// I2S DMA consumption.  See config.h: PCM_BUF_SIZE_BYTES = 128 KB, sized in
// stereo int16 frames = 32768 frames = 742 ms @ 44.1kHz.  Power-of-2 size so
// index wrap is a cheap mask instead of a modulo.
//
// Single-producer (AudioTask, via EQI2SOutput::ConsumeSample) / single-
// consumer (FeederTask) — classic SPSC ring buffer.  head/tail are each only
// ever written by their own task, so no mutex is needed; just volatile reads
// of the other task's index. This matches the project's existing rule of
// "never block the audio decode path."
// ---------------------------------------------------------------------------
struct StereoFrame { int16_t l, r; };

#define PCM_RING_FRAMES (PCM_BUF_SIZE_BYTES / sizeof(StereoFrame))  // 32768
#define PCM_RING_MASK   (PCM_RING_FRAMES - 1)

static StereoFrame*       s_ring        = nullptr;  // PSRAM-backed
static volatile uint32_t  s_ringHead    = 0;  // next write index (producer-owned)
static volatile uint32_t  s_ringTail    = 0;  // next read index  (consumer-owned)
static volatile bool      s_ringDropped = false; // unused since ringPush() now refuses (returns false) on overflow instead of dropping; kept for now in case future overflow-rate logging wants it

// ---------------------------------------------------------------------------
// DIAGNOSTIC COUNTERS (ring buffer health)
//   s_ringOverflowCount — total ringPush() failures (decoder outran feeder)
//   s_ringUnderrunCount — total feeder chunks with framesFilled == 0 (ring ran dry)
//   Both are written by their respective single-writer task on Core 0 and read
//   by AudioTask's once-per-second logging.  uint32_t increments are atomic on
//   32-bit ESP32, so volatile suffices alongside the single-core guarantee.
// ---------------------------------------------------------------------------
static volatile uint32_t  s_ringOverflowCount  = 0;
static volatile uint32_t  s_ringUnderrunCount  = 0;

static inline uint32_t ringUsed() {
    return (s_ringHead - s_ringTail) & PCM_RING_MASK;
}
static inline uint32_t ringFree() {
    return PCM_RING_FRAMES - 1 - ringUsed();  // reserve 1 slot so head==tail is unambiguous (empty)
}

/// Producer side (AudioTask / EQI2SOutput::ConsumeSample). Non-blocking:
/// returns false immediately if the ring is full, rather than dropping a
/// sample to force success. This is what allows ConsumeSample() (below) to
/// honestly report "can't accept more" back to AudioGeneratorMP3::loop(),
/// which is how that library's decode pacing is actually designed to work
/// (see ConsumeSample() comment for the full explanation). The decoder is
/// still never *blocked* — it just gets told no and returns control to the
/// caller, which keeps polling at its own pace.
static inline bool ringPush(int16_t l, int16_t r) {
    if (ringFree() == 0) {
        s_ringOverflowCount++;  // DIAGNOSTIC: count every overflow
        return false;  // full — let the caller decide what to do
    }
    s_ring[s_ringHead] = { l, r };
    s_ringHead = (s_ringHead + 1) & PCM_RING_MASK;
    return true;
}

/// Consumer side (FeederTask). Returns false (caller should write silence)
/// if the ring is empty — never blocks waiting for data.
static inline bool ringPop(int16_t& l, int16_t& r) {
    if (s_ringHead == s_ringTail) return false;  // empty
    StereoFrame f = s_ring[s_ringTail];
    s_ringTail = (s_ringTail + 1) & PCM_RING_MASK;
    l = f.l; r = f.r;
    return true;
}

/// Discard any buffered PCM — called on track change so the tail end of the
/// previous track doesn't leak into the start of the next one. Safe to call
/// from the producer (AudioTask) side: it only ever advances tail forward to
/// meet head, which the consumer treats the same as a normal empty ring.
static inline void ringReset() {
    s_ringTail = s_ringHead;
}

// Forward declarations
static void audioFeederTaskFn(void* pvParams);

// ---------------------------------------------------------------------------
// Audio-ready flag — set to true once audio task init is complete and I2S is
// configured.  Core 1 polls this via audioIsReady() to avoid sending PLAY_TRACK
// before the audio pipeline is ready to receive it.
// ---------------------------------------------------------------------------
static volatile bool s_audioReady = false;
static volatile bool s_pauseFeeder = false;  // pause feeder during i2s reconfig (track change)

// ---------------------------------------------------------------------------
// Volume curve tuning
// ---------------------------------------------------------------------------
// gain = pow(volume / 100.0f, VOLUME_GAMMA)
//
// gamma=1.0 → linear (original — bad, low end too loud)
// gamma=2.0 → natural quadratic (sweet spot — recommended start)
// gamma=2.5 → even more low-end precision (if volume 5 still feels too loud)
// gamma=3.0 → aggressive low-end spread (may need higher listening volumes)
//
#define VOLUME_GAMMA  2.0f

// ---------------------------------------------------------------------------
// Runaway/never-ending track watchdog tuning — see the WATCHDOG comment in
// audioTaskFn() for why this exists.
// ---------------------------------------------------------------------------
#define TRACK_DURATION_GRACE_MS   60000UL          // 60s over the estimate
#define TRACK_RUNAWAY_HARD_CAP_MS (20UL * 60UL * 1000UL)  // 20 min absolute

// ---------------------------------------------------------------------------
// Module state (all touched only by Core 0 task)
// ---------------------------------------------------------------------------
static AudioFileSourceSD*   s_src    = nullptr;
static AudioOutputI2S*      s_out    = nullptr;
static AudioGeneratorMP3*   s_gen    = nullptr;

static int       s_currentTrack  = -1;
static bool      s_playing       = false;
static bool      s_paused        = false;
static volatile int s_volume        = DEFAULT_VOLUME;  // 0-100 — volatile: read inside MP3 decoder loop(), written by handleCommand()
static volatile float s_gain     = 1.0f;  // precomputed from s_volume via pow-law curve — volatile: written by recalcGain() on AudioTask (decode), read live by audioFeederTaskFn() on FeederTask at the playback boundary
static uint32_t  s_startMs       = 0;   // millis() when track started (approx)
static uint32_t  s_pausedMs      = 0;   // accumulated pause time
static uint32_t  s_trackDurationMs = 0; // estimated duration of current track

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

/// Recompute s_gain from s_volume using a power-law curve.
/// Called only when volume changes — NOT per sample.
/// ⚠ This is the only volume-related logic that remains on the decode
///   side, and it does not touch any audio sample — it only updates the
///   shared scalar s_gain that the feeder task reads at the playback
///   boundary (see applyGain() in audioFeederTaskFn() below). No residual
///   per-sample volume application exists in the producer/decode path.
static void recalcGain() {
    // ⚠ DEFENSIVE CLAMP: read s_volume into a local once (it's volatile —
    //   written asynchronously by handleCommand()'s SET_VOLUME case) and
    //   clamp it BEFORE it ever reaches powf(). powf() with a fractional
    //   exponent on a negative base is undefined and can return NaN. NaN
    //   then flows into s_gain, and from there into applyGain() on the
    //   feeder task — see the NaN-safety fix there. Clamping here removes
    //   the bad value at its origin instead of only handling the symptom
    //   downstream.
    int vol = constrain((int)s_volume, 0, 100);
    if (vol <= 0) {
        s_gain = 0.0f;
    } else if (vol >= 100) {
        s_gain = 1.0f;
    } else {
        s_gain = powf((float)vol / 100.0f, VOLUME_GAMMA);
    }
}

// ---------------------------------------------------------------------------
// ID3v2 tag skip — FAST via seek(), not the decoder stepping through it.
//
// Some tracks in this library carry a leading ID3v2 tag with an embedded
// APIC (cover art / "thumbnail") frame — anywhere from tens of KB to a few
// MB of embedded JPEG/PNG data. Nothing in this firmware ever reads ID3 (see
// storage.cpp: titles/artists are derived from filenames only, no ID3
// parsing at all) — but the MP3 decoder still has to get PAST that leading
// tag to find the first real audio frame before begin() can return. Left to
// the decoder/library's own tag-skipping, that's effectively a sequential
// read over SD of however many bytes of image data the tag contains, which
// is exactly what was producing multi-second (sometimes 15-30s) "stuck at
// 0:00" gaps between songs — only on tracks that happen to carry embedded
// art, matching what was observed. A raw SD seek() past the same span is
// several orders of magnitude faster than reading through it, so do that
// explicitly before the decoder ever sees the file.
static void skipID3v2Tag(AudioFileSourceSD* src) {
    uint8_t hdr[10];
    if (src->read(hdr, sizeof(hdr)) != sizeof(hdr)) {
        src->seek(0, SEEK_SET);  // file shorter than an ID3 header — just rewind
        return;
    }
    if (hdr[0] == 'I' && hdr[1] == 'D' && hdr[2] == '3') {
        // Tag size is a 28-bit "syncsafe" integer: 7 bits used per byte,
        // MSB of each byte always 0. Spans bytes 6-9 of the header.
        uint32_t tagSize = ((uint32_t)(hdr[6] & 0x7F) << 21) |
                           ((uint32_t)(hdr[7] & 0x7F) << 14) |
                           ((uint32_t)(hdr[8] & 0x7F) << 7)  |
                            (uint32_t)(hdr[9] & 0x7F);
        bool hasFooter = (hdr[5] & 0x10) != 0;  // footer flag, bit 4 of byte 5
        uint32_t skipTo = 10 + tagSize + (hasFooter ? 10 : 0);
        Serial.printf("[audio] Skipping ID3v2 tag: %u bytes (fast seek)\n", (unsigned)skipTo);
        src->seek((int32_t)skipTo, SEEK_SET);
    } else {
        // No ID3v2 tag present — first audio frame starts at byte 0.
        src->seek(0, SEEK_SET);
    }
}

static bool openTrack(int index) {
    AudioSdGuard sdGuard(60000);
    if (!sdGuard.locked) return false;
    char pathBuf[PATH_LEN];
    if (!getTrackPath(index, pathBuf, sizeof(pathBuf))) {
        Serial.printf("[audio] openTrack: invalid index %d\n", index);
        return false;
    }
    // Tear down the previous decoder and source BEFORE pausing the feeder.
    // These operations (stop/delete/close/open on SD) do NOT touch the I2S
    // driver and can run while the feeder continues draining the ring buffer,
    // keeping the DMA pipeline warm during the entire file-open window.
    if (s_gen) { s_gen->stop(); delete s_gen; s_gen = nullptr; }
    if (s_src) { s_src->close(); delete s_src; s_src = nullptr; }

    // Path already has leading "/" from storage.cpp — no prepend needed
    Serial.printf("[audio] Opening: %s\n", pathBuf);

    // Direct open — no redundant SD.exists() or SD.open() for debug logging.
    // The persistent binary index already verified the path at scan time, and
    // AudioFileSourceSD's own isOpen() check below catches any failures.
    // Removing these duplicate SD operations saves ~100ms per track change on
    // a typical SD card (two file-open round trips).
    s_src = new AudioFileSourceSD(pathBuf);
    if (!s_src || !s_src->isOpen()) {
        Serial.println("[audio] Failed to open file on SD");
        postAudioEvent(AudioEventType::ERROR_FILE, index);
        return false;
    }

    // Fast-skip any leading ID3v2 tag (including embedded cover art) via
    // seek() rather than letting the decoder step through it — see
    // skipID3v2Tag() comment above for why this matters.
    skipID3v2Tag(s_src);

    // Retrieve estimated track duration from our persistent binary index entry
    IndexEntry entry;
    if (getIndexEntry(index, entry)) {
        s_trackDurationMs = entry.durationMs;
    } else {
        s_trackDurationMs = 0;
    }

    s_gen = new AudioGeneratorMP3();

    // Pause the feeder NOW — just before s_gen->begin(), which is the only
    // call that touches the I2S driver (via EQI2SOutput::begin()).
    // On second and subsequent tracks EQI2SOutput::begin() skips the full
    // uninstall/reinstall (Fix 1) and only zeroes the DMA buffers, so the
    // pause window is just a few microseconds instead of tens of milliseconds.
    // On the very first track it does the full install — still safe because
    // the feeder task hasn't been created yet at that point.
    s_pauseFeeder = true;
    vTaskDelay(pdMS_TO_TICKS(2));  // yield so a mid-i2s_write() feeder chunk completes

    // AudioGeneratorMP3 in ESP8266Audio v1.9.9 takes source + output only.
    // Calls EQI2SOutput::begin() internally — see Fix 1 comment there.
    if (!s_gen->begin(s_src, s_out)) {
        s_pauseFeeder = false;  // always unpause on error so the feeder can recover
        Serial.println("[audio] AudioGeneratorMP3::begin failed");
        postAudioEvent(AudioEventType::ERROR_FILE, index);
        return false;
    }
    Serial.println("[audio] Decoder opened successfully");

    // Start the I2S feeder task — once.  EQI2SOutput::begin() has now run
    // (either full install on first track, or DMA-zero on subsequent tracks),
    // so i2s_write() is safe.
    static bool s_feederStarted = false;
    if (!s_feederStarted) {
        s_feederStarted = true;
        xTaskCreatePinnedToCore(
            audioFeederTaskFn, "I2SFeedTask", FEEDER_TASK_STACK,
            nullptr, FEEDER_TASK_PRIORITY, nullptr, 0
        );
    }

    // Flush ring BEFORE unpausing the feeder — ringReset() called AFTER
    // s_pauseFeeder=false was a race condition: the feeder could start
    // pulling from the ring between the unpause and the reset, reading
    // garbage or writing stale-track audio to DMA. With the flush here,
    // the ring is clean before the feeder ever sees it.
    ringReset();
    eqReset();

    // Unpause the feeder — DMA is clean, ring is flushed, safe to run.
    s_pauseFeeder = false;

    if (xSemaphoreTake(gPlaybackMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
        gPlayback.status            = PlaybackStatus::PLAYING;
        gPlayback.currentTrackIndex = index;
        gPlayback.positionMs        = 0;
        gPlayback.durationMs        = s_trackDurationMs;
        xSemaphoreGive(gPlaybackMutex);
    }

    // ⚠ FIX: these two were never being set anywhere in this file. Without
    //   s_playing = true, the decode gate in audioTaskFn()'s main loop
    //   (`if (s_gen && s_playing && !s_paused)`) was permanently false, so
    //   s_gen->loop() was never called after openTrack() succeeded — no MP3
    //   decoding ever happened, the ring buffer stayed empty forever, and
    //   the feeder just wrote continuous silence. PAUSE/RESUME were also
    //   silent no-ops as a result, since both are gated on s_playing too.
    //   Without s_currentTrack being kept in sync with the track actually
    //   opened, NEXT_TRACK/PREV_TRACK and the track-ended auto-advance path
    //   (which all compute off s_currentTrack, not gPlayback.currentTrackIndex)
    //   always computed relative to -1, so "next"/"prev" always reopened
    //   track 0 instead of actually advancing.
    s_playing      = true;
    s_paused       = false;
    s_currentTrack = index;
    // The progress clock is relative to the currently opened track. Reset it
    // here so POSITION_UPDATE reports elapsed track time rather than uptime
    // or time accumulated while playing the previous track.
    s_startMs      = millis();
    s_pausedMs     = 0;

    postAudioEvent(AudioEventType::TRACK_STARTED, index, 0, s_trackDurationMs);
    return true;
}

static void handleCommand(const AudioCmd& cmd) {
    switch (cmd.type) {
        case AudioCmdType::PLAY_TRACK:
            openTrack(cmd.trackIndex);
            break;

        case AudioCmdType::PAUSE:
            if (s_gen && s_playing && !s_paused) {
                s_paused    = true;
                s_pausedMs  = millis();
                ringReset();  // don't let ~742ms of buffered audio keep playing after pause
                if (xSemaphoreTake(gPlaybackMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
                    gPlayback.status = PlaybackStatus::PAUSED;
                    xSemaphoreGive(gPlaybackMutex);
                }
                postAudioEvent(AudioEventType::PLAYBACK_PAUSED, s_currentTrack);
            }
            break;

        case AudioCmdType::RESUME:
            if (s_gen && s_playing && s_paused) {
                s_startMs += (millis() - s_pausedMs);
                s_paused = false;
                if (xSemaphoreTake(gPlaybackMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
                    gPlayback.status = PlaybackStatus::PLAYING;
                    xSemaphoreGive(gPlaybackMutex);
                }
                postAudioEvent(AudioEventType::PLAYBACK_RESUMED, s_currentTrack);
            }
            break;

        case AudioCmdType::NEXT_TRACK: {
            int count = getTrackCount();
            if (count > 0) openTrack((s_currentTrack + 1) % count);
            break;
        }

        case AudioCmdType::PREV_TRACK: {
            int count = getTrackCount();
            if (count > 0) openTrack((s_currentTrack - 1 + count) % count);
            break;
        }

        case AudioCmdType::SET_VOLUME:
            Serial.printf("[audio] SET_VOLUME cmd: value=%ld, old_vol=%d\n", cmd.value, (int)s_volume);
            s_volume = constrain((int)cmd.value, 0, 100);
            recalcGain();   // <-- recompute logarithmic gain once
            saveVolume(s_volume);  // <-- persist to NVS so it survives reset
            Serial.printf("[audio] SET_VOLUME applied: vol=%d, gain=%.4f\n", (int)s_volume, (double)s_gain);
            if (xSemaphoreTake(gPlaybackMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
                gPlayback.volume = s_volume;
                xSemaphoreGive(gPlaybackMutex);
            }
            postAudioEvent(AudioEventType::VOLUME_CHANGED, s_currentTrack,
                           0, 0, s_volume);
            break;

        case AudioCmdType::STOP:
            if (s_gen) s_gen->stop();
            s_playing = false;
            s_paused  = false;
            ringReset();  // don't let buffered audio keep playing after STOP
            if (xSemaphoreTake(gPlaybackMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
                gPlayback.status = PlaybackStatus::STOPPED;
                xSemaphoreGive(gPlaybackMutex);
            }
            break;

        default:
            break;
    }
}

class EQI2SOutput : public AudioOutputI2S {
public:
    // ⚠ Our own "is the legacy driver installed" flag. We can't rely on the
    //   base class's `i2sOn` member for this: it's only ever set true inside
    //   AudioOutputI2S::begin() (the new i2s_chan_handle_t-API version),
    //   which we never call — our begin() override replaces it entirely
    //   with the legacy i2s_driver_install() path. So i2sOn stays false
    //   forever from the base class's point of view, even while our driver
    //   is actually up and running. SetRate() below needs to know whether
    //   the legacy driver is live to decide whether to call i2s_set_clk();
    //   this flag is that source of truth instead.
    bool driverInstalled = false;

    EQI2SOutput() : AudioOutputI2S(0, AudioOutputI2S::EXTERNAL_I2S) {
        // Configure pins and format BEFORE begin() is called.
        // ⚠ Do NOT call begin() here — AudioGeneratorMP3::begin() will
        //    call AudioOutputI2S::begin() internally. Calling it twice
        //    races on the I2S driver and produces silence.
        SetPinout(PIN_I2S_BCLK, PIN_I2S_WS, PIN_I2S_DOUT);
        SetRate(SAMPLE_RATE);
        SetBitsPerSample(16);
        SetChannels(2);
        SetOutputModeMono(false);
        // begin() is called by AudioGeneratorMP3::begin() → output->begin()
    }

    // ⚠ I2S DRIVER BUG FIX: AudioOutputI2S::begin() calls i2s_driver_install()
    //   every time it is called.  On ESP32 arduino-esp32 3.x / ESP-IDF 5.x,
    //   calling i2s_driver_install() on an already-installed port returns
    //   ESP_ERR_INVALID_STATE.  The parent class does NOT uninstall first, so
    //   the second and subsequent calls to begin() (one per track change via
    //   AudioGeneratorMP3::begin() → output->begin()) leave the I2S driver in
    //   an inconsistent state, causing silence and/or stuck-at-0:00 behaviour.
    //
    //   Original fix: uninstall + reinstall on every track. This worked but
    //   added ~50–100ms of silence at every track boundary because the entire
    //   I2S driver teardown/setup sequence had to complete — and the feeder
    //   had to be paused for the whole duration.
    //
    //   Fix 1 (gap reduction): on second and subsequent tracks, skip the
    //   uninstall/reinstall entirely. The driver is already running with the
    //   correct DMA config. Just zero the DMA buffers to flush stale data and
    //   return. (Sample-rate changes used to be handled by a live
    //   i2s_set_clk() call in SetRate() below — that turned out to be the
    //   root cause of the universal static bug, since it changed the wire
    //   clock without flushing already-buffered, old-rate-paced PCM out of
    //   the ring first. See the SetRate() comment below for the real fix:
    //   a rate change now forces a full reinstall through this same path,
    //   not a live clock nudge.)
    //
    //   Recovery: if i2s_zero_dma_buffer() returns an error (driver somehow
    //   corrupt), fall through to the full reinstall path so the player
    //   self-heals on the next track rather than getting stuck.
    //
    // ⚠ SAMPLE RATE FIX: AudioGeneratorMP3 does NOT call SetRate() before
    //   begin() — it calls it from inside GetOneSample(), i.e. mid-stream,
    //   once decoding is already underway and it has seen the file's actual
    //   sample rate in the first decoded frame. So by the time SetRate()
    //   fires, our begin() has already run (using whatever `hertz` was at
    //   construction time — the SAMPLE_RATE default, now 48000 — see
    //   config.h) and the legacy I2S driver is already installed at that
    //   rate. Most tracks in this library are 48kHz, so this matches on
    //   the common case from the very first frame; SetRate() below only
    //   has real work to do for the rarer rate that doesn't match.
    //
    //   The base AudioOutputI2S::SetRate() in this arduino-esp32/ESP-IDF
    //   version reconfigures the clock via the NEW i2s_chan_handle_t /
    //   i2s_channel_reconfig_std_clock() API. That API targets a completely
    //   different I2S driver model than the legacy i2s_driver_install() /
    //   i2s_write() calls used everywhere else in this file (begin() above,
    //   the feeder's i2s_write()). The new-API call has no handle to act on
    //   here, so it silently does nothing on its own — which is why this
    //   override exists at all. (An earlier version of this override called
    //   i2s_set_clk() directly to live-reconfigure the legacy driver's
    //   clock — that successfully changed the wire clock, but did nothing
    //   about the ~742ms of PCM already buffered in the ring under the OLD
    //   rate's timing, which then played out under the NEW clock right
    //   after the switch. That mismatch is what produced static/garbled
    //   audio on every track, since most tracks here are 48kHz against a
    //   44.1kHz initial install.
    //
    //   Fix: on a genuine rate change, do a full driver reinstall (so the
    //   DMA's own sample_rate config field, not just the clock, is correct
    //   — see begin() below) AND flush the ring first, via the same
    //   s_pauseFeeder + ringReset() pattern openTrack() already uses for
    //   track changes. This is safe to call from here because SetRate() —
    //   like ConsumeSample() — runs on AudioTask (the producer/decode
    //   side), the same side ringReset() is documented as safe to call
    //   from. The brief feeder pause means a few ms of dropped output at
    //   the moment of a genuine rate change, which is far better than the
    //   alternative (audible garbage), and should now be rare in practice
    //   since config.h's SAMPLE_RATE default was changed to 48000 to match
    //   what this library mostly actually contains.
    bool SetRate(int hz) override {
        // ⚠ SANITY GUARD: a corrupt/malformed MP3 frame can make
        //   AudioGeneratorMP3 misparse a bogus "sample rate" (0, some huge
        //   nonsensical value, etc). Accepting that blindly would overwrite
        //   `hertz` with garbage and/or attempt an i2s_driver_install() with
        //   an invalid rate — and because `hertz`/`driverInstalled` live on
        //   this SAME EQI2SOutput object for the entire runtime (reused
        //   across every track, never recreated), one bad file could leave
        //   every track after it broken until reboot. Reject anything
        //   outside a plausible real-world MP3 sample rate and just keep
        //   playing at whatever rate was already working.
        if (hz < 8000 || hz > 192000) {
            Serial.printf("[audio] ⚠ Rejecting bogus rate %d from track %d (corrupt frame?) — keeping %d\n",
                          hz, s_currentTrack, hertz);
            return true;  // pretend success; don't let this poison state
        }
        bool changed = (hertz != hz);
        if (driverInstalled && changed) {
            uint32_t t = millis();
            int oldRate = hertz;  // capture BEFORE updating hertz
            hertz = hz;
            Serial.printf("[audio] %lu: rate change %d -> %d for track %d, forcing reinstall\n",
                          t, oldRate, hz, s_currentTrack);

            // Pause the feeder and flush the ring BEFORE tearing down the
            // driver, so no stale-rate samples get written once the new
            // rate is live, and so the feeder never calls i2s_write() on a
            // driver mid-uninstall.
            s_pauseFeeder = true;
            vTaskDelay(pdMS_TO_TICKS(2));
            ringReset();

            // Mark not-installed so the begin() call below takes the full
            // reinstall path (with the new `hertz` value already set above)
            // instead of the live-clock-nudge / DMA-zero-only path.
            driverInstalled = false;
            bool ok = begin();  // re-installs at the new rate from scratch
            s_pauseFeeder = false;

            if (!ok) {
                Serial.printf("[audio] Reinstall for rate change to %dHz FAILED\n", hz);
                return false;
            }
            Serial.printf("[audio] Reinstalled I2S driver at %dHz for track %d\n", hz, s_currentTrack);
        } else {
            hertz = hz;  // no reinstall needed, but still track the rate
        }
        return true;
    }

    bool begin() override {
        // FIX 1: If the driver is already installed and healthy, skip the
        // full uninstall/reinstall cycle. Just clear the DMA buffers so
        // stale samples from the previous track don't leak into the new one.
        // The feeder pause window in openTrack() is now only the few µs this
        // takes, rather than the full ~50–100ms of a driver reinstall.
        if (driverInstalled) {
            // DIAGNOSTIC: log every i2s_zero_dma_buffer() with timestamp + track info
            uint32_t t = millis();
            esp_err_t err = i2s_zero_dma_buffer((i2s_port_t)I2S_PORT);
            if (err == ESP_OK) {
                Serial.printf("[audio] %lu: i2s_zero_dma_buffer() for track %d (no reinstall)\n", t, s_currentTrack);
                return true;
            }
            // If zeroing failed the driver state is suspect — fall through to
            // full reinstall so the player self-heals rather than staying broken.
            Serial.printf("[audio] i2s_zero_dma_buffer failed (%d), falling back to full reinstall\n", err);
            driverInstalled = false;
        }

        // First track (or self-heal after driver error): full install path.
        // Uninstall any existing driver on this port first — ignore the error
        // if nothing was installed yet.
        i2s_driver_uninstall((i2s_port_t)I2S_PORT);

        // Use the rate the decoder actually asked for via SetRate(), not a
        // hardcoded constant. `hertz` is set by the base AudioOutputI2S
        // class's SetRate() — primed to SAMPLE_RATE (now 48000, matching
        // what this library mostly contains — see config.h) by our
        // constructor, and overwritten by AudioGeneratorMP3 with the
        // file's real sample rate before it calls output->begin(). This may
        // still be the *previous* track's rate the first instant begin()
        // runs for a new track (SetRate() for the new file's real rate
        // doesn't fire until its first frame is decoded, a few ms into
        // playback) — that's fine: SetRate() now detects that mismatch and
        // forces exactly this same full-reinstall path again moments
        // later, this time with the correct rate, rather than silently
        // live-nudging the clock out from under already-buffered audio.
        int rate = hertz ? hertz : SAMPLE_RATE;

        // Install with our tuned DMA parameters from config.h.
        i2s_config_t i2s_config = {};
        i2s_config.mode                 = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
        i2s_config.sample_rate          = rate;
        i2s_config.bits_per_sample      = I2S_BITS_PER_SAMPLE_16BIT;
        i2s_config.channel_format       = I2S_CHANNEL_FMT_RIGHT_LEFT;
        i2s_config.communication_format = I2S_COMM_FORMAT_STAND_I2S;
        i2s_config.intr_alloc_flags     = ESP_INTR_FLAG_LEVEL1;
        i2s_config.dma_buf_count        = I2S_DMA_BUF_COUNT;
        i2s_config.dma_buf_len          = I2S_DMA_BUF_LEN;
        i2s_config.use_apll             = false;
        i2s_config.tx_desc_auto_clear   = true;
        esp_err_t err = i2s_driver_install((i2s_port_t)I2S_PORT, &i2s_config, 0, NULL);
        if (err != ESP_OK) {
            Serial.printf("[audio] i2s_driver_install failed: %d\n", err);
            return false;
        }

        i2s_pin_config_t pin_config = {};
        pin_config.mck_io_num   = PIN_I2S_SCK;    // drive MCLK on SCK pin per GPIO Assignments: GPIO 7
        pin_config.bck_io_num   = PIN_I2S_BCLK;
        pin_config.ws_io_num    = PIN_I2S_WS;
        pin_config.data_out_num = PIN_I2S_DOUT;
        pin_config.data_in_num  = I2S_PIN_NO_CHANGE;
        err = i2s_set_pin((i2s_port_t)I2S_PORT, &pin_config);
        if (err != ESP_OK) {
            Serial.printf("[audio] i2s_set_pin failed: %d\n", err);
            return false;
        }

        // Zero DMA buffers so there is no stale noise at track start.
        i2s_zero_dma_buffer((i2s_port_t)I2S_PORT);

        driverInstalled = true;
        Serial.printf("[audio] I2S driver installed: %dHz, %d DMA bufs × %d samples\n",
                      rate, I2S_DMA_BUF_COUNT, I2S_DMA_BUF_LEN);
        return true;
    }

    // ⚠ VOLUME FIX (corrected): volume is NOT applied here. This pushes
    //   EQ-processed PCM only into the ring buffer — gain-neutral audio.
    //   Gain is applied at the playback boundary, in audioFeederTaskFn(),
    //   immediately before i2s_write(). Rationale: the audible effect of a
    //   volume change is bounded by how much already-gained audio is
    //   queued ahead of it. Baking gain in here would mean a SET_VOLUME
    //   command doesn't reach the speaker until everything already sitting
    //   in the ~742ms ring buffer drains — a 742ms perceived lag, which
    //   reads as broken, not instant. Applying gain at the feeder instead
    //   means a volume change reaches the speaker as soon as the I2S DMA
    //   buffer alone drains (~46ms) — an 8x improvement — because gain is
    //   the last operation touching the sample before i2s_write(). See
    //   audioFeederTaskFn() for the corresponding gain application.
    //
    // ⚠ BALANCE: balance IS applied here (producer side), unlike volume.
    //   Reason: applying balance in the feeder requires mutex access to
    //   read gPlayback.balance. The feeder runs at configMAX_PRIORITIES-3
    //   and must NEVER take a mutex — doing so would preempt the audio
    //   decoder (at a lower priority) while waiting for the mutex, causing
    //   priority inversion and crashing the real-time I2S feed. Balance
    //   changes have ~742ms latency instead of ~46ms, which is fine for
    //   manual adjustment.
    // ⚠ PACING FIX (the actual root cause of sped-up / garbled playback):
    //   AudioGeneratorMP3::loop() works like this internally: it decodes one
    //   sample, calls output->ConsumeSample() on it, and if that returns
    //   true, immediately decodes the NEXT sample and tries again — in a
    //   tight do/while loop, with NO other exit condition per call except
    //   running out of compressed data or hitting a decode error. The
    //   *only* thing that's supposed to make loop() return control to the
    //   caller at a sane point is ConsumeSample() returning false once the
    //   output side can't accept more right now.
    //
    //   This previously always returned true unconditionally (ringPush()
    //   used to silently drop the oldest sample and succeed on overflow).
    //   That meant a single call to s_gen->loop() from audioTaskFn()'s main
    //   loop had no real boundary — it could decode and push an arbitrarily
    //   large burst of frames (limited only by how fast the CPU could pull
    //   compressed bytes off the SD card and run the decoder), all in one
    //   shot, before audioTaskFn() ever got back to its own throttle logic.
    //   The external throttles (this file has tried both a fixed per-call
    //   delay and an adaptive ring-fill-based delay) only run *between*
    //   calls to loop() — they can't do anything about an already-unbounded
    //   burst that happened *inside* one call. Net effect: audio got
    //   crammed into the ring far faster than real-time in bursts, the ring
    //   overflowed repeatedly (dropping freshly-decoded audio, not stale
    //   audio), and what came out the far end was time-compressed —
    //   audible as "playing too fast" — regardless of sample rate, I2S
    //   clock config, or core priorities.
    //
    //   Fix: report ring-full honestly. Once ringPush() fails, return false
    //   here so loop()'s inner do/while exits immediately and hands control
    //   back to audioTaskFn(), which calls loop() again on its very next
    //   pass through the outer for(;;) — nothing is lost, decode just
    //   naturally paces itself to "however much room is in the ring right
    //   now" per call instead of running unbounded. This also makes the
    //   external throttle delays redundant for correctness (they can still
    //   help reduce wasted CPU spinning, but no longer carry the actual
    //   pacing responsibility) — see the adaptive throttle below, now purely
    //   a CPU-saving nicety rather than the thing standing between correct
    //   and sped-up playback.
    bool ConsumeSample(int16_t sample[2]) override {
        float fL = sample[0] / 32768.0f;
        float fR = sample[1] / 32768.0f;
        eqProcess(fL, fR);
        // ⚠ NaN/Inf GUARD: an IIR biquad's state variables (w1/w2 in eq.cpp)
        //   propagate any non-finite value forward into every sample after
        //   it — once NaN gets into the filter state, it never clears on
        //   its own (only eqReset() on track/preset change would clear it).
        //   If a single corrupt decoded sample or transient float error
        //   ever drove the filter there, every sample after it would be
        //   non-finite all the way to the DAC, sounding exactly like
        //   continuous full-volume noise. Catch it here, at the earliest
        //   point after EQ and before it reaches the ring buffer, and
        //   substitute silence for that sample rather than letting NaN
        //   propagate downstream into balance scaling, the ring, and
        //   ultimately applyGain() on the feeder side.
        if (!isfinite(fL)) fL = 0.0f;
        if (!isfinite(fR)) fR = 0.0f;
        int16_t outL = (int16_t)constrain((int32_t)(fL * 32767.0f), -32768, 32767);
        int16_t outR = (int16_t)constrain((int32_t)(fR * 32767.0f), -32768, 32767);
        return ringPush(outL, outR);  // false ⇒ ring full ⇒ decoder backs off
    }
};

static uint32_t s_lastPositionReportMs = 0;
#define POSITION_REPORT_INTERVAL_MS 1000

// ---------------------------------------------------------------------------
// I2S feeder task — the only thing this task does is keep I2S DMA fed,
// continuously, regardless of what AudioTask/decode is doing. This is the
// piece that actually decouples decode timing from output timing.
//
// Pulls frames out of the ring buffer in moderately sized chunks (matches
// I2S_DMA_BUF_LEN from config.h) and writes them with i2s_write(). On
// underrun (ring empty — e.g. cold start before decode has filled it, or a
// pathological SD stall longer than the ~742ms buffer can absorb) it writes
// silence for that chunk instead of blocking or busy-spinning, so I2S DMA
// never starves and the IDF driver never has to repeat/garbage stale buffer
// contents (the actual audible "click").
//
// ⚠ VOLUME (playback boundary): gain is applied here, immediately before
//   i2s_write(), reading the live volatile s_gain — never cached, never
//   precomputed earlier in the pipeline. This is the actual playback
//   boundary: the last touch a sample gets before it reaches the DAC.
//   Per stereo frame, s_gain is read exactly ONCE (into a local) and used
//   for both L and R — not via two independent per-channel gain calls that
//   could each re-read s_gain separately. That matters because s_gain is
//   written asynchronously from AudioTask's SET_VOLUME handler: two
//   independent reads could straddle a write and apply mismatched gain to
//   the left vs. right channel of the same frame (a momentary, narrow
//   stereo-balance glitch). Reading once per frame guarantees L and R
//   always share identical gain.
//
// ⚠ NOTE: Balance is NOT applied in the feeder. It is applied in the
//   producer (ConsumeSample) alongside EQ to avoid ANY mutex operations
//   in this high-priority real-time task. Balance changes take ~742ms
//   to become audible (ring buffer depth), which is imperceptible for
//   manual adjustment.
// ---------------------------------------------------------------------------
static inline int16_t applyGain(int16_t sample, float gain) {
    // ⚠ NaN-SAFETY FIX: the original `if (gain >= 1.0f) return sample;`
    //   early-out is FALSE for NaN (every comparison against NaN is false),
    //   so a NaN/garbage gain value used to fall straight through to
    //   `sample * gain` below, producing NaN, which constrain()/the cast to
    //   int16_t then turns into implementation-defined (effectively random,
    //   often full-scale) output — written directly to the DAC. That is
    //   the most likely source of the "full volume garbage noise" bug:
    //   any upstream NaN in s_gain used to bypass this function entirely
    //   instead of being caught by it.
    //
    //   isfinite() catches NaN AND ±Inf in one check. A non-finite gain is
    //   treated as "mute this frame" rather than "pass it through" — silence
    //   is always the safe failure mode for audio output, never raw samples
    //   scaled by garbage.
    if (!isfinite(gain)) return 0;
    if (gain >= 1.0f) return sample;
    if (gain <= 0.0f) return 0;
    float scaled = (float)sample * gain;
    if (scaled > 32767.0f) return 32767;
    if (scaled < -32768.0f) return -32768;
    return (int16_t)scaled;
}

// ---------------------------------------------------------------------------
// DIAGNOSTIC: sample-level sanity check in the feeder.
//   Detects N consecutive frames where both L and R are suspiciously
//   identical to each other and to the previous frame (a fingerprint of
//   clock desync — the DAC repeating/garbling the same DMA word) OR both
//   are at maximum absolute value (32767 / -32768 — maxed-out output,
//   another clock-desync symptom).  Rate-limited to one log per
//   SUSPECT_FRAME_RATELIMIT_MS to avoid flooding serial.
// ---------------------------------------------------------------------------
#define SUSPECT_CONSECUTIVE_N  64   // frames before we flag it
#define SUSPECT_FRAME_RATELIMIT_MS 60000  // don't re-log within 60s

static void audioFeederTaskFn(void* /*pvParams*/) {
    Serial.println("[audio] FeederTask started on Core 0");

    static int16_t chunk[I2S_DMA_BUF_LEN * 2];  // interleaved L/R

    // DIAGNOSTIC: consecutive-suspect-sample tracker
    uint32_t suspectCount     = 0;
    int16_t  suspectLastL     = 0;
    int16_t  suspectLastR     = 0;
    uint32_t suspectLastLogMs = 0;

    for (;;) {
        // If a track change is in progress, the I2S driver is being
        // reinstalled. Skip this chunk to avoid calling i2s_write() on
        // a destroyed driver handle, which would hang forever (WDT reset).
        // Yield briefly so the audio task can complete its reconfiguration.
        if (s_pauseFeeder) {
            // Reset the consecutive-suspect counter during feeder pause so a
            // pause/resume doesn't trigger a false alarm across a clean boundary.
            suspectCount = 0;
            vTaskDelay(pdMS_TO_TICKS(1));
            continue;
        }

        int16_t l, r;
        int framesFilled = 0;
        bool suspectThisChunk = false;

        for (int i = 0; i < I2S_DMA_BUF_LEN; i++) {
            if (ringPop(l, r)) {
                framesFilled++;
            } else {
                l = 0; r = 0;  // underrun: silence, not blocking, not stale data
            }

            // ----- DIAGNOSTIC: consecutive-suspect-sample check -----
            // Check for two patterns:
            //   (a) both channels identical to each other AND identical to the
            //       previous frame's L channel (same DMA word repeated)
            //   (b) both channels at max absolute value (32767 or -32768)
            bool ident      = (l == r) && (l == suspectLastL) && (r == suspectLastR);
            bool bothMaxed  = (l == 32767  || l == -32768) && (r == 32767  || r == -32768);
            if (ident || bothMaxed) {
                suspectCount++;
            } else {
                suspectCount = 0;
            }
            suspectLastL = l;
            suspectLastR = r;

            if (suspectCount >= SUSPECT_CONSECUTIVE_N) {
                uint32_t now = millis();
                if (now - suspectLastLogMs >= SUSPECT_FRAME_RATELIMIT_MS) {
                    suspectLastLogMs = now;
                    suspectThisChunk = true;  // log once after the chunk fill
                }
                suspectCount = 0;  // reset counter so we don't re-trigger mid-chunk
            }
            // ------------------------------------------------------------

            // Single live read of s_gain per frame — shared by L and R so
            // both channels of this frame always get identical gain, even
            // if SET_VOLUME writes s_gain concurrently between samples.
            float gain = s_gain;
            chunk[i * 2]     = applyGain(l, gain);
            chunk[i * 2 + 1] = applyGain(r, gain);
        }

        // Rate-limited log for consecutive suspect samples detected this chunk
        if (suspectThisChunk) {
            Serial.printf("[audio] ⚠ SUSPECT: %d consecutive identical/maxed frames detected on track %d (possible clock desync)\n",
                          (int)SUSPECT_CONSECUTIVE_N, s_currentTrack);
        }

        // DIAGNOSTIC: count underrun chunks (framesFilled == 0)
        if (framesFilled == 0) {
            s_ringUnderrunCount++;
        }

        // ⚠ STARVATION FIX: on a ring-buffer underrun (framesFilled == 0,
        //   i.e. this entire chunk was silence because the decoder hasn't
        //   produced anything new), don't immediately loop back into
        //   i2s_write() again. This task runs at a HIGHER FreeRTOS priority
        //   than the decode task (AudioTask) on this same core — that's
        //   intentional for the non-underrun case (see AUDIO_TASK_PRIORITY
        //   comment above), so the feeder can preempt decode briefly to hit
        //   its DMA deadline. But i2s_write(..., portMAX_DELAY) only blocks
        //   until DMA has room for the NEXT chunk — once a real underrun
        //   starts, DMA continuously has room (nothing is filling it but
        //   silence), so i2s_write() returns almost immediately every time.
        //   The result: this loop spins continuously writing silence at the
        //   highest priority on Core 0, leaving the FreeRTOS scheduler no
        //   opportunity to ever run the lower-priority AudioTask — which is
        //   exactly the task responsible for draining gAudioCmdQueue
        //   (PAUSE/RESUME/NEXT_TRACK/SET_VOLUME/etc. via recvAudioCmd()) AND
        //   for refilling the ring buffer in the first place. Once this
        //   starts, the player can get stuck silently forever: input
        //   commands stop being processed, and the ring can never refill
        //   because the very task that would refill it never gets CPU time.
        //   This is true priority inversion, not specific to any one
        //   underrun cause (track-end, decoder hiccup, very first moments
        //   after openTrack() before the ring has filled, etc).
        //
        //   Fix: on each underrun chunk, yield for roughly one DMA buffer's
        //   worth of playback time instead of immediately re-looping. This
        //   keeps the underrun-silence case from out-competing AudioTask for
        //   the core, while still being short enough (a few ms) that normal
        //   playback resumes the instant the ring has data again — ringPop()
        //   on the very next iteration will immediately pick up fresh
        //   samples once AudioTask gets to run and refill the ring.
        if (framesFilled == 0) {
            vTaskDelay(pdMS_TO_TICKS(1));
        }

        size_t bytesWritten = 0;
        // i2s_write() blocks until DMA has room — that's fine and intended
        // here, since this task's only job is feeding I2S. Blocking here
        // no longer stalls MP3 decode, which is the whole point of the fix.
        i2s_write(I2S_PORT, chunk, sizeof(chunk), &bytesWritten, portMAX_DELAY);

        (void)framesFilled;  // available for underrun-rate logging if needed
    }
    vTaskDelete(nullptr);
}

void audioTaskFn(void* /*pvParams*/) {
    Serial.println("[audio] Task started on Core 0");

    // Allocate the PCM ring buffer in PSRAM (falls back to regular heap if
    // PSRAM isn't available — see config.h PSRAM fallback note).
    s_ring = (StereoFrame*)heap_caps_malloc(
        PCM_RING_FRAMES * sizeof(StereoFrame), MALLOC_CAP_SPIRAM);
    if (!s_ring) {
        Serial.println("[audio] ⚠ PSRAM alloc failed for ring buffer, falling back to heap");
        s_ring = (StereoFrame*)heap_caps_malloc(
            PCM_RING_FRAMES * sizeof(StereoFrame), MALLOC_CAP_8BIT);
    }
    if (!s_ring) {
        Serial.println("[audio] FATAL: could not allocate PCM ring buffer");
        vTaskDelete(nullptr);
        return;
    }
    Serial.printf("[audio] PCM ring buffer: %u frames (%.0f ms @ %dHz)\n",
                  (unsigned)PCM_RING_FRAMES,
                  1000.0f * PCM_RING_FRAMES / SAMPLE_RATE, SAMPLE_RATE);

    s_out = new EQI2SOutput();
    eqSetPreset(EQPreset::FLAT);

    // Load persisted volume from NVS (falls back to DEFAULT_VOLUME)
    s_volume = loadVolume();
    recalcGain();
    Serial.printf("[audio] Initial volume from NVS: %d, gain=%.4f\n", (int)s_volume, (double)s_gain);
    if (xSemaphoreTake(gPlaybackMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        gPlayback.volume   = s_volume;
        gPlayback.status   = PlaybackStatus::STOPPED;
        xSemaphoreGive(gPlaybackMutex);
    }
    // Post initial volume so the UI learns the real value (not DEFAULT_VOLUME)
    // immediately, rather than showing "+21dB" until the encoder is first moved.
    postAudioEvent(AudioEventType::VOLUME_CHANGED, -1, 0, 0, s_volume);

    // Signal Core 1 that the audio task is fully initialized and can accept
    // commands.  Core 1 polls this via audioIsReady() instead of using a
    // delay(), making the startup sequence deterministic.
    s_audioReady = true;
    Serial.println("[audio] Audio task init complete — ready flag set");

    // ⚠ The feeder task is NOT started here. AudioOutputI2S::begin() (which
    //   installs the I2S driver) is called transitively by
    //   AudioGeneratorMP3::begin() — see EQI2SOutput's constructor comment —
    //   and that only happens inside openTrack(), triggered by the first
    //   PLAY_TRACK command. Starting the feeder before that would call
    //   i2s_write() on a port that hasn't been configured yet. openTrack()
    //   below starts the feeder (once, via a static guard) right after the
    //   first successful s_gen->begin().

    // ⚠ Core 0 WDT is disabled globally in setup() via disableCore0WDT().
    //    No per-task WDT management needed here.

    for (;;) {
        AudioCmd cmd;
        while (recvAudioCmd(cmd, 0)) {
            handleCommand(cmd);
        }

        if (s_gen && s_playing && !s_paused) {
            if (s_gen->isRunning()) {
                AudioSdGuard sdGuard(100);
                if (!sdGuard.locked) {
                    vTaskDelay(pdMS_TO_TICKS(1));
                    continue;
                }
                bool stillRunning = s_gen->loop();
                // Release SD before track transition / UI queue work.
                xSemaphoreGive(gSdMutex);
                sdGuard.locked = false;
                if (!stillRunning) {
                    Serial.printf("[audio] Track %d ended\n", s_currentTrack);
                    int ended = s_currentTrack;
                    s_playing = false;
                    postAudioEvent(AudioEventType::TRACK_ENDED, ended);

                    int count = getTrackCount();
                    if (count <= 0) { s_playing = false; continue; }
                    int next = (s_currentTrack + 1) % count;
                    vTaskDelay(pdMS_TO_TICKS(50));
                    openTrack(next);
                }

                uint32_t now = millis();
                if (now - s_lastPositionReportMs >= POSITION_REPORT_INTERVAL_MS) {
                    s_lastPositionReportMs = now;

                    // ----- DIAGNOSTIC: ring buffer health (1Hz) -----
                    uint32_t ovf = s_ringOverflowCount;
                    uint32_t unf = s_ringUnderrunCount;
                    uint32_t used = ringUsed();
                    Serial.printf("[audio] DIAG: ringUsed=%u/%u overflows=%lu underruns=%lu gain=%.4f\n",
                                  (unsigned)used, (unsigned)PCM_RING_FRAMES,
                                  (unsigned long)ovf, (unsigned long)unf,
                                  (double)s_gain);

                    // ----- DIAGNOSTIC: EQ coefficients (1Hz) -----
                    {
                        const BiquadCoeffs& c = eqGetCoeffs();
                        Serial.printf("[audio] DIAG: eq b0=%.4f b1=%.4f b2=%.4f a1=%.4f a2=%.4f\n",
                                      c.b0, c.b1, c.b2, c.a1, c.a2);
                    }

                    // ⚠ NOTE: this position is "samples handed to the ring
                    //   buffer," which now leads what's audible by up to the
                    //   ring's ~742ms depth. Imperceptible for a 1Hz progress
                    //   bar tick; flagged here in case finer sync is ever needed.
                    uint32_t pos = (s_paused)
                        ? (s_pausedMs - s_startMs)
                        : (now - s_startMs);
                    if (xSemaphoreTake(gPlaybackMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
                        gPlayback.positionMs = pos;
                        xSemaphoreGive(gPlaybackMutex);
                    }
                    postAudioEvent(AudioEventType::POSITION_UPDATE,
                                   s_currentTrack, pos, s_trackDurationMs);

                    // ----- WATCHDOG: runaway / never-ending track -----
                    // A corrupt file, or one whose decoder never cleanly
                    // signals EOF, means s_gen->loop() just keeps returning
                    // true forever — nothing above ever calls openTrack()
                    // for the next track, so playback (and the displayed
                    // clock) just runs past the track's real length
                    // indefinitely. Our duration ESTIMATE (storage.cpp:
                    // filesize / assumed-128kbps) is also just a guess and
                    // can be off for VBR/odd-bitrate files, so give it a
                    // generous grace window before treating it as stuck —
                    // but always cap at an absolute ceiling regardless, in
                    // case the estimate itself is 0 or wildly wrong.
                    uint32_t cap = (s_trackDurationMs > 0)
                        ? (s_trackDurationMs + TRACK_DURATION_GRACE_MS)
                        : TRACK_RUNAWAY_HARD_CAP_MS;
                    if (cap > TRACK_RUNAWAY_HARD_CAP_MS) cap = TRACK_RUNAWAY_HARD_CAP_MS;
                    if (pos > cap) {
                        Serial.printf("[audio] ⚠ Track %d exceeded expected length (pos=%lums, cap=%lums) — "
                                      "forcing advance (corrupt/never-ending file?)\n",
                                      s_currentTrack, (unsigned long)pos, (unsigned long)cap);
                        int ended = s_currentTrack;
                        s_playing = false;
                        int count = getTrackCount();
                        if (count <= 0) { s_playing = false; continue; }
                        int next = (s_currentTrack + 1) % count;
                        postAudioEvent(AudioEventType::TRACK_ENDED, ended);
                        vTaskDelay(pdMS_TO_TICKS(50));
                        openTrack(next);
                    }
                }

                // Adaptive throttle: delay after decode based on ring fill.
                // ⚠ No longer load-bearing for correctness — see the
                //   "PACING FIX" comment on ConsumeSample() above.
                //   ConsumeSample() returning false once the ring is full is
                //   what actually paces decode to real-time now; this delay
                //   just avoids spinning audioTaskFn() pointlessly fast when
                //   there's already a healthy buffer, saving CPU/power.
                uint32_t used = ringUsed();
                if (used > (PCM_RING_FRAMES / 10)) {
                    int delayMs = (used * 50) / PCM_RING_FRAMES;  // 1-50ms
                    vTaskDelay(pdMS_TO_TICKS(constrain(delayMs, 1, 50)));
                }
            }
        } else {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
    }
    vTaskDelete(nullptr);
}

bool audioIsReady() {
    return s_audioReady;
}

void audioTaskStart() {
    xTaskCreatePinnedToCore(
        audioTaskFn,
        "AudioTask",
        AUDIO_TASK_STACK,
        nullptr,
        AUDIO_TASK_PRIORITY,
        nullptr,
        0
    );
}
