#pragma once
// =============================================================================
// config.h — Pin definitions, hardware constants, compile-time tuning knobs
// =============================================================================
// ⚠ FLAG: Verify every pin number against the actual board silkscreen before
//         soldering. The ESP32-S3 Supermini layout varies between vendors.
// ⚠ FLAG: Confirm e-paper driver chip from board markings before building.
// =============================================================================

// ---------------------------------------------------------------------------
// SD card — dedicated SPI bus (separate from e-paper)
//   Per GPIO Assignments.txt:
//     Silkscreen 02 (GPIO 2, Orange) = SD MOSI
//     Silkscreen 03 (GPIO 3, Blue)   = SD SCK
//     Silkscreen 01 (GPIO 1, White)  = SD MISO
//     Silkscreen 04 (GPIO 4, Green)  = SD CS
// ---------------------------------------------------------------------------
#define PIN_SD_MOSI     2
#define PIN_SD_SCK      3
#define PIN_SD_MISO     1
#define PIN_SD_CS       4

// ---------------------------------------------------------------------------
// E-paper display (SSD1675, 2.13" 250×122, GxEPD2_213_BN — Waveshare V4)
//   DIN = GPIO 43 (TX silkscreen)   CLK = GPIO 44 (RX silkscreen)
//   CS = GPIO 13   DC = GPIO 12   RST = GPIO 11   BUSY = GPIO 10
//   ⚠ TX/RX silkscreen pins repurposed as plain GPIO — native USB CDC
//     provides serial debug independent of UART0.
// ---------------------------------------------------------------------------
#define PIN_EPD_DIN     43
#define PIN_EPD_CLK     44
#define PIN_EPD_CS      13
#define PIN_EPD_DC      12
#define PIN_EPD_RST     11
#define PIN_EPD_BUSY    10

// ---------------------------------------------------------------------------
// I2S → PCM5102 DAC
//   Per GPIO Assignments.txt:
//     Silkscreen 07 (GPIO 7, Blue)   = DAC SCK
//     Silkscreen 06 (GPIO 6, Green)  = DAC BCK
//     Silkscreen 05 (GPIO 5, Yellow) = DAC DIN
//     Silkscreen 09 (GPIO 9, White)  = DAC LCK
//   Tie PCM5102 SCK to GND for auto-detection.
// ---------------------------------------------------------------------------
#define PIN_I2S_BCLK    6
#define PIN_I2S_WS      9    // LRCLK / LCK — per table: GPIO 9
#define PIN_I2S_DOUT    5
#define PIN_I2S_SCK     7    // system clock — tie to GND on PCM5102

// ---------------------------------------------------------------------------
// Rotary encoder
//   CLK = GPIO 18   DT = GPIO 17   SW = GPIO 16 (silkscreen "39")
// Per GPIO Assignments.txt:
//   Silkscreen 18 (GPIO 18, Green)  = Encoder CLK
//   Silkscreen 17 (GPIO 17, Black)  = Encoder DT
//   Silkscreen 16 (GPIO 16, Green)  = Encoder SW (NO)
// ---------------------------------------------------------------------------
#define PIN_ENC_A       18
#define PIN_ENC_B       17
#define PIN_ENC_SW      16

// ---------------------------------------------------------------------------
// Toggle switch — 3-position latching aircraft toggle
//   Up (next) = GPIO 14   Down (prev) = GPIO 15
// ---------------------------------------------------------------------------
#define PIN_TOGGLE_NEXT 14
#define PIN_TOGGLE_PREV 15

// ---------------------------------------------------------------------------
// Battery voltage ADC — GPIO 8 = ADC1_CH0 on ESP32-S3
// ---------------------------------------------------------------------------
#define PIN_BATT_ADC    8

// ---------------------------------------------------------------------------
// Display geometry
// ---------------------------------------------------------------------------
#define DISPLAY_WIDTH   250
#define DISPLAY_HEIGHT  122

// Music library root on the SD card. Use "/Music" for layouts such as
// /Music/<playlist>/; the persistent index remains in the SD root.
#define MUSIC_ROOT "/"

// Right-hand text region (full width minus margins)
#define TEXT_X          2
#define TEXT_W          (DISPLAY_WIDTH - TEXT_X - 2)

// Progress bar strip at the very bottom
#define PBAR_Y          (DISPLAY_HEIGHT - 12)
#define PBAR_H          12
#define PBAR_BAR_W      2
#define PBAR_MAX_H      12

// Battery indicator (top-right)
#define BATT_X          (DISPLAY_WIDTH - 42)
#define BATT_Y          0
#define BATT_W          36
#define BATT_H          9

// ---------------------------------------------------------------------------
// Audio
// ---------------------------------------------------------------------------
// ⚠ SAMPLE RATE: changed from 44100 to 48000. Diagnostic logging (added
//   during the static/garbled-audio investigation) showed nearly every MP3
//   in this library is actually 48kHz, not 44.1kHz. The I2S driver used to
//   install at 44100 on the FIRST track (this constant, used before any
//   file's real rate is known), then live-reconfigure to 48000Hz via
//   i2s_set_clk() once AudioGeneratorMP3 decoded the first frame and called
//   SetRate(48000) — and that same 44.1→48 dance repeated on EVERY track,
//   not just an occasional outlier. The live i2s_set_clk() call does change
//   the wire clock, but anything already sitting in the PCM ring buffer at
//   that moment was queued under the old rate assumption, and got played
//   out right after the clock switch — that's the source of the universal
//   static/garbled noise. Defaulting to the rate the library actually uses
//   means the FIRST install (in EQI2SOutput::begin(), before any reconfigure
//   logic runs at all) is correct for the common case, and the reconfigure
//   path (now hardened in audio.cpp to force a full reinstall + ring flush
//   instead of a live clock nudge) only has to handle genuine 44.1kHz
//   outliers, which will be rare based on what was observed.
#define SAMPLE_RATE     48000
#define I2S_PORT        I2S_NUM_0
#define I2S_DMA_BUF_COUNT 8
#define I2S_DMA_BUF_LEN 512
#define AUDIO_READ_BUF_SIZE (4 * 1024)
#define DEFAULT_VOLUME  70

// PCM ring buffer — elastic buffer between bursty MP3 decode and continuous I2S.
// 128 KB = 32768 stereo samples = 742 ms at 44100 Hz (power-of-2 for fast masking).
// Doubled from 64 KB to absorb bursty MP3 decode (2–5x real-time) without
// overflowing. Must be power of 2.  PSRAM preferred; will fall back to DRAM if needed.
#define PCM_BUF_SIZE_BYTES  (128 * 1024)

// ---------------------------------------------------------------------------
// Input timing (ms)
// ---------------------------------------------------------------------------
#define DEBOUNCE_MS          25
#define LONG_PRESS_MS        1000
#define TOGGLE_HOLD_MS       3000
#define TOGGLE_REPEAT_START  600
#define TOGGLE_REPEAT_MIN    200
#define TOGGLE_ACCEL_STEP    30

// ---------------------------------------------------------------------------
// Battery monitoring
// ---------------------------------------------------------------------------
#define BATT_DIVIDER_RATIO   1.4167f
#define BATT_ADC_REF_MV      3300
#define BATT_ADC_BITS        12
#define BATT_SAMPLE_EVERY_MS 20000

// ---------------------------------------------------------------------------
// E-paper partial-refresh ghosting budget
// ---------------------------------------------------------------------------
#define PARTIAL_REFRESH_GHOST_LIMIT  300

// ---------------------------------------------------------------------------
// IPC queue sizes (FreeRTOS)
// ---------------------------------------------------------------------------
#define AUDIO_CMD_QUEUE_DEPTH   8
#define UI_EVENT_QUEUE_DEPTH    16

// ---------------------------------------------------------------------------
// Splash / boot
// ---------------------------------------------------------------------------
#define SPLASH_DURATION_MS  2000
