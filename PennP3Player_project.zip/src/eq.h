#pragma once
// =============================================================================
// eq.h — Software EQ via biquad IIR filters (per-preset, precomputed)
// =============================================================================
// Each preset is a single biquad section applied to both L and R channels.
// Coefficients are computed once when the preset changes, not per-sample.
//
// Timing budget note (⚠ FLAG):
//   At 44100 Hz stereo the audio task processes ~512 samples per DMA buffer.
//   Each sample needs: 5 multiplies + 4 adds (float) per biquad stage.
//   On the ESP32-S3 Xtensa LX7 with HW FPU this is ~5 ns/op → ~50 ns/sample
//   → ~25 µs per 512-sample buffer for EQ alone.  That's comfortable alongside
//   MP3 decode (typically ~2–5 ms/frame) and I2S DMA (non-blocking).
//   If decode spikes, consider switching to integer fixed-point biquads.
//
// Design:
//   - Direct Form II transposed (numerically stable)
//   - 32-bit float coefficients
//   - Two state variables (w1, w2) per channel per stage
//   - Coefficients precomputed at 44100 Hz

#include <stdint.h>
#include "state.h"

// ---------------------------------------------------------------------------
// Biquad filter state
// ---------------------------------------------------------------------------
struct BiquadState {
    float w1L, w2L;   // left channel delay elements
    float w1R, w2R;   // right channel delay elements
};

// ---------------------------------------------------------------------------
// Biquad coefficients (Direct Form II transposed)
//   y[n] = b0*x[n] + w1[n-1]
//   w1    = b1*x[n] - a1*y[n] + w2[n-1]
//   w2    = b2*x[n] - a2*y[n]
// ---------------------------------------------------------------------------
struct BiquadCoeffs {
    float b0, b1, b2;   // feed-forward
    float a1, a2;        // feed-back (a0 normalised to 1)
};

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

// Update internal coefficients for the new preset.
// The audio task initializes the DSP to the default flat response.
void eqSetPreset(EQPreset preset);

// Process one stereo sample in-place.
// Inputs/outputs are -1.0 .. +1.0 floating point.
// Call this every sample from the audio task.
void eqProcess(float& sampleL, float& sampleR);

// Reset filter state (call on track change to prevent clicks).
void eqReset();

// Return coefficients for the currently active preset.
const BiquadCoeffs& eqGetCoeffs();

// Return currently active preset.
EQPreset eqGetPreset();
