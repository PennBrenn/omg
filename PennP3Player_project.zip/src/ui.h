#pragma once
// =============================================================================
// ui.h — UI state machine + screen rendering (Core 1)
// =============================================================================
// Owns the top-level PlayerState machine.  Consumes InputEvents from the
// input module and AudioEvents from the audio task, updates display.
//
// All display I/O happens here — never in the audio task.
//
// ⚠ INPUT ISOLATION ARCHITECTURE (refactored):
//   Input events are normalized by inputNormalize() in input.cpp based on
//   the current InputContext (PLAYBACK or MENU).  The UI layer sets the
//   input context via inputSetContext() on state transitions.
//   The UI layer receives ONLY normalized events:
//     NAV_UP, NAV_DOWN, NAV_ENTER, NAV_BACK     (MENU context only)
//     PLAY_PAUSE, SHOW_MENU                     (PLAYBACK context only)
//     TRACK_NEXT, TRACK_PREV                    (PLAYBACK context only)
//     VOLUME_UP, VOLUME_DOWN                    (PLAYBACK context, handled in main.cpp)
//   The UI NEVER interprets raw hardware events directly.
//   The UI NEVER queries input context for routing decisions.
//
// InputContext is defined in input.h — the single authoritative source.
// No duplicate InputContext declaration here.

#include <Arduino.h>
#include "state.h"
#include "input.h"

// ---------------------------------------------------------------------------
// Menu item IDs
// ---------------------------------------------------------------------------
enum class MenuItem : uint8_t {
    SLEEP_TIMER = 0,
    MUSIC_FOLDER,
    REINDEX_ALL,
    BACK,
    _COUNT
};

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

// Call once from setup() on Core 1 after display and storage are ready.
void uiInit();

// Main UI tick — call every loop iteration on Core 1.
// Consumes one InputEvent and any pending AudioEvents, updates state,
// triggers display redraws as needed.
void uiTick(InputEvent evt);

// Force a full redraw of the current screen (e.g. after boot).
void uiForceRedraw();

// Return current player state (read-only).
PlayerState uiGetState();