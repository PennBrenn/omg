// =============================================================================
// ui.cpp — UI state machine + screen rendering
// =============================================================================
// Rendering strategy (fixed: no paged loops in draw functions):
//   All draw*() functions write to the display buffer only.
//   The caller (uiTick) calls setFullWindow() + displayFullRefresh()
//   once, which performs the actual e-paper update.
//   This matches the working test code pattern: buffer → display(false).
// =============================================================================
//
// ⚠ INPUT ARCHITECTURE (refactored):
//   uiTick() receives NORMALIZED events from inputNormalize().
//   It NEVER handles raw hardware events (ENC_CW, TOGGLE_NEXT, etc.) directly.
//   On state transitions (PLAYBACK→MENU or MENU→PLAYBACK), it calls
//   inputSetContext() to update the routing context for inputNormalize().
//   This ensures:
//     - MENU context: only NAV_*/NAV_BACK events reach menu handlers
//     - PLAYBACK context: only PLAY_PAUSE/SHOW_MENU/TRACK_* events
//     - No UI state queries happen in input paths

#include "ui.h"
#include "display.h"
#include "storage.h"
#include "battery.h"
#include "config.h"
#include "state.h"
#include <Fonts/FreeSans9pt7b.h>

// =============================================================================
// Mini character bitmap — decorative icon shown above the song-length text
// =============================================================================
#define MINI_HEIGHT 40
#define MINI_WIDTH 49

// array size is 280  (7 bytes/row × 40 rows — required for 49×40 1bpp bitmap)
static const uint8_t mini[] = {
  0x03, 0xf9, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x03, 0xff, 0x80, 0x00, 0x00, 0x00, 0x00,
  0x3f, 0xff, 0xf8, 0x00, 0x00, 0x00, 0x00,
  0x4f, 0xff, 0xea, 0x00, 0x00, 0x00, 0x00,
  0x4f, 0xff, 0xff, 0x80, 0x00, 0x00, 0x00,
  0x4f, 0xff, 0xfe, 0x00, 0x00, 0x00, 0x00,
  0x7f, 0xff, 0xdf, 0xc0, 0x00, 0x00, 0x00,
  0x7f, 0xff, 0x0f, 0xe0, 0x00, 0x00, 0x00,
  0xff, 0xff, 0x8f, 0xf8, 0x00, 0x00, 0x00,
  0xbf, 0xff, 0x0f, 0xfe, 0x04, 0x00, 0x00,
  0x7f, 0x7f, 0xff, 0xff, 0xb4, 0x00, 0x00,
  0x37, 0xff, 0xff, 0xff, 0xf7, 0x00, 0x00,
  0x1d, 0xef, 0xff, 0xff, 0xf3, 0x00, 0x00,
  0x07, 0xf7, 0xff, 0x3f, 0xfe, 0x00, 0x00,
  0x01, 0xff, 0xf8, 0x3b, 0xff, 0xc0, 0x00,
  0x00, 0x7f, 0xd8, 0x71, 0xff, 0x00, 0x00,
  0x00, 0x1f, 0xc9, 0xf0, 0x7c, 0x00, 0x00,
  0x00, 0x1f, 0xff, 0xfc, 0xf8, 0x00, 0x00,
  0x00, 0x0f, 0xfe, 0x3f, 0x1c, 0x00, 0x00,
  0x00, 0x1e, 0xfb, 0xff, 0x1c, 0x00, 0x00,
  0x00, 0x7c, 0xfb, 0x7f, 0x7c, 0x00, 0x00,
  0x01, 0xf8, 0xfb, 0xef, 0xff, 0x80, 0x00,
  0x33, 0xc7, 0x7b, 0xec, 0x9f, 0x80, 0x00,
  0x39, 0xdf, 0xf1, 0xe7, 0x1f, 0x40, 0x00,
  0x7f, 0xdf, 0x7b, 0xaf, 0xff, 0x40, 0x00,
  0xff, 0xfc, 0x0f, 0xbf, 0xff, 0xd0, 0x00,
  0x3e, 0x58, 0x7d, 0xed, 0xfb, 0xf0, 0x00,
  0x70, 0x1f, 0x80, 0x0f, 0xea, 0x60, 0x00,
  0x37, 0xb2, 0x00, 0x04, 0x7e, 0x60, 0x00,
  0x03, 0xf8, 0x00, 0x0c, 0xe0, 0x10, 0x00,
  0x07, 0xd0, 0x00, 0x38, 0xe0, 0x18, 0x00,
  0x00, 0x40, 0x00, 0xff, 0xc0, 0x0c, 0x00,
  0x00, 0x00, 0x00, 0x7b, 0x80, 0x04, 0x00,
  0x00, 0x00, 0x00, 0x73, 0x80, 0x0e, 0x00,
  0x00, 0x00, 0x00, 0x03, 0x00, 0x23, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x60, 0x00,
};

// =============================================================================
// UI layout constants (local — not in config.h to avoid clutter)
// =============================================================================
// Volume indicator (below battery) — permanent "+XdB" text readout
static constexpr int16_t VOL_RIGHT_OFF_X  = 35;   // right edge offset from screen right
static constexpr int16_t VOL_BELOW_BATT_Y = 2;    // pixels below battery rect
static constexpr int16_t VOL_BAR_W        = 32;   // width of volume text region
static constexpr int16_t VOL_BAR_H        = 9;    // height of volume text region

// Play/pause icon (above progress bar)
static constexpr int16_t PBAR_LABEL_ABOVE = 10;   // time label baseline above progress bar
static constexpr int16_t PP_ABOVE_PBAR    = 11;   // icon baseline above progress bar
static constexpr int16_t PP_ICON_W        = 12;   // icon width
static constexpr int16_t PP_ICON_H        = 10;   // icon height
// Menu layout
static constexpr int16_t MENU_SEP_Y       = 16;   // y of separator line below header
static constexpr int16_t MENU_ITEM_Y0     = 27;   // y of first menu item (moved down 6px = 0.75× font height to clear separator)
static constexpr int16_t MENU_SPACING     = 12;   // spacing between menu items (0.75× original 16)
static constexpr int16_t MENU_TEXT_X      = 4;    // left margin for menu text
static constexpr int16_t MENU_ASTERISK_R  = 10;   // asterisk right offset from screen right

// =============================================================================
// Layout system — anchor-based 2D positioning with regions, margins, & sizing
// =============================================================================

// -- Geometry primitives ------------------------------------------------------
struct UIPoint  { int16_t x, y; };
struct UISize   { int16_t w, h; };
struct UIRect   { int16_t x, y, w, h; };
struct UIInsets { int16_t t, r, b, l; };  // top, right, bottom, left

// -- Alignment helper for text within a rect ----------------------------------
enum class UITextAlign : uint8_t {
    LEFT,   // x is left edge (default)
    CENTER, // x is horizontal center
    RIGHT   // x is right edge
};

enum class UITextVAlign : uint8_t {
    BASELINE, // y is baseline (default)
    MIDDLE,   // y is vertical middle of text
    TOP       // y is top of text
};

// Draw text aligned within a rect — safe with null or empty str (no-op)
static void drawAlignedText(const UIRect& r, const char* str,
                            const GFXfont* font = nullptr,
                            UITextAlign halign = UITextAlign::LEFT,
                            UITextVAlign valign = UITextVAlign::BASELINE,
                            uint16_t color = GxEPD_BLACK,
                            int16_t padX = 0, int16_t padY = 0) {
    if (!str || !*str) return;
    int16_t tx = r.x + padX;
    int16_t ty = r.y + padY;

    int16_t tw = displayTextWidth(str, font);
    int16_t th = (font == nullptr) ? 8 : font->yAdvance; // real line height — avoids title-line overlap

    switch (halign) {
        case UITextAlign::CENTER: tx = r.x + r.w/2 - tw/2; break;
        case UITextAlign::RIGHT:  tx = r.x + r.w - tw - padX; break;
        default: break;
    }

    switch (valign) {
        case UITextVAlign::MIDDLE: ty = r.y + r.h/2 + th/3; break; // th/3 approximates baseline offset
        case UITextVAlign::TOP:    ty = r.y + th; break;
        default: break;
    }

    displayText(tx, ty, str, font, color);
}

// Fill a rect with an optional border
static void drawFilledRect(const UIRect& r, uint16_t color = GxEPD_BLACK,
                           bool border = false, uint16_t borderColor = GxEPD_BLACK) {
    if (r.w <= 0 || r.h <= 0) return;
    displayFillRect(r.x, r.y, r.w, r.h, color);
    if (border) {
        displayRect(r.x, r.y, r.w, r.h, borderColor);
    }
}

// Clear a rect region
static void clearRect(const UIRect& r) {
    if (r.w <= 0 || r.h <= 0) return;
    displayFillRect(r.x, r.y, r.w, r.h, GxEPD_WHITE);
}

// =============================================================================
// Region definitions — all layout regions computed from display dimensions
// =============================================================================

// -- Top-level screen regions -------------------------------------------------
static UIRect s_screenRect = {0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT};
static UIRect s_textRect;       // text region (left-aligned, above progress bar)
static UIRect s_pbarRect;       // progress bar at bottom of screen
static UIRect s_pbarLabelTop;   // space used by time labels above bar
static UIRect s_battRect;       // battery indicator (top-right)
static UIRect s_volRect;        // volume indicator (below battery)
static UIRect s_ppRect;         // play/pause icon (above progress bar)

// -- Text sub-regions ---------------------------------------------------------
static UIRect s_title1Rect, s_title2Rect, s_title3Rect, s_artistRect, s_ctrRect;

// -- Menu regions -------------------------------------------------------------
static UIRect s_menuHeaderRect;
static UIRect s_menuSepRect;

// -- Error screen regions -----------------------------------------------------
static int16_t s_errTextX;
static int16_t s_errTextY;

// -- Rebuilding screen regions ------------------------------------------------
static UIRect s_rebuildTextRect;
static UIRect s_rebuildProgRect;
static int16_t s_rebuildResY;

// =============================================================================
// Compute all layout regions from display dimensions
// =============================================================================
static void recomputeAllLayouts() {
    // Text region: left-aligned, above progress bar
    s_textRect.x = TEXT_X;
    s_textRect.y = 2; // small top padding
    s_textRect.w = TEXT_W;
    s_textRect.h = PBAR_Y - s_textRect.y - 2; // up to progress bar

    // Progress bar strip
    s_pbarRect.x = 0;
    s_pbarRect.y = PBAR_Y;
    s_pbarRect.w = DISPLAY_WIDTH;
    s_pbarRect.h = PBAR_H;

    // Time label zone (above progress bar)
    s_pbarLabelTop.x = 0;
    s_pbarLabelTop.y = PBAR_Y - 10;
    s_pbarLabelTop.w = DISPLAY_WIDTH;
    s_pbarLabelTop.h = 10;

    // Battery indicator
    s_battRect.x = DISPLAY_WIDTH - 44;
    s_battRect.y = 0;
    s_battRect.w = 42;
    s_battRect.h = 9;

    // Volume indicator
    s_volRect.x = DISPLAY_WIDTH - VOL_RIGHT_OFF_X;
    s_volRect.y = BATT_Y + BATT_H + VOL_BELOW_BATT_Y;
    s_volRect.w = VOL_BAR_W;
    s_volRect.h = VOL_BAR_H;

    // Play/pause icon — moved 3× its width to the right to avoid overlapping
    // with the elapsed-time label at the left edge.
    s_ppRect.x = TEXT_X + PP_ICON_W * 3;
    s_ppRect.y = PBAR_Y - PP_ABOVE_PBAR;
    s_ppRect.w = PP_ICON_W;
    s_ppRect.h = PP_ICON_H;

    // Text sub-regions (within text rect) — explicit casts avoid narrowing warnings
    // Title lines use the font's real line height (yAdvance) instead of a
    // guessed constant, and are narrowed to stop before the battery/volume
    // indicators in the top-right corner so long titles don't run under them.
    const int16_t titleLineH = FreeSans9pt7b.yAdvance;
    const int16_t titleSafeW = (int16_t)(s_battRect.x - s_textRect.x - 4);
    // Title lines: moved up by 0.5× line height (half the previous offset) and
    // support up to 3 wrapped lines. Artist is always below the last title line.
    s_title1Rect = {s_textRect.x, (int16_t)(s_textRect.y - titleLineH / 2),              titleSafeW,   titleLineH};
    s_title2Rect = {s_textRect.x, (int16_t)(s_title1Rect.y + titleLineH),                titleSafeW,   titleLineH};
    s_title3Rect = {s_textRect.x, (int16_t)(s_title2Rect.y + titleLineH),                titleSafeW,   titleLineH};
    s_artistRect = {s_textRect.x, (int16_t)(s_title3Rect.y + titleLineH),                s_textRect.w, 12};
    s_ctrRect    = {s_textRect.x, (int16_t)(PBAR_Y - PBAR_LABEL_ABOVE - 12),              s_textRect.w, 10};

    // Menu regions — header text moved up by 1× its original y (y=0), but
    // separator and menu items stay at their original positions.
    s_menuHeaderRect = {2, 13, DISPLAY_WIDTH, 14};
    s_menuSepRect    = {0, MENU_SEP_Y, DISPLAY_WIDTH, 1};

    // Error screen
    s_errTextX = DISPLAY_WIDTH / 2;
    s_errTextY = DISPLAY_HEIGHT / 2;

    // Rebuilding screen
    s_rebuildTextRect = {4, 4, DISPLAY_WIDTH - 8, 14};
    s_rebuildProgRect = {4, 40, DISPLAY_WIDTH - 8, 10};
    s_rebuildResY     = DISPLAY_HEIGHT / 2;
}

// ---------------------------------------------------------------------------
// Module state
// ---------------------------------------------------------------------------
static PlayerState s_state = PlayerState::BOOT;

static int      s_trackIndex   = 0;
static uint32_t s_positionMs   = 0;
static uint32_t s_durationMs   = 0;
static int      s_volume       = DEFAULT_VOLUME;
static bool     s_playing      = false;
enum class MenuPage : uint8_t { UTILITIES, SLEEP_TIMER, MUSIC_FOLDER };
static MenuPage s_menuPage = MenuPage::UTILITIES;
static int s_menuSel = 0;
static int s_sleepSel = 0;
static int s_folderSel = 0;
static int s_folderFirstVisible = 0;
static bool s_sleepActive = false;
static uint32_t s_sleepDeadline = 0;
static uint32_t s_sleepDuration = 0;
static int s_sleepShownMinute = -1;
static bool s_sleepIndicatorDirty = false;

static int  s_prevMenuSel  = 0;

static int  s_rebuildCurrent = 0;

static bool s_dirtyProgress  = false;
static bool s_dirtyVolume    = false;
static bool s_dirtyPlayPause = false;
static bool s_needFullRedraw = false;
static bool s_menuDirty      = false;  // menu cursor moved — partial refresh only

static uint32_t s_lastBattMs = 0;

static void drawNowPlaying();
static void drawMenu();
static void drawError(const char* msg);
static void drawRebuilding();
static void drawProgressBar();
static void drawBatteryIndicator();
static void drawSleepIndicator();
static void drawVolumeIndicator();
static void drawPlayPauseIcon();
static void formatTime(uint32_t ms, char* buf, size_t len);

// Cursor overlay helpers (defined after drawMenu, but called from uiTick)
static void drawCursorAt(int16_t y);
static void clearCursorAt(int16_t y);
static int16_t getCursorY();
static int16_t getPrevCursorY();

// ---------------------------------------------------------------------------
// Sync input context with UI state — called on state transitions
// ---------------------------------------------------------------------------
static void syncInputContext() {
    if (s_state == PlayerState::MENU) {
        inputSetContext(InputContext::MENU);
    } else if (s_state == PlayerState::NOW_PLAYING) {
        inputSetContext(InputContext::PLAYBACK);
    } else {
        inputSetContext(InputContext::OTHER);
    }
}

void uiInit() {
    s_state          = PlayerState::BOOT;
    s_needFullRedraw = true;
    s_lastBattMs     = 0;
    recomputeAllLayouts();
    syncInputContext();
}

PlayerState uiGetState() { return s_state; }
void uiForceRedraw() { s_needFullRedraw = true; }

static void drainAudioEvents() {
    AudioEvent evt;
    while (recvAudioEvent(evt, 0)) {
        switch (evt.type) {
            case AudioEventType::TRACK_STARTED:
                // If still in BOOT state, the first TRACK_STARTED transitions
                // to NOW_PLAYING so the splash screen stays visible until
                // audio actually starts playing.
                if (s_state == PlayerState::BOOT) {
                    s_state = PlayerState::NOW_PLAYING;
                    syncInputContext();
                }
                s_trackIndex  = evt.trackIndex;
                s_positionMs  = 0;
                s_durationMs  = evt.durationMs;
                s_playing     = true;
                s_needFullRedraw = true;
                displayRequestFullRefresh();
                {
                    char path[PATH_LEN];
                    if (getTrackPath(evt.trackIndex, path, sizeof(path))) {
                        Serial.printf("[player] Now playing: %s\n", path);
                    }
                }
                break;
            case AudioEventType::TRACK_ENDED:
                s_playing = false;
                break;
            case AudioEventType::PLAYBACK_PAUSED:
                s_playing = false;
                s_dirtyPlayPause = true;
                break;
            case AudioEventType::PLAYBACK_RESUMED:
                s_playing = true;
                s_dirtyPlayPause = true;
                break;
            case AudioEventType::POSITION_UPDATE:
                s_positionMs  = evt.positionMs;
                s_durationMs  = evt.durationMs;
                s_dirtyProgress = true;
                break;
            case AudioEventType::VOLUME_CHANGED:
                s_volume = (int)evt.value;
                s_dirtyVolume = true;
                break;
            case AudioEventType::ERROR_FILE:
                Serial.printf("[ui] Audio error on track %d\n", evt.trackIndex);
                break;
            default: break;
        }
    }
}

// ---------------------------------------------------------------------------
// Normalized event handlers — receive already-context-routed events
// ---------------------------------------------------------------------------

static void handleNowPlayingInput(InputEvent evt) {
    switch (evt) {
        // ⚠ These are NORMALIZED events from inputNormalize().
        //   The router has already determined the correct action based on
        //   the current InputContext (PLAYBACK).  No raw events here.
        case InputEvent::PLAY_PAUSE:
            sendAudioCmd(s_playing ? AudioCmdType::PAUSE : AudioCmdType::RESUME);
            break;
        case InputEvent::SHOW_MENU:
            s_state      = PlayerState::MENU;
            s_menuSel    = 0;
            s_menuPage   = MenuPage::UTILITIES;
            s_needFullRedraw = true;
            syncInputContext();
            break;
        case InputEvent::TRACK_NEXT:
            sendAudioCmd(AudioCmdType::NEXT_TRACK);
            break;
        case InputEvent::TRACK_PREV:
            sendAudioCmd(AudioCmdType::PREV_TRACK);
            break;
        // VOLUME_UP/DOWN are handled in main.cpp fast path, but may arrive
        // here too (buffered).  Ignore them — s_volume is updated by
        // VOLUME_CHANGED audio event.
        case InputEvent::VOLUME_UP:
        case InputEvent::VOLUME_DOWN:
            break;
        // Menu navigation events should never arrive in PLAYBACK context.
        // If they do, ignore them.
        case InputEvent::NAV_UP:
        case InputEvent::NAV_DOWN:
        case InputEvent::NAV_ENTER:
        case InputEvent::NAV_BACK:
        default:
            break;
    }
}

static const uint32_t SLEEP_PRESETS_MS[] = {0, 5UL * 60UL * 1000UL, 30UL * 60UL * 1000UL, 60UL * 60UL * 1000UL};
static const char* SLEEP_LABELS[] = {"Off", "5 min", "30 min", "1 hour"};

static void reportReindexProgress(int indexedTracks) {
    s_rebuildCurrent = indexedTracks;
    display().setFullWindow();
    drawRebuilding();
    displayFullRefresh();
}

static void exitMenuToPlayback() {
    s_state = PlayerState::NOW_PLAYING;
    s_menuPage = MenuPage::UTILITIES;
    syncInputContext();
    s_needFullRedraw = true;
    displayRequestFullRefresh();
}

static void handleMenuInput(InputEvent evt) {
    const int folderCount = storageFolderCount();
    int itemCount = s_menuPage == MenuPage::UTILITIES ? (int)MenuItem::_COUNT
                  : s_menuPage == MenuPage::SLEEP_TIMER ? 4 : folderCount;
    if (s_menuPage == MenuPage::MUSIC_FOLDER && itemCount == 0) itemCount = 1;
    switch (evt) {
        case InputEvent::NAV_UP:
            if (itemCount > 0) {
                int* selected = s_menuPage == MenuPage::UTILITIES ? &s_menuSel
                              : s_menuPage == MenuPage::SLEEP_TIMER ? &s_sleepSel : &s_folderSel;
                *selected = (*selected - 1 + itemCount) % itemCount;
                if (s_menuPage == MenuPage::MUSIC_FOLDER) {
                    if (s_folderSel < s_folderFirstVisible) s_folderFirstVisible = s_folderSel;
                    if (s_folderSel >= s_folderFirstVisible + 7) s_folderFirstVisible = s_folderSel - 6;
                }
                s_menuDirty = true;
            }
            break;
        case InputEvent::NAV_DOWN:
            if (itemCount > 0) {
                int* selected = s_menuPage == MenuPage::UTILITIES ? &s_menuSel
                              : s_menuPage == MenuPage::SLEEP_TIMER ? &s_sleepSel : &s_folderSel;
                *selected = (*selected + 1) % itemCount;
                if (s_menuPage == MenuPage::MUSIC_FOLDER) {
                    if (s_folderSel < s_folderFirstVisible) s_folderFirstVisible = s_folderSel;
                    if (s_folderSel >= s_folderFirstVisible + 7) s_folderFirstVisible = s_folderSel - 6;
                }
                s_menuDirty = true;
            }
            break;
        case InputEvent::NAV_ENTER:
            if (s_menuPage == MenuPage::UTILITIES) {
                switch ((MenuItem)s_menuSel) {
                    case MenuItem::SLEEP_TIMER:
                        s_sleepSel = 0;
                        for (int i = 0; i < 4; ++i)
                            if (SLEEP_PRESETS_MS[i] == s_sleepDuration && s_sleepActive) s_sleepSel = i;
                        if (!s_sleepActive) s_sleepSel = 0;
                        s_menuPage = MenuPage::SLEEP_TIMER;
                        s_needFullRedraw = true;
                        break;
                    case MenuItem::MUSIC_FOLDER:
                        s_menuPage = MenuPage::MUSIC_FOLDER;
                        s_folderSel = 0;
                        s_folderFirstVisible = 0;
                        for (int i = 0; i < folderCount; ++i) {
                            char folder[PATH_LEN];
                            if (storageGetFolderName(i, folder, sizeof(folder)) && strcmp(folder, storageSelectedFolder()) == 0) {
                                s_folderSel = i;
                                break;
                            }
                        }
                        s_folderFirstVisible = max(0, s_folderSel - 6);
                        s_needFullRedraw = true;
                        break;
                    case MenuItem::REINDEX_ALL: {
                        bool wasPlaying = s_playing;
                        sendAudioCmd(AudioCmdType::PAUSE);
                        s_state = PlayerState::REBUILDING_INDEX;
                        syncInputContext();
                        s_rebuildCurrent = 0;
                        display().setFullWindow();
                        drawRebuilding();
                        displayFullRefresh();
                        int newCount = storageReindexAll(reportReindexProgress);
                        if (newCount > 0) {
                            if (s_trackIndex < 0 || s_trackIndex >= newCount) s_trackIndex = 0;
                            sendAudioCmd(AudioCmdType::PLAY_TRACK, s_trackIndex);
                            if (!wasPlaying) sendAudioCmd(AudioCmdType::PAUSE);
                        }
                        Serial.printf("[ui] Reindex complete: %d tracks in %s\n", newCount, storageSelectedFolder());
                        display().setFullWindow();
                        displayClear();
                        drawAlignedText({0, s_rebuildResY, DISPLAY_WIDTH, 14},
                                        newCount > 0 ? "Index rebuilt OK" : "No MP3 files found",
                                        &FreeSans9pt7b, UITextAlign::CENTER, UITextVAlign::TOP);
                        char buf[32]; snprintf(buf, sizeof(buf), "%d tracks", newCount);
                        drawAlignedText({0, (int16_t)(s_rebuildResY + 16), DISPLAY_WIDTH, 10}, buf, nullptr,
                                        UITextAlign::CENTER, UITextVAlign::TOP);
                        displayFullRefresh();
                        delay(700);
                        s_state = PlayerState::MENU;
                        s_menuPage = MenuPage::UTILITIES;
                        syncInputContext();
                        s_needFullRedraw = true;
                        break;
                    }
                    case MenuItem::BACK: exitMenuToPlayback(); break;
                    default: break;
                }
            } else if (s_menuPage == MenuPage::SLEEP_TIMER) {
                s_sleepDuration = SLEEP_PRESETS_MS[s_sleepSel];
                s_sleepActive = s_sleepDuration != 0;
                s_sleepDeadline = s_sleepActive ? millis() + s_sleepDuration : 0;
                s_sleepShownMinute = -1;
                s_sleepIndicatorDirty = true;
                s_menuPage = MenuPage::UTILITIES;
                s_needFullRedraw = true;
            } else {
                char folder[PATH_LEN];
                if (storageGetFolderName(s_folderSel, folder, sizeof(folder)) && storageSelectFolder(folder)) {
                    sendAudioCmd(AudioCmdType::PAUSE);
                    s_trackIndex = 0;
                    s_positionMs = 0;
                    if (getTrackCount() > 0) {
                        sendAudioCmd(AudioCmdType::PLAY_TRACK, 0);
                        s_playing = true;
                    }
                    saveLastPlayed(0, 0);
                }
                s_menuPage = MenuPage::UTILITIES;
                s_needFullRedraw = true;
            }
            break;
        case InputEvent::NAV_BACK:
            if (s_menuPage != MenuPage::UTILITIES) {
                s_menuPage = MenuPage::UTILITIES;
                s_needFullRedraw = true;
            } else exitMenuToPlayback();
            break;
        default: break;
    }
}

void uiTick(InputEvent evt) {
    drainAudioEvents();

    uint32_t now = millis();
    if (s_sleepActive) {
        if ((int32_t)(now - s_sleepDeadline) >= 0) {
            s_sleepActive = false;
            s_sleepDuration = 0;
            s_sleepDeadline = 0;
            if (s_playing) sendAudioCmd(AudioCmdType::PAUSE);
            s_sleepIndicatorDirty = true;
        } else {
            int remainingMinute = (int)((s_sleepDeadline - now + 59999UL) / 60000UL);
            if (remainingMinute != s_sleepShownMinute) {
                s_sleepShownMinute = remainingMinute;
                s_sleepIndicatorDirty = true;
            }
        }
    }
    if (now - s_lastBattMs >= BATT_SAMPLE_EVERY_MS) {
        s_lastBattMs = now;
        batteryUpdate();
        s_dirtyVolume = true;
    }

    // BOOT — stay in BOOT state (splash screen stays visible) until
    //         the first TRACK_STARTED audio event arrives.
    //         A timeout forces transition after 10 s so the player is
    //         never stuck on splash permanently if audio never starts.
    static uint32_t s_bootStartMs = 0;
    if (s_state == PlayerState::BOOT) {
        if (s_bootStartMs == 0) {
            s_bootStartMs = now;
        }
        // Timeout: transition even without TRACK_STARTED after 10 seconds
        if (now - s_bootStartMs > 10000) {
            Serial.println("[ui] BOOT timeout (10 s) — forcing NOW_PLAYING");
            s_state = PlayerState::NOW_PLAYING;
            syncInputContext();
            s_needFullRedraw = true;
        }
        // While BOOT, skip all rendering (splash is already on the display
        // from setup()).  Input is also ignored during boot.
        return;
    }

    // Error states
    if (s_state == PlayerState::ERROR_NO_SD && s_needFullRedraw) {
        display().setFullWindow();
        drawError("No SD card");
        displayFullRefresh();
        s_needFullRedraw = false;
        return;
    }
    if (s_state == PlayerState::ERROR_NO_TRACKS && s_needFullRedraw) {
        display().setFullWindow();
        drawError("No MP3 files");
        displayFullRefresh();
        s_needFullRedraw = false;
        return;
    }

    // Handle input — evt is ALREADY a normalized event from inputNormalize()
    if (evt != InputEvent::NONE) {
        if (s_state == PlayerState::NOW_PLAYING)
            handleNowPlayingInput(evt);
        else if (s_state == PlayerState::MENU)
            handleMenuInput(evt);
        // REBUILDING_INDEX and ERROR states: ignore input
    }

    // UI render
    if (s_state == PlayerState::MENU) {
        if (s_needFullRedraw) {
            display().setFullWindow();
            drawMenu();
            displayFullRefresh();
            s_needFullRedraw = false;
            s_menuDirty      = false;
        } else if (s_menuDirty) {
            // ⚠ CURSOR MOVE — overlay approach: labels are drawn once and
            //   never change.  Only the cursor triangle moves.  We clear the
            //   old cursor area (small white rect), then draw the new cursor.
            //   The labels themselves do NOT change — no ghosting from label
            //   text, and the cursor area is tiny (10x10px), so partial
            //   refresh works reliably even on e-paper.
            int16_t oldY = getPrevCursorY();
            int16_t newY = getCursorY();
            // Erase old cursor (white fill) — only if it differs from new
            if (oldY != newY) {
                clearCursorAt(oldY);
            }
            // Draw new cursor
            drawCursorAt(newY);
            displayPartialRefresh();
            // Update previous selection trackers
            s_prevMenuSel  = s_menuSel;
            s_menuDirty = false;
        }
    } else {
        if (s_needFullRedraw) {
            display().setFullWindow();
            recomputeAllLayouts();
            drawNowPlaying();
            displayFullRefresh();
            s_needFullRedraw    = false;
            s_dirtyProgress     = false;
            s_dirtyVolume       = false;
            s_dirtyPlayPause    = false;
            s_sleepIndicatorDirty = false;
        } else if (s_dirtyProgress || s_dirtyVolume || s_dirtyPlayPause || s_sleepIndicatorDirty) {
            if (s_dirtyProgress)  drawProgressBar();
            if (s_dirtyVolume)    drawVolumeIndicator();
            if (s_dirtyPlayPause) drawPlayPauseIcon();
            if (s_sleepIndicatorDirty) drawSleepIndicator();
            displayPartialRefresh();
            s_dirtyProgress  = false;
            s_dirtyVolume    = false;
            s_dirtyPlayPause = false;
            s_sleepIndicatorDirty = false;
        }
    }
}

static void formatTime(uint32_t ms, char* buf, size_t len) {
    uint32_t secs = ms / 1000, mins = secs / 60; secs %= 60;
    snprintf(buf, len, "%lu:%02lu", (unsigned long)mins, (unsigned long)secs);
}

// ====== DRAW FUNCTIONS — buffer only, no paged loops ======

static void drawError(const char* msg) {
    displayClear();
    drawAlignedText({0, (int16_t)(s_errTextY - 14), DISPLAY_WIDTH, 28}, msg, &FreeSans9pt7b,
                    UITextAlign::CENTER, UITextVAlign::MIDDLE);
}

static void drawRebuilding() {
    displayClear();
    drawAlignedText(s_rebuildTextRect, "Rebuilding index...", &FreeSans9pt7b,
                    UITextAlign::LEFT, UITextVAlign::TOP);
    char buf[40];
    snprintf(buf, sizeof(buf), "%d tracks found", s_rebuildCurrent);
    drawAlignedText(s_rebuildProgRect, buf, nullptr,
                    UITextAlign::LEFT, UITextVAlign::TOP);
}

static void drawBatteryIndicator() {
    float volts = batteryGetVolts();
    int pct     = batteryGetPercent();
    const UIRect& r = s_battRect;

    char vbuf[10];
    snprintf(vbuf, sizeof(vbuf), "%.1fv", volts);
    displayText(r.x, r.y, vbuf, nullptr);

    int barX = r.x + 28;
    int barY = r.y + 1;
    int barW = 12;
    int barH = 7;

    displayRect(barX, barY, barW, barH);
    displayFillRect(barX + barW, barY + 2, 2, 3); // tip
    int segs = (pct * 5 + 99) / 100;
    for (int i = 0; i < segs; i++)
        displayFillRect(barX + 1 + i * 2, barY + 1, 2, 5);
}

static void drawVolumeIndicator() {
    const UIRect& r = s_volRect;
    UIRect glyphArea = { r.x, (int16_t)(r.y + r.h - 1), r.w, 8 };
    clearRect(glyphArea);

    int db = (s_volume * 30) / 100;
    char buf[12];
    snprintf(buf, sizeof(buf), "+%ddB", db);
    displayText(r.x, r.y + r.h - 1, buf, nullptr);
}

static void drawPlayPauseIcon() {
    const UIRect& r = s_ppRect;
    clearRect(r);
    if (s_playing) {
        display().fillTriangle(r.x, r.y, r.x, r.y + r.h - 1,
                               r.x + r.w - 4, r.y + r.h / 2 - 1, GxEPD_BLACK);
    } else {
        int barW = 3, gap = 2;
        displayFillRect(r.x, r.y, barW, r.h - 1);
        displayFillRect(r.x + barW + gap, r.y, barW, r.h - 1);
    }
}

// Progress bar: fixed 15-segment bell-curve kernel overlay
static const uint8_t BAR_KERNEL[15] = {0,0,0,0,0,3,6,10,6,3,0,0,0,0,0};
static const int8_t  KERNEL_CENTER   = 7;
static const int     PBAR_N_SEGMENTS = 15;

static void drawProgressBar() {
    clearRect(s_pbarRect);
    clearRect(s_pbarLabelTop);

    char elapsed[12], total[12];
    formatTime(s_positionMs, elapsed, sizeof(elapsed));
    formatTime(s_durationMs, total, sizeof(total));

    const int16_t labelBaseY = PBAR_Y - PBAR_LABEL_ABOVE;
    displayText(2, labelBaseY, elapsed, nullptr);
    int16_t tw = displayTextWidth(total, nullptr);
    displayText(DISPLAY_WIDTH - tw - 2, labelBaseY, total, nullptr);

    // Draw decorative character bitmap above the song-length (total) text
    const int16_t miniX = DISPLAY_WIDTH - MINI_WIDTH - 2;   // right-aligned, 2px margin
    const int16_t miniY = labelBaseY - MINI_HEIGHT - 1;     // 1px gap above text baseline
    // Clear the bitmap area (in case of partial refresh)
    displayFillRect(miniX, miniY, MINI_WIDTH, MINI_HEIGHT, GxEPD_WHITE);
    displayBitmap(miniX, miniY, MINI_WIDTH, MINI_HEIGHT, mini);

    int16_t labelW = displayTextWidth("0:00", nullptr) + 4;
    int16_t barLeft   = labelW;
    int16_t barRight  = DISPLAY_WIDTH - labelW;
    int16_t barWidth  = barRight - barLeft;
    if (barWidth <= 0) return;

    int16_t gap    = 1;
    int16_t segW   = (barWidth - (PBAR_N_SEGMENTS - 1) * gap) / PBAR_N_SEGMENTS;
    if (segW < 1) segW = 1;
    int16_t used   = segW * PBAR_N_SEGMENTS + (PBAR_N_SEGMENTS - 1) * gap;
    int16_t x0     = barLeft + (barWidth - used) / 2;

    uint32_t centerIdx = 0;
    if (s_durationMs > 0) {
        centerIdx = s_positionMs * (PBAR_N_SEGMENTS - 1) / s_durationMs;
        if (centerIdx > (uint32_t)(PBAR_N_SEGMENTS - 1)) centerIdx = PBAR_N_SEGMENTS - 1;
    }

    uint8_t heights[PBAR_N_SEGMENTS] = {0};
    for (int i = 0; i < PBAR_N_SEGMENTS; i++) {
        int barIdx = (int)centerIdx + (i - KERNEL_CENTER);
        if (barIdx >= 0 && barIdx < PBAR_N_SEGMENTS) {
            if (BAR_KERNEL[i] > heights[barIdx]) {
                heights[barIdx] = BAR_KERNEL[i];
            }
        }
    }

    for (int i = 0; i < PBAR_N_SEGMENTS; i++) {
        if (heights[i] > 0) {
            displayFillRect(x0 + i * (segW + gap), PBAR_Y + PBAR_H - heights[i], segW, heights[i]);
        }
    }
}

static void drawNowPlaying() {
    displayClear();

    drawBatteryIndicator();
    drawVolumeIndicator();
    drawPlayPauseIcon();
    drawProgressBar();
    drawSleepIndicator();

    IndexEntry entry;
    bool haveEntry = (s_trackIndex >= 0 && getIndexEntry(s_trackIndex, entry));
    if (haveEntry) {
        char titleL1[TITLE_LEN], titleL2[TITLE_LEN], titleL3[TITLE_LEN];
        char artistBuf[ARTIST_LEN];

        // Wrap title into up to 3 lines: first pass splits line1 / remainder,
        // second pass splits the remainder into line2 / line3.
        displayWrapText(entry.title, s_title1Rect.w, &FreeSans9pt7b,
                        titleL1, titleL2, sizeof(titleL1));
        titleL3[0] = '\0';
        if (titleL2[0] != '\0') {
            char wrappedL2[TITLE_LEN], wrappedL3[TITLE_LEN];
            displayWrapText(titleL2, s_title1Rect.w, &FreeSans9pt7b,
                            wrappedL2, wrappedL3, sizeof(wrappedL2));
            strncpy(titleL2, wrappedL2, sizeof(titleL2) - 1);
            titleL2[sizeof(titleL2) - 1] = '\0';
            if (wrappedL3[0] != '\0') {
                displayTruncate(wrappedL3, s_title1Rect.w, &FreeSans9pt7b,
                                titleL3, sizeof(titleL3));
            }
        }
        displayTruncate(entry.artist, s_textRect.w, nullptr,
                        artistBuf, sizeof(artistBuf));

        drawAlignedText(s_title1Rect, titleL1, &FreeSans9pt7b,
                        UITextAlign::LEFT, UITextVAlign::TOP);

        if (titleL2[0] != '\0') {
            drawAlignedText(s_title2Rect, titleL2, &FreeSans9pt7b,
                            UITextAlign::LEFT, UITextVAlign::TOP);
        }
        if (titleL3[0] != '\0') {
            drawAlignedText(s_title3Rect, titleL3, &FreeSans9pt7b,
                            UITextAlign::LEFT, UITextVAlign::TOP);
        }
        drawAlignedText(s_artistRect, artistBuf, nullptr,
                        UITextAlign::LEFT, UITextVAlign::TOP);

        char ctr[24];
        snprintf(ctr, sizeof(ctr), "%d/%d", s_trackIndex + 1, getTrackCount());
        displayText(s_ctrRect.x, s_ctrRect.y, ctr, nullptr);

        int16_t cx = s_ctrRect.x + displayTextWidth(ctr, nullptr) + 4;

        static const char* repeatIcons[] = {"", "R1", "RA", "SH"};
        if (gConfig.repeatMode != RepeatMode::NONE) {
            displayText(cx, s_ctrRect.y,
                        repeatIcons[(int)gConfig.repeatMode], nullptr);
        }
    }
}

// Cursor overlay constants
static constexpr int16_t CURSOR_X      = 2;    // x-position of cursor char
static constexpr int16_t CURSOR_W      = 10;   // width of cursor area
static constexpr int16_t CURSOR_H      = 10;   // height of cursor bounding box
// Default GFX font renders with y = top of glyph, height = 8px.
// To center a CURSOR_H=10 triangle on an 8px glyph: offset = (8 - 10) / 2 = -1
static constexpr int16_t CURSOR_Y_OFF  = -1;   // centers 10px triangle on 8px glyph: top = y-1, mid = y+4

// Helper: draw a filled triangle cursor at a menu item row.
// 'y' is the top of the text glyph (default font, y = top-left).
static void drawCursorAt(int16_t y) {
    int16_t top = y + CURSOR_Y_OFF;
    display().fillTriangle(CURSOR_X,                 top,
                           CURSOR_X,                 top + CURSOR_H - 1,
                           CURSOR_X + CURSOR_W - 4,  top + CURSOR_H / 2,
                           GxEPD_BLACK);
}

// Helper: clear the cursor area at a menu item row (erase old cursor)
static void clearCursorAt(int16_t y) {
    int16_t top = y + CURSOR_Y_OFF;
    displayFillRect(CURSOR_X, top, CURSOR_W, CURSOR_H, GxEPD_WHITE);
}

// Menu rows use a fixed seven-row viewport, enough for the small utility pages.
static int16_t getMenuItemY(int idx) { return MENU_ITEM_Y0 + idx * MENU_SPACING; }
static int16_t getCursorY() {
    int selected = s_menuPage == MenuPage::UTILITIES ? s_menuSel
                 : s_menuPage == MenuPage::SLEEP_TIMER ? s_sleepSel : s_folderSel - s_folderFirstVisible;
    return getMenuItemY(selected);
}
static int16_t getPrevCursorY() { return getMenuItemY(s_prevMenuSel); }

static void drawMenu() {
    displayClear();
    const char* header = s_menuPage == MenuPage::UTILITIES ? "Utilities"
                       : s_menuPage == MenuPage::SLEEP_TIMER ? "Sleep timer" : "Music folder";
    drawAlignedText(s_menuHeaderRect, header, &FreeSans9pt7b, UITextAlign::LEFT, UITextVAlign::BASELINE);
    displayFillRect(0, MENU_SEP_Y, DISPLAY_WIDTH, 1);
    char label[PATH_LEN];
    int rows = 0;
    if (s_menuPage == MenuPage::UTILITIES) {
        static const char* labels[] = {"Sleep timer", "Music folder", "Reindex all", "Back"};
        for (int i = 0; i < (int)MenuItem::_COUNT; ++i) {
            int y = getMenuItemY(i);
            snprintf(label, sizeof(label), "%s", labels[i]);
            if (i == 0 && s_sleepActive) {
                uint32_t left = s_sleepDeadline - millis();
                snprintf(label, sizeof(label), "Sleep timer: %lum", (unsigned long)((left + 59999UL) / 60000UL));
            }
            displayText(MENU_TEXT_X + CURSOR_W + 2, y, label, nullptr, GxEPD_BLACK);
        }
        rows = (int)MenuItem::_COUNT;
    } else if (s_menuPage == MenuPage::SLEEP_TIMER) {
        for (int i = 0; i < 4; ++i) {
            displayText(MENU_TEXT_X + CURSOR_W + 2, getMenuItemY(i), SLEEP_LABELS[i], nullptr, GxEPD_BLACK);
            if (SLEEP_PRESETS_MS[i] == s_sleepDuration)
                displayText(DISPLAY_WIDTH - MENU_ASTERISK_R, getMenuItemY(i), "*", nullptr, GxEPD_BLACK);
        }
        rows = 4;
    } else {
        int total = storageFolderCount();
        rows = min(7, max(1, total - s_folderFirstVisible));
        if (total == 0) {
            displayText(MENU_TEXT_X + CURSOR_W + 2, MENU_ITEM_Y0, "No folders", nullptr, GxEPD_BLACK);
        } else {
            for (int i = 0; i < rows; ++i) {
                if (storageGetFolderName(s_folderFirstVisible + i, label, sizeof(label))) {
                    displayText(MENU_TEXT_X + CURSOR_W + 2, getMenuItemY(i), label, nullptr, GxEPD_BLACK);
                    if (strcmp(label, storageSelectedFolder()) == 0)
                        displayText(DISPLAY_WIDTH - MENU_ASTERISK_R, getMenuItemY(i), "*", nullptr, GxEPD_BLACK);
                }
            }
        }
    }
    (void)rows;
    drawCursorAt(getCursorY());
    s_prevMenuSel = s_menuPage == MenuPage::MUSIC_FOLDER ? s_folderSel - s_folderFirstVisible
                  : s_menuPage == MenuPage::SLEEP_TIMER ? s_sleepSel : s_menuSel;
}

static void drawSleepIndicator() {
    UIRect r = {52, (int16_t)(PBAR_Y - PBAR_LABEL_ABOVE - 8), 42, 9};
    clearRect(r);
    if (!s_sleepActive) return;
    uint32_t remaining = (int32_t)(millis() - s_sleepDeadline) >= 0 ? 0 : s_sleepDeadline - millis();
    char text[20];
    snprintf(text, sizeof(text), "S%lum", (unsigned long)((remaining + 59999UL) / 60000UL));
    displayText(r.x, r.y, text, nullptr);
}
