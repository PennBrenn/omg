// =============================================================================
// pennp3.ino — Main sketch: init, global definitions, Core 1 loop
// =============================================================================
// Core split:
//   Core 0: audioTaskFn() — SD read, MP3 decode, EQ, I2S output
//   Core 1: loop()        — input poll, UI state machine, display, battery
//
// Boot sequence:
//   1. Serial + SPI init
//   2. PSRAM diagnostic
//   3. SD mount + track list build
//   4. Display init + splash
//   5. Battery init
//   6. Input init
//   7. Create FreeRTOS queues + mutex
//   8. Start audio task on Core 0
//   9. Enter Core 1 loop (UI + input)
// =============================================================================
//
// ⚠ INPUT ARCHITECTURE (refactored):
//   loop() calls inputPoll() to get a raw InputEvent.
//   inputNormalize(raw) routes it through the current InputContext
//   (PLAYBACK, MENU, or OTHER) and returns a normalized event.
//   The normalized event is dispatched here in the fast path for
//   volume commands, and also buffered for uiTick().
//
//   The context is a PLAIN variable set by inputSetContext() in ui.cpp
//   when state transitions occur.  No function here calls uiGetState().
//   This completely decouples the input fast path from UI state queries.

#include <Arduino.h>
#include <SPI.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>

#include "config.h"
#include "loadscreen.h"
#include "state.h"
#include "storage.h"
#include "audio.h"
#include "battery.h"
#include "input.h"
#include "display.h"
#include "ui.h"

// =============================================================================
// Global definitions (declared extern in state.h)
// =============================================================================
QueueHandle_t    gAudioCmdQueue  = nullptr;
QueueHandle_t    gAudioEvtQueue  = nullptr;
SemaphoreHandle_t gPlaybackMutex = nullptr;
SemaphoreHandle_t gSdMutex       = nullptr;
PlaybackState    gPlayback       = {};
PlayerConfig     gConfig         = { RepeatMode::NONE, false };

// =============================================================================
// setup() — runs on Core 1
// =============================================================================
void setup() {
    Serial.begin(115200);
    delay(200);  // let serial settle

    // ⚠ Disable task WDT for Core 0 (audio decode runs long continuous loops
    //    and will trip the 10-second default WDT).  Safe because Core 0 only
    //    runs the audio pipeline, which is self-recovering.
    disableCore0WDT();

    Serial.println("\n[boot] pennp3 starting");

    // -------------------------------------------------------------------------
    // PSRAM diagnostic
    // ⚠ FLAG: If this prints "No PSRAM" you must keep MAX_TRACKS low (≤200)
    //         and APIC_MAX_BYTES low (≤60 KB) to avoid OOM crashes.
    // -------------------------------------------------------------------------
    if (psramFound()) {
        Serial.printf("[boot] PSRAM found: %u KB free\n",
                      ESP.getFreePsram() / 1024);
    } else {
        Serial.println("[boot] ⚠ No PSRAM detected — memory-constrained mode");
        Serial.printf("[boot] Free heap: %u KB\n", ESP.getFreeHeap() / 1024);
    }

    // -------------------------------------------------------------------------
    // SPI bus — SD card only (e-paper has its own SPI on pins 43/44)
    // -------------------------------------------------------------------------
    // ⚠ No external pull-ups on SD module — use INPUT_PULLUP on MISO
    pinMode(PIN_SD_MISO, INPUT_PULLUP);
    pinMode(PIN_SD_CS, OUTPUT);
    digitalWrite(PIN_SD_CS, HIGH);

    SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
    Serial.println("[boot] SPI initialized");

    // -------------------------------------------------------------------------
    // FreeRTOS IPC primitives — must exist before audio task starts
    // -------------------------------------------------------------------------
    gAudioCmdQueue = xQueueCreate(AUDIO_CMD_QUEUE_DEPTH, sizeof(AudioCmd));
    gAudioEvtQueue = xQueueCreate(UI_EVENT_QUEUE_DEPTH,  sizeof(AudioEvent));
    gPlaybackMutex = xSemaphoreCreateMutex();
    gSdMutex = xSemaphoreCreateMutex();
    if (!gAudioCmdQueue || !gAudioEvtQueue || !gPlaybackMutex || !gSdMutex) {
        Serial.println("[boot] FATAL: queue/mutex creation failed");
        while (true) delay(1000);
    }
    Serial.println("[boot] FreeRTOS queues created");

    // -------------------------------------------------------------------------
    // Display — init first so it can show error messages.
    //   E-paper has its own dedicated SPI bus (GPIO 43/44 via s_epdSPI),
    //   completely separate from SD (GPIO 1/2/3/4 via default SPI).
    //   No bus-sharing — init order does not matter.
    // -------------------------------------------------------------------------
    displayInit();

    // Show boot bitmap on the initial full-refresh flash
    display().setFullWindow();
    displayClear();
    displayBitmap(0, 0, LOAD_WIDTH, LOAD_HEIGHT, load);
    display().display(false);
    uiInit();

    // -------------------------------------------------------------------------
    // SD card — init after display so errors can be shown
    // -------------------------------------------------------------------------
    if (!storageInit()) {
        Serial.println("[boot] SD mount failed — showing error on display");
        const char* message = "No SD card";
        displayClear();
        int16_t messageX = (DISPLAY_WIDTH - displayTextWidth(message, &FreeSans9pt7b)) / 2;
        int16_t messageY = DISPLAY_HEIGHT / 2 + FreeSans9pt7b.yAdvance / 3;
        displayText(messageX, messageY, message, &FreeSans9pt7b);
        displayFullRefresh();
        while (true) { Serial.println("[boot] Halted: no SD"); delay(1000); }
    }

    int nTracks = 0;
    if (storageLoadIndex()) {
        nTracks = getTrackCount();
        Serial.printf("[boot] Loaded %d tracks from persistent binary index\n", nTracks);
    } else {
        Serial.println("[boot] Valid persistent index not found, building library from scratch...");
        nTracks = storageBuildList();
        Serial.printf("[boot] Rebuilt persistent index with %d tracks\n", nTracks);
    }

    // -------------------------------------------------------------------------
    // Battery
    // -------------------------------------------------------------------------
    batteryInit();

    // -------------------------------------------------------------------------
    // Input
    // -------------------------------------------------------------------------
    inputInit();

    // -------------------------------------------------------------------------
    // Restore last-played position
    // -------------------------------------------------------------------------
    int lastTrack = 0;
    uint32_t lastPos = 0;
    loadLastPlayed(lastTrack, lastPos);
    lastTrack = (nTracks > 0) ? constrain(lastTrack, 0, nTracks - 1) : 0;
    Serial.printf("[boot] Resuming at track %d, pos %lu ms\n", lastTrack, (unsigned long)lastPos);

    // -------------------------------------------------------------------------
    // Start audio task on Core 0
    // -------------------------------------------------------------------------
    audioTaskStart();

    // Wait for audio task to finish its initialization before sending the
    // first PLAY_TRACK command.  Polling the ready flag is deterministic
    // (no arbitrary delay) and avoids the race condition where PLAY_TRACK
    // arrives before the audio task's queue/mutex/EQI2SOutput init.
    {
        uint32_t audioStartTimeout = millis();
        while (!audioIsReady()) {
            vTaskDelay(pdMS_TO_TICKS(1));  // yield to Core 0 while waiting
            if (millis() - audioStartTimeout > 5000) {
                Serial.println("[boot] ⚠ TIMEOUT waiting for audio task ready — sending PLAY_TRACK anyway");
                break;
            }
        }
        Serial.printf("[boot] Audio task ready after %lu ms\n", millis() - audioStartTimeout);
    }

    // Send initial play command — log failure if queue full
    if (!sendAudioCmd(AudioCmdType::PLAY_TRACK, lastTrack, 0)) {
        Serial.println("[boot] ⚠ CRITICAL: Failed to send initial PLAY_TRACK (queue full)");
    } else {
        Serial.println("[boot] Sent initial PLAY_TRACK command");
    }
    // ⚠ FLAG: Seek to lastPos is not implemented in v1 (spec says out of scope).
    //         The player will restart from the beginning of the last track.
    //         Implement SEEK_PERCENT when chapter/byte-offset seeking is added.

    // Transition to NOW_PLAYING — the BOOT state in uiTick triggers a full
    // refresh that replaces the "pennp3player" splash with the now-playing UI.
    uiForceRedraw();

    Serial.println("[boot] Boot complete — entering main loop on Core 1");
}

// =============================================================================
// loop() — Core 1: input + UI + battery
// =============================================================================

// Persistence timer — save position every 30 seconds
static uint32_t s_lastSaveMs  = 0;
#define SAVE_INTERVAL_MS 30000

void loop() {
    // -------------------------------------------------------------------------
    // Fast polling loop — input dispatch is decoupled from display/UI timing.
    //
    //   ⚠ INPUT ISOLATION (refactored):
    //     All input flows through inputPoll() → inputNormalize().
    //     inputNormalize() uses the current InputContext (set by ui.cpp via
    //     inputSetContext()) to route events correctly.  NO UI state query
    //     (*no uiGetState()*) is made here.
    //
    //     Volume commands (VOLUME_UP/DOWN) are dispatched HERE for speed
    //     (~1μs FreeRTOS queue write), so even if the e-paper display blocks
    //     the main loop for 300–3000ms, the very next encoder detent is still
    //     dispatched to the audio task immediately.
    //
    //     Non-volume normalized events are buffered and delivered to uiTick()
    //     on the slow tick.  uiTick() handles NAV_*, PLAY_PAUSE, SHOW_MENU,
    //     TRACK_NEXT, TRACK_PREV, etc.
    // -------------------------------------------------------------------------
    static uint32_t s_slowTick = 0;
    static InputEvent s_pendingEvts[8];
    static int s_pendingCnt = 0;
    static int s_lastVolume = loadVolume();    // local copy for fast dispatch, persisted
    uint32_t now = millis();

    // Poll input every iteration — get raw event
    InputEvent raw = inputPoll();

    // Normalize through context-aware router — NO uiGetState() call here
    InputEvent evt = inputNormalize(raw);

    // VOLUME DISPATCH — only VOLUME_UP/VOLUME_DOWN events produce audio commands.
    // The router (inputNormalize()) ensures these only appear in PLAYBACK context.
    // No UI state check needed here — the router already filtered them.
    if (evt == InputEvent::VOLUME_UP) {
        s_lastVolume = min(100, s_lastVolume + 1);
        sendAudioCmd(AudioCmdType::SET_VOLUME, 0, s_lastVolume);
    } else if (evt == InputEvent::VOLUME_DOWN) {
        s_lastVolume = max(0, s_lastVolume - 1);
        sendAudioCmd(AudioCmdType::SET_VOLUME, 0, s_lastVolume);
    }

    // Buffer ALL normalized events for UI state machine
    if (evt != InputEvent::NONE && s_pendingCnt < 8) {
        s_pendingEvts[s_pendingCnt++] = evt;
    }

    // Slow work: UI, save — run every ~5ms.
    // This path MAY be blocked by e-paper display() calls (300–3000ms).
    // Volume commands are ALREADY dispatched above, so the audio volume
    // changes immediately regardless of display state.
    if (now - s_slowTick >= 5) {
        s_slowTick = now;

        // UI tick — process ALL buffered normalized events.
        if (s_pendingCnt > 0) {
            for (int i = 0; i < s_pendingCnt; i++) {
                uiTick(s_pendingEvts[i]);
            }
            s_pendingCnt = 0;
        } else {
            uiTick(InputEvent::NONE);
        }

        // Periodic save of playback position
        if (now - s_lastSaveMs >= SAVE_INTERVAL_MS) {
            s_lastSaveMs = now;
            uint32_t pos = 0;
            int track = 0;
            if (xSemaphoreTake(gPlaybackMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
                track = (int)gPlayback.currentTrackIndex;
                pos   = gPlayback.positionMs;
                xSemaphoreGive(gPlaybackMutex);
            }
            saveLastPlayed(track, pos);
        }
    }

    // No vTaskDelay — loop spins at CPU speed for fast input polling.
    // FreeRTOS preempts Core 1 for Core 0 audio automatically.
    // The slow work runs every 5ms and yields internally if needed.
}
