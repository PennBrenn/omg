// =============================================================================
// eq.cpp — Biquad IIR EQ implementation
// =============================================================================
// Coefficient computation uses the Audio EQ Cookbook formulas by Robert
// Bristow-Johnson (https://www.w3.org/2011/audio/audio-eq-cookbook.html).
// All coefficients are normalised so a0 = 1.
// =============================================================================

#include "eq.h"
#include <math.h>
#include <Arduino.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ---------------------------------------------------------------------------
// Module state
// ---------------------------------------------------------------------------
static EQPreset   s_preset  = EQPreset::FLAT;
static BiquadCoeffs s_c;
static BiquadState  s_state;

// ---------------------------------------------------------------------------
// Coefficient computation helpers
// ---------------------------------------------------------------------------

// Low-shelf boost: used for Bass Boost
// Fc = shelf corner frequency, dBgain = peak gain in dB, S = shelf slope (1.0)
static BiquadCoeffs makeLowShelf(float Fc, float dBgain, float S = 1.0f) {
    float A  = powf(10.0f, dBgain / 40.0f);
    float w0 = 2.0f * (float)M_PI * Fc / (float)SAMPLE_RATE;
    float cosw0 = cosf(w0);
    float sinw0 = sinf(w0);
    float alpha  = sinw0 / 2.0f * sqrtf((A + 1.0f / A) * (1.0f / S - 1.0f) + 2.0f);

    float b0 =  A * ((A + 1.0f) - (A - 1.0f) * cosw0 + 2.0f * sqrtf(A) * alpha);
    float b1 =  2.0f * A * ((A - 1.0f) - (A + 1.0f) * cosw0);
    float b2 =  A * ((A + 1.0f) - (A - 1.0f) * cosw0 - 2.0f * sqrtf(A) * alpha);
    float a0 =        (A + 1.0f) + (A - 1.0f) * cosw0 + 2.0f * sqrtf(A) * alpha;
    float a1 = -2.0f * ((A - 1.0f) + (A + 1.0f) * cosw0);
    float a2 =        (A + 1.0f) + (A - 1.0f) * cosw0 - 2.0f * sqrtf(A) * alpha;

    return { b0/a0, b1/a0, b2/a0, a1/a0, a2/a0 };
}

// High-shelf boost: used for Treble Boost
static BiquadCoeffs makeHighShelf(float Fc, float dBgain, float S = 1.0f) {
    float A  = powf(10.0f, dBgain / 40.0f);
    float w0 = 2.0f * (float)M_PI * Fc / (float)SAMPLE_RATE;
    float cosw0 = cosf(w0);
    float sinw0 = sinf(w0);
    float alpha  = sinw0 / 2.0f * sqrtf((A + 1.0f / A) * (1.0f / S - 1.0f) + 2.0f);

    float b0 =  A * ((A + 1.0f) + (A - 1.0f) * cosw0 + 2.0f * sqrtf(A) * alpha);
    float b1 = -2.0f * A * ((A - 1.0f) + (A + 1.0f) * cosw0);
    float b2 =  A * ((A + 1.0f) + (A - 1.0f) * cosw0 - 2.0f * sqrtf(A) * alpha);
    float a0 =        (A + 1.0f) - (A - 1.0f) * cosw0 + 2.0f * sqrtf(A) * alpha;
    float a1 =  2.0f * ((A - 1.0f) - (A + 1.0f) * cosw0);
    float a2 =        (A + 1.0f) - (A - 1.0f) * cosw0 - 2.0f * sqrtf(A) * alpha;

    return { b0/a0, b1/a0, b2/a0, a1/a0, a2/a0 };
}

// Peaking EQ: used for Vocal Boost (mid-range band boost)
// Fc = centre frequency, dBgain, BW = bandwidth in octaves
static BiquadCoeffs makePeaking(float Fc, float dBgain, float BW) {
    float A  = powf(10.0f, dBgain / 40.0f);
    float w0 = 2.0f * (float)M_PI * Fc / (float)SAMPLE_RATE;
    float cosw0 = cosf(w0);
    float alpha  = sinf(w0) * sinhf((float)M_LN2 / 2.0f * BW * w0 / sinf(w0));

    float b0 =  1.0f + alpha * A;
    float b1 = -2.0f * cosw0;
    float b2 =  1.0f - alpha * A;
    float a0 =  1.0f + alpha / A;
    float a1 = -2.0f * cosw0;
    float a2 =  1.0f - alpha / A;

    return { b0/a0, b1/a0, b2/a0, a1/a0, a2/a0 };
}

// Flat / identity
static BiquadCoeffs makeFlat() {
    return { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
void eqSetPreset(EQPreset preset) {
    s_preset = preset;
    switch (preset) {
        case EQPreset::FLAT:
            s_c = makeFlat();
            break;
        case EQPreset::BASS_BOOST:
            // Low shelf at 150 Hz, +8 dB
            s_c = makeLowShelf(150.0f, 8.0f);
            break;
        case EQPreset::TREBLE_BOOST:
            // High shelf at 8000 Hz, +8 dB
            s_c = makeHighShelf(8000.0f, 8.0f);
            break;
        case EQPreset::VOCAL_BOOST:
            // Peaking at 2500 Hz, +6 dB, 2 octave bandwidth
            s_c = makePeaking(2500.0f, 6.0f, 2.0f);
            break;
        default:
            s_c = makeFlat();
            break;
    }
    // Log for debugging
    Serial.printf("[eq] preset=%d b0=%.4f b1=%.4f b2=%.4f a1=%.4f a2=%.4f\n",
                  (int)preset, s_c.b0, s_c.b1, s_c.b2, s_c.a1, s_c.a2);
    eqReset();
}

// Direct Form II transposed — applied inline to a single sample
// This version is called once per sample from the audio loop.
// The function is short and will likely inline to machine code.
void eqProcess(float& sampleL, float& sampleR) {
    if (s_preset == EQPreset::FLAT) return;  // bypass entirely — no math

    // Left channel
    float xL = sampleL;
    float yL = s_c.b0 * xL + s_state.w1L;
    s_state.w1L = s_c.b1 * xL - s_c.a1 * yL + s_state.w2L;
    s_state.w2L = s_c.b2 * xL - s_c.a2 * yL;
    sampleL = yL;

    // Right channel
    float xR = sampleR;
    float yR = s_c.b0 * xR + s_state.w1R;
    s_state.w1R = s_c.b1 * xR - s_c.a1 * yR + s_state.w2R;
    s_state.w2R = s_c.b2 * xR - s_c.a2 * yR;
    sampleR = yR;
}

void eqReset() {
    s_state = {0.0f, 0.0f, 0.0f, 0.0f};
}

const BiquadCoeffs& eqGetCoeffs() { return s_c; }

EQPreset eqGetPreset() { return s_preset; }
