// =============================================================================
// battery.cpp — LiPo voltage sensing
// =============================================================================
// ⚠ FLAG: The ESP32-S3's ADC has known non-linearity, especially near the
//   rails.  For better accuracy, use esp_adc_cal_characterize() from the
//   ESP-IDF ADC calibration API rather than raw analogRead().  The current
//   implementation uses analogReadMilliVolts() which applies the built-in
//   eFuse calibration on supported boards — verify this is available in your
//   Arduino-ESP32 core version (available from arduino-esp32 >= 2.0.3).
//
// ⚠ FLAG: BATT_DIVIDER_RATIO in config.h must match your actual resistors.
//   Measure with a multimeter before trusting the percentage display.
// =============================================================================

#include "battery.h"
#include "config.h"
#include <Arduino.h>
#include <esp_adc_cal.h>

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
static float s_volts   = 3.7f;  // reasonable default at boot
static int   s_percent = 50;

// ---------------------------------------------------------------------------
// Piecewise LiPo discharge map
// These breakpoints approximate a typical LiPo 18650/pouch cell.
// Not calibrated to your specific cell — adjust by comparing against a
// charger or bench supply display during initial testing.
// ---------------------------------------------------------------------------
struct VoltPct { float v; int pct; };
static const VoltPct kCurve[] = {
    { 4.20f, 100 },
    { 4.10f,  90 },
    { 4.00f,  80 },
    { 3.90f,  70 },
    { 3.80f,  60 },
    { 3.70f,  50 },
    { 3.60f,  35 },
    { 3.50f,  20 },
    { 3.40f,  10 },
    { 3.30f,   0 },
    { 3.00f,   0 },
};
static const int kCurveLen = sizeof(kCurve) / sizeof(kCurve[0]);

static int voltsToPct(float v) {
    if (v >= kCurve[0].v)           return 100;
    if (v <= kCurve[kCurveLen-1].v) return 0;
    for (int i = 0; i < kCurveLen - 1; i++) {
        if (v >= kCurve[i+1].v) {
            // Linear interpolation between two breakpoints
            float frac = (v - kCurve[i+1].v) / (kCurve[i].v - kCurve[i+1].v);
            return (int)(kCurve[i+1].pct + frac * (kCurve[i].pct - kCurve[i+1].pct));
        }
    }
    return 0;
}

// ---------------------------------------------------------------------------
// ADC oversampling: take N raw readings and average to reduce noise
// ---------------------------------------------------------------------------
#define BATT_OVERSAMPLE 8

static float readBatteryVolts() {
    // analogReadMilliVolts() returns the millivolt reading with eFuse
    // calibration applied.  Falls back to raw if calibration data is absent.
    uint32_t sumMv = 0;
    for (int i = 0; i < BATT_OVERSAMPLE; i++) {
        sumMv += analogReadMilliVolts(PIN_BATT_ADC);
        delayMicroseconds(200);
    }
    float adcMv = (float)sumMv / BATT_OVERSAMPLE;
    float adcV  = adcMv / 1000.0f;
    return adcV * BATT_DIVIDER_RATIO;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
void batteryInit() {
    analogSetAttenuation(ADC_11db);   // full 0–3.3 V range on ESP32-S3
    // Perform an initial reading so the display shows something at boot
    batteryUpdate();
    Serial.printf("[battery] init: %.2f V  %d%%\n", s_volts, s_percent);
}

void batteryUpdate() {
    s_volts   = readBatteryVolts();
    s_percent = voltsToPct(s_volts);
    Serial.printf("[battery] %.2f V  %d%%\n", s_volts, s_percent);
}

float batteryGetVolts()   { return s_volts;   }
int   batteryGetPercent() { return s_percent; }