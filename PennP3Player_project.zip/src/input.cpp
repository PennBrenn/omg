// =============================================================================
// input.cpp — Raw hardware polling, context-aware normalizer
// =============================================================================
// Architecture:
//   Raw layer:  pollEncoder() / pollEncButton() / pollToggle() → raw InputEvents
//   Channel:    inputPoll() returns one raw event per call
//   Router:     inputNormalize(raw) → normalized event based on current context
//
// The context is an INDEPENDENT variable set by inputSetContext().
// The input system NEVER calls any UI function.
//
// Encoder: interrupt-driven quadrature decode (ISR on CHANGE of both pins).
//   The ISR runs at CPU speed independent of the main loop, so transitions
//   are NEVER missed even when the e-paper display blocks the main loop for
//   300-2000ms during refresh.  The main loop simply drains the ISR's
//   accumulator into the event queue.
//
// Encoder button: debounced; distinguishes short and long press.
//
// Toggle: latching 3-position switch.  Emits INPUT_UP/INPUT_DOWN/INPUT_REPEAT
//   events (context-agnostic directional events), NOT hardware-specific
//   TOGGLE_NEXT/TOGGLE_PREV.  This decouples the physical switch wiring
//   from the semantic meaning.
// =============================================================================

#include "input.h"
#include "config.h"
#include <Arduino.h>

// ---------------------------------------------------------------------------
// Encoder interrupt state — ISR captures EVERY transition
// ---------------------------------------------------------------------------

// Half-step decode table: index = (last_AB << 2) | curr_AB
static const int8_t kEncTable[16] = {
      0, -1, +1,  0,
     +1,  0,  0, -1,
     -1,  0,  0, +1,
      0, +1, -1,  0,
};

// ISR-shared state — protected by s_encMux (portMUX critical sections)
static portMUX_TYPE s_encMux    = portMUX_INITIALIZER_UNLOCKED;
static uint8_t      s_isrLastAB = 0;     // last AB pattern read by ISR
static volatile int32_t s_isrAccum = 0;  // accumulated pulse count from ISR
#define ENC_DETENT_DIV 4                 // EC11 detent divisor

// ---------------------------------------------------------------------------
// Encoder ISR — fires on CHANGE of either encoder pin
// ---------------------------------------------------------------------------
void IRAM_ATTR encoderISR() {
    uint32_t gpio_in = GPIO.in;
    uint8_t ab = ((gpio_in >> PIN_ENC_A) & 1) << 1;
    ab |= (gpio_in >> PIN_ENC_B) & 1;

    if (ab == s_isrLastAB) return;

    uint8_t idx = (s_isrLastAB << 2) | ab;
    s_isrAccum += kEncTable[idx & 0x0F];
    s_isrLastAB = ab;
}

// ---------------------------------------------------------------------------
// Encoder button (SW) — debounced state (polling only)
// ---------------------------------------------------------------------------
static bool     s_swStable    = true;
static uint32_t s_swDebounceEnd = 0;
static bool     s_swPending   = false;
static uint32_t s_swDownMs    = 0;

// ---------------------------------------------------------------------------
// Toggle switch state machine — emits generic INPUT_UP/INPUT_DOWN events
// ---------------------------------------------------------------------------
enum class ToggleState : uint8_t {
    CENTER,
    DEBOUNCE_UP,
    DEBOUNCE_DOWN,
    SIDE_UP,
    SIDE_DOWN,
    REPEAT_UP,
    REPEAT_DOWN,
};

static ToggleState s_toggleState   = ToggleState::CENTER;
static uint32_t    s_toggleMs      = 0;
static uint32_t    s_repeatMs      = 0;
static uint32_t    s_repeatInterval = TOGGLE_REPEAT_START;

// ---------------------------------------------------------------------------
// Input context — standalone variable, NOT a UI state query
// ---------------------------------------------------------------------------
static InputContext s_inputContext = InputContext::PLAYBACK;

void inputSetContext(InputContext ctx) {
    s_inputContext = ctx;
    Serial.printf("[input] Context: %s\n",
        ctx == InputContext::PLAYBACK ? "PLAYBACK" :
        ctx == InputContext::MENU ? "MENU" : "OTHER");
}

InputContext inputGetContext() {
    return s_inputContext;
}

// ---------------------------------------------------------------------------
// Event queue
// ---------------------------------------------------------------------------
#define EVT_QUEUE_SIZE 16
static InputEvent s_evtQueue[EVT_QUEUE_SIZE];
static uint8_t    s_evtHead = 0;
static uint8_t    s_evtTail = 0;

static void pushEvent(InputEvent e) {
    uint8_t next = (s_evtTail + 1) % EVT_QUEUE_SIZE;
    if (next != s_evtHead) {
        s_evtQueue[s_evtTail] = e;
        s_evtTail = next;
    }
}

static InputEvent popEvent() {
    if (s_evtHead == s_evtTail) return InputEvent::NONE;
    InputEvent e = s_evtQueue[s_evtHead];
    s_evtHead = (s_evtHead + 1) % EVT_QUEUE_SIZE;
    return e;
}

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
void inputInit() {
    pinMode(PIN_ENC_A,       INPUT_PULLUP);
    pinMode(PIN_ENC_B,       INPUT_PULLUP);
    pinMode(PIN_ENC_SW,      INPUT_PULLUP);
    pinMode(PIN_TOGGLE_NEXT, INPUT_PULLUP);
    pinMode(PIN_TOGGLE_PREV, INPUT_PULLUP);

    uint8_t initialAB = (digitalRead(PIN_ENC_A) << 1) | digitalRead(PIN_ENC_B);
    s_isrLastAB = initialAB;
    s_isrAccum  = 0;

    attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), encoderISR, CHANGE);
    attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), encoderISR, CHANGE);

    Serial.println("[input] Initialized");
}

// ---------------------------------------------------------------------------
// Encoder polling — drain ISR accumulator and push events
// ---------------------------------------------------------------------------
static void pollEncoder() {
    int32_t accum;
    portENTER_CRITICAL(&s_encMux);
    accum = s_isrAccum;
    s_isrAccum = 0;
    portEXIT_CRITICAL(&s_encMux);

    while (accum >= ENC_DETENT_DIV) {
        pushEvent(InputEvent::ENC_CW);
        accum -= ENC_DETENT_DIV;
    }
    while (accum <= -ENC_DETENT_DIV) {
        pushEvent(InputEvent::ENC_CCW);
        accum += ENC_DETENT_DIV;
    }

    if (accum != 0) {
        portENTER_CRITICAL(&s_encMux);
        s_isrAccum += accum;
        portEXIT_CRITICAL(&s_encMux);
    }
}

// ---------------------------------------------------------------------------
// Button debounce — polling
// ---------------------------------------------------------------------------
static void pollEncButton() {
    bool raw = (bool)digitalRead(PIN_ENC_SW);
    uint32_t now = millis();

    if (raw != s_swStable && (int32_t)(now - s_swDebounceEnd) < 0 && s_swDebounceEnd != 0) {
        // Still in debounce window
    } else if (raw != s_swStable) {
        s_swStable = raw;
        s_swDebounceEnd = now + DEBOUNCE_MS;
        if (!raw) {
            s_swDownMs = now;
            s_swPending = true;
        } else {
            if (s_swPending) {
                uint32_t held = now - s_swDownMs;
                s_swPending = false;
                if (held < LONG_PRESS_MS) {
                    pushEvent(InputEvent::ENC_SHORT_PRESS);
                    Serial.printf("[ENC] PRESS (held=%ums)\n", held);
                }
            }
        }
    }

    if (s_swPending && !s_swStable) {
        if ((int32_t)(now - s_swDownMs) >= (int32_t)LONG_PRESS_MS) {
            s_swPending = false;
            pushEvent(InputEvent::ENC_LONG_PRESS);
            Serial.printf("[ENC] LONG_PRESS\n");
        }
    }
}

// ---------------------------------------------------------------------------
// Toggle state machine — emits generic INPUT_UP/INPUT_DOWN
// ---------------------------------------------------------------------------
static void pollToggle() {
    uint32_t now = millis();
    bool nextRaw = !digitalRead(PIN_TOGGLE_NEXT);
    bool prevRaw = !digitalRead(PIN_TOGGLE_PREV);

    switch (s_toggleState) {
        case ToggleState::CENTER:
            if (prevRaw) {
                s_toggleState = ToggleState::DEBOUNCE_UP;
                s_toggleMs    = now;
            } else if (nextRaw) {
                s_toggleState = ToggleState::DEBOUNCE_DOWN;
                s_toggleMs    = now;
            }
            break;

        case ToggleState::DEBOUNCE_UP:
            if (!prevRaw) {
                s_toggleState = ToggleState::CENTER;
            } else if ((int32_t)(now - s_toggleMs) >= DEBOUNCE_MS) {
                s_toggleState = ToggleState::SIDE_UP;
                s_toggleMs    = now;
                pushEvent(InputEvent::INPUT_UP);
            }
            break;

        case ToggleState::DEBOUNCE_DOWN:
            if (!nextRaw) {
                s_toggleState = ToggleState::CENTER;
            } else if ((int32_t)(now - s_toggleMs) >= DEBOUNCE_MS) {
                s_toggleState = ToggleState::SIDE_DOWN;
                s_toggleMs    = now;
                pushEvent(InputEvent::INPUT_DOWN);
            }
            break;

        case ToggleState::SIDE_UP:
            if (!prevRaw) {
                s_toggleState    = ToggleState::CENTER;
                s_repeatInterval = TOGGLE_REPEAT_START;
                pushEvent(InputEvent::INPUT_RELEASE);
            } else if ((int32_t)(now - s_toggleMs) >= TOGGLE_HOLD_MS) {
                s_toggleState    = ToggleState::REPEAT_UP;
                s_repeatMs       = now;
                s_repeatInterval = TOGGLE_REPEAT_START;
            }
            break;

        case ToggleState::SIDE_DOWN:
            if (!nextRaw) {
                s_toggleState    = ToggleState::CENTER;
                s_repeatInterval = TOGGLE_REPEAT_START;
                pushEvent(InputEvent::INPUT_RELEASE);
            } else if ((int32_t)(now - s_toggleMs) >= TOGGLE_HOLD_MS) {
                s_toggleState    = ToggleState::REPEAT_DOWN;
                s_repeatMs       = now;
                s_repeatInterval = TOGGLE_REPEAT_START;
            }
            break;

        case ToggleState::REPEAT_UP:
            if (!prevRaw) {
                s_toggleState    = ToggleState::CENTER;
                s_repeatInterval = TOGGLE_REPEAT_START;
                pushEvent(InputEvent::INPUT_RELEASE);
            } else if ((int32_t)(now - s_repeatMs) >= (int32_t)s_repeatInterval) {
                s_repeatMs = now;
                pushEvent(InputEvent::INPUT_REPEAT_UP);
                if (s_repeatInterval > (uint32_t)TOGGLE_REPEAT_MIN + TOGGLE_ACCEL_STEP)
                    s_repeatInterval -= TOGGLE_ACCEL_STEP;
                else
                    s_repeatInterval = TOGGLE_REPEAT_MIN;
            }
            break;

        case ToggleState::REPEAT_DOWN:
            if (!nextRaw) {
                s_toggleState    = ToggleState::CENTER;
                s_repeatInterval = TOGGLE_REPEAT_START;
                pushEvent(InputEvent::INPUT_RELEASE);
            } else if ((int32_t)(now - s_repeatMs) >= (int32_t)s_repeatInterval) {
                s_repeatMs = now;
                pushEvent(InputEvent::INPUT_REPEAT_DOWN);
                if (s_repeatInterval > (uint32_t)TOGGLE_REPEAT_MIN + TOGGLE_ACCEL_STEP)
                    s_repeatInterval -= TOGGLE_ACCEL_STEP;
                else
                    s_repeatInterval = TOGGLE_REPEAT_MIN;
            }
            break;
    }
}

// ---------------------------------------------------------------------------
// Main poll — returns ONE raw event per call
// ---------------------------------------------------------------------------
InputEvent inputPoll() {
    pollEncoder();
    pollEncButton();
    pollToggle();

    InputEvent evt = popEvent();
    if (evt != InputEvent::NONE) {
        const char* name = "?";
        switch (evt) {
            case InputEvent::ENC_CW:          name = "CW";  break;
            case InputEvent::ENC_CCW:         name = "CCW"; break;
            case InputEvent::ENC_SHORT_PRESS: name = "Click"; break;
            case InputEvent::ENC_LONG_PRESS:  name = "LongPress"; break;
            case InputEvent::INPUT_UP:        name = "Up"; break;
            case InputEvent::INPUT_DOWN:      name = "Down"; break;
            case InputEvent::INPUT_REPEAT_UP: name = "UpRepeat"; break;
            case InputEvent::INPUT_REPEAT_DOWN: name = "DownRepeat"; break;
            case InputEvent::INPUT_RELEASE:   name = "Release"; break;
            default: break;
        }
        Serial.printf("[input] %s\n", name);
    }
    return evt;
}

// ---------------------------------------------------------------------------
// Context-aware normalizer — central input router
// ---------------------------------------------------------------------------
// This is the ONLY place where context-dependent routing decisions are made.
// No other module queries input context or UI state to interpret events.
//
// Rules:
//   PLAYBACK context:
//     ENC_CW/CCW        → VOLUME_UP/DOWN
//     INPUT_UP           → TRACK_PREV
//     INPUT_DOWN         → TRACK_NEXT
//     INPUT_REPEAT_UP    → TRACK_PREV (repeated)
//     INPUT_REPEAT_DOWN  → TRACK_NEXT (repeated)
//     ENC_SHORT_PRESS    → PLAY_PAUSE
//     ENC_LONG_PRESS     → SHOW_MENU
//
//   MENU context:
//     ENC_CW             → NAV_DOWN (encoder becomes menu navigation input)
//     ENC_CCW            → NAV_UP
//     INPUT_UP            → NAV_UP
//     INPUT_DOWN          → NAV_DOWN
//     INPUT_REPEAT_UP     → NAV_UP (repeated)
//     INPUT_REPEAT_DOWN   → NAV_DOWN (repeated)
//     ENC_SHORT_PRESS     → NAV_ENTER
//     ENC_LONG_PRESS      → NAV_BACK
//
//   OTHER context: all events pass through unchanged (handled as needed).
//     In practice, BOOT/ERROR states ignore most events.
//
// Side-effect rule: inputNormalize NEVER sends audio commands, NEVER modifies
//   UI state, NEVER reads UI state.  It returns a normalized event code and
//   the caller (main.cpp or uiTick) decides what to do with it.
// ---------------------------------------------------------------------------
InputEvent inputNormalize(InputEvent raw) {
    // Special handling for encoder press/release and generic directional events:
    // these are context-agnostic raw events that need routing.
    // Encoder rotation and directional events are the only ones with context-dependent mappings.
    InputContext ctx = s_inputContext;

    if (ctx == InputContext::PLAYBACK) {
        switch (raw) {
            case InputEvent::ENC_CW:            return InputEvent::VOLUME_UP;
            case InputEvent::ENC_CCW:           return InputEvent::VOLUME_DOWN;
            case InputEvent::INPUT_UP:          return InputEvent::TRACK_PREV;
            case InputEvent::INPUT_DOWN:        return InputEvent::TRACK_NEXT;
            case InputEvent::INPUT_REPEAT_UP:   return InputEvent::TRACK_PREV;
            case InputEvent::INPUT_REPEAT_DOWN: return InputEvent::TRACK_NEXT;
            case InputEvent::ENC_SHORT_PRESS:   return InputEvent::PLAY_PAUSE;
            case InputEvent::ENC_LONG_PRESS:    return InputEvent::SHOW_MENU;
            case InputEvent::INPUT_RELEASE:     // release has no action in playback
            default:                            return raw;  // pass through unchanged
        }
    }

    if (ctx == InputContext::MENU) {
        switch (raw) {
            case InputEvent::ENC_CW:            return InputEvent::NAV_DOWN;
            case InputEvent::ENC_CCW:           return InputEvent::NAV_UP;
            case InputEvent::INPUT_UP:          return InputEvent::NAV_UP;
            case InputEvent::INPUT_DOWN:        return InputEvent::NAV_DOWN;
            case InputEvent::INPUT_REPEAT_UP:   return InputEvent::NAV_UP;
            case InputEvent::INPUT_REPEAT_DOWN: return InputEvent::NAV_DOWN;
            case InputEvent::ENC_SHORT_PRESS:   return InputEvent::NAV_ENTER;
            case InputEvent::ENC_LONG_PRESS:    return InputEvent::NAV_BACK;
            case InputEvent::INPUT_RELEASE:     // release has no action in menu
            default:                            return raw;  // pass through (e.g. NONE)
        }
    }

    // OTHER context: pass through raw events.  Main loop / uiTick will handle.
    return raw;
}