#!/usr/bin/env python3
"""
=============================================================================
mp3_cleaner_gui.py — PennP3Player Album Art Stripper + Filename Checker
=============================================================================
Tkinter GUI that scans removable drives for MP3 files, strips embedded album
art (APIC frames) without re-encoding, and flags/trims overly long filenames.

Keyboard shortcuts:
    Ctrl+R  — Refresh drive list
    Ctrl+S  — Run strip (same as clicking the big green button)
    Escape  — Close

Requirements:
    - Python 3 + tkinter (usually built-in)
    - ffmpeg on PATH (for actual APIC removal)

Usage:
    python3 tools/mp3_cleaner_gui.py
=============================================================================
"""

import argparse
import glob
import json
import os
import subprocess
import struct
import sys
import threading
import time


# ---------------------------------------------------------------------------
# Try importing tkinter — show clear error if not available
# ---------------------------------------------------------------------------
try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog
    from tkinter.scrolledtext import ScrolledText
except ImportError:
    print("ERROR: tkinter not available on this system.")
    print("On Debian/Ubuntu: sudo apt-get install python3-tk")
    print("On Fedora:        sudo dnf install python3-tkinter")
    print("On Arch:          sudo pacman -S tk")
    sys.exit(1)


# =============================================================================
# Constants matching the firmware (storage.h)
# =============================================================================
PATH_LEN   = 288
TITLE_LEN  = 256
ARTIST_LEN = 128

TRIM_TITLE_TARGET  = TITLE_LEN - 16   # 240
TRIM_ARTIST_TARGET = ARTIST_LEN - 8   # 120

APP_NAME  = "PennP3Player MP3 Cleaner"
APP_WIDTH = 720
APP_HEIGHT= 560


# =============================================================================
# Backend logic (same as strip_album_art_and_check_filenames.py)
# =============================================================================
def find_removable_drives():
    """Return list of mount paths for removable drives (USB sticks etc.).

    Uses lsblk JSON output to reliably identify USB mass-storage partitions,
    then falls back to scanning common automount directories.
    """
    drives = []

    # ---------------------------------------------------------------
    # 1. Primary method: parse lsblk JSON and filter on USB transport
    # ---------------------------------------------------------------
    try:
        result = subprocess.run(
            ['lsblk', '-J', '-o', 'NAME,TYPE,MOUNTPOINT,TRAN'],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            data = json.loads(result.stdout)
        else:
            data = {'blockdevices': []}
    except Exception:
        data = {'blockdevices': []}

    for dev in data.get('blockdevices', []):
        # Find USB devices (the disk itself has tran='usb')
        if dev.get('tran') == 'usb':
            for child in dev.get('children', []):
                mp = child.get('mountpoint')
                if child.get('type') == 'part' and mp:
                    mp = mp if mp != '[SWAP]' else None
                if mp and mp not in drives:
                    drives.append(mp)

    # ---------------------------------------------------------------
    # 2. Fallback: scan common automount points for mount directories
    # ---------------------------------------------------------------
    for base in ['/media', '/mnt', '/run/media']:
        if not os.path.isdir(base):
            continue
        try:
            for entry in sorted(os.listdir(base)):
                full = os.path.join(base, entry)
                # Directly mounted (e.g. /media/DRIVE_LABEL)
                if os.path.ismount(full) and full not in drives:
                    drives.append(full)
                # Subdirectory mount (e.g. /run/media/$USER/DRIVE_LABEL)
                if os.path.isdir(full):
                    try:
                        for sub in sorted(os.listdir(full)):
                            sub_full = os.path.join(full, sub)
                            if os.path.ismount(sub_full) and sub_full not in drives:
                                drives.append(sub_full)
                    except PermissionError:
                        pass
        except PermissionError:
            pass

    return sorted(drives)


def has_apic(filepath):
    """Return APIC frame size in bytes, or 0 if none."""
    try:
        with open(filepath, 'rb') as f:
            hdr = f.read(10)
            if hdr[:3] != b'ID3':
                return 0
            id3_size = (
                ((hdr[6] & 0x7f) << 21) |
                ((hdr[7] & 0x7f) << 14) |
                ((hdr[8] & 0x7f) << 7) |
                (hdr[9] & 0x7f)
            )
            tag_size = id3_size + 10
            pos = 10
            while pos + 10 <= tag_size:
                f.seek(pos)
                frame = f.read(10)
                if frame == b'\x00' * 10:
                    break
                frame_sz = (
                    (frame[4] << 24) |
                    (frame[5] << 16) |
                    (frame[6] << 8) |
                    frame[7]
                )
                if frame[:4] == b'APIC':
                    return frame_sz
                pos += frame_sz + 10
    except Exception:
        pass
    return 0


def strip_apic(filepath):
    """Losslessly remove APIC via ffmpeg stream copy. Returns True on success."""
    root, ext = os.path.splitext(filepath)
    tmp = root + '_noart' + ext
    cmd = [
        'ffmpeg', '-y',
        '-i', filepath,
        '-c', 'copy',
        '-map_metadata', '0',
        '-vn',
        tmp
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode == 0 and os.path.exists(tmp):
            os.replace(tmp, filepath)
            return True
    except Exception:
        pass
    if os.path.exists(tmp):
        try:
            os.remove(tmp)
        except Exception:
            pass
    return False


def check_filename(base):
    """Analyse a base filename (no extension) for device compatibility.
    Returns (ok: bool, artist: str, title: str, issues: list)."""
    issues = []
    artist = ''
    title = ''

    cleaned = base.replace('_', ' ')
    sep = cleaned.find(' - ')
    if sep >= 0:
        artist = cleaned[:sep].strip()
        title = cleaned[sep + 3:].strip()
    else:
        title = cleaned.strip()

    full_path_len = 1 + 4 + len(base)
    if full_path_len > PATH_LEN:
        issues.append(f"Path would be {full_path_len} chars (max {PATH_LEN})")
    if len(artist) > ARTIST_LEN:
        issues.append(f"Artist is {len(artist)} chars (max {ARTIST_LEN})")
    if len(title) > TITLE_LEN:
        issues.append(f"Title is {len(title)} chars (max {TITLE_LEN})")

    return (len(issues) == 0, artist, title, issues)


def trimmed_name(base):
    """Return trimmed version of base filename that fits device limits."""
    cleaned = base.replace('_', ' ')
    sep = cleaned.find(' - ')
    if sep >= 0:
        artist_part = cleaned[:sep].strip()
        title_part = cleaned[sep + 3:].strip()
        if len(artist_part) > TRIM_ARTIST_TARGET:
            artist_part = artist_part[:TRIM_ARTIST_TARGET - 3].rstrip() + '...'
        if len(title_part) > TRIM_TITLE_TARGET:
            title_part = title_part[:TRIM_TITLE_TARGET - 3].rstrip() + '...'
        trimmed = f"{artist_part} - {title_part}"
    else:
        title_part = cleaned.strip()
        if len(title_part) > TRIM_TITLE_TARGET:
            title_part = title_part[:TRIM_TITLE_TARGET - 3].rstrip() + '...'
        trimmed = title_part
    max_total = PATH_LEN - 1 - 4
    if len(trimmed) > max_total:
        trimmed = trimmed[:max_total - 3].rstrip() + '...'
    return trimmed


# =============================================================================
# GUI Application
# =============================================================================
class MP3CleanerApp:
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.geometry(f"{APP_WIDTH}x{APP_HEIGHT}")
        root.minsize(640, 480)

        # ---- State ----
        self.selected_path = tk.StringVar()
        self.trim_names_var = tk.BooleanVar(value=True)
        self.running = False
        self.cancelled = False

        # ---- Color scheme ----
        self.colors = {
            'bg':        '#1e1e2e',
            'fg':        '#cdd6f4',
            'select':    '#313244',
            'accent':    '#89b4fa',
            'success':   '#a6e3a1',
            'warning':   '#f9e2af',
            'error':     '#f38ba8',
            'btn_green': '#2e8b57',
            'btn_green_hover': '#3cb371',
            'log_bg':    '#11111b',
            'log_fg':    '#cdd6f4',
            'frame_bg':  '#181825',
        }
        root.configure(bg=self.colors['bg'])

        # ---- Build UI ----
        self._build_ui()

        # ---- Bind keyboard shortcuts ----
        root.bind('<Control-r>', lambda e: self.refresh_drives())
        root.bind('<Control-s>', lambda e: self.run_strip())
        root.bind('<Escape>', lambda e: root.destroy())

        # ---- Initial drive scan ----
        self.refresh_drives()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        root = self.root
        bg = self.colors['bg']
        fg = self.colors['fg']
        sel = self.colors['select']
        frame_bg = self.colors['frame_bg']

        # ---- Top bar: title ----
        title_frame = tk.Frame(root, bg=bg, height=40)
        title_frame.pack(fill='x', padx=12, pady=(10, 0))
        title_frame.pack_propagate(False)
        tk.Label(
            title_frame, text=APP_NAME,
            font=('Segoe UI', 14, 'bold'),
            bg=bg, fg=self.colors['accent']
        ).pack(side='left')

        # ---- Drive selection frame ----
        drive_frame = tk.LabelFrame(
            root, text="  Drive Selection  ",
            font=('Segoe UI', 10),
            bg=frame_bg, fg=fg,
            padx=10, pady=8,
            relief='groove', bd=1,
            labelanchor='nw',
        )
        drive_frame.pack(fill='x', padx=12, pady=(8, 0))

        inner = tk.Frame(drive_frame, bg=frame_bg)
        inner.pack(fill='x')

        self.drive_combo = ttk.Combobox(
            inner, textvariable=self.selected_path,
            font=('Segoe UI', 11),
            state='readonly',
            width=50,
        )
        self.drive_combo.pack(side='left', fill='x', expand=True)

        self.refresh_btn = tk.Button(
            inner, text="⟳ Refresh",
            font=('Segoe UI', 10),
            bg=self.colors['select'], fg=fg,
            activebackground=self.colors['accent'],
            relief='flat', padx=10, cursor='hand2',
            command=self.refresh_drives,
        )
        self.refresh_btn.pack(side='right', padx=(8, 0))

        # ---- Options frame ----
        opt_frame = tk.LabelFrame(
            root, text="  Options  ",
            font=('Segoe UI', 10),
            bg=frame_bg, fg=fg,
            padx=10, pady=6,
            relief='groove', bd=1,
            labelanchor='nw',
        )
        opt_frame.pack(fill='x', padx=12, pady=(6, 0))

        self.trim_check = tk.Checkbutton(
            opt_frame,
            text="Truncate long filenames to fit device limits (PATH=288, TITLE=256, ARTIST=128)",
            variable=self.trim_names_var,
            font=('Segoe UI', 9),
            bg=frame_bg, fg=fg,
            selectcolor=frame_bg,
            activebackground=frame_bg,
            activeforeground=fg,
            cursor='hand2',
        )
        self.trim_check.pack(anchor='w')

        # ---- Big green strip button ----
        self.strip_btn = tk.Button(
            root,
            text="STRIP ALBUM ART & CLEAN FILES",
            font=('Segoe UI', 14, 'bold'),
            bg=self.colors['btn_green'],
            fg='white',
            activebackground=self.colors['btn_green_hover'],
            activeforeground='white',
            relief='flat',
            bd=0,
            padx=20, pady=14,
            cursor='hand2',
            command=self.run_strip,
        )
        self.strip_btn.pack(fill='x', padx=12, pady=(8, 0))

        # ---- Log area ----
        log_frame = tk.LabelFrame(
            root, text="  Log  ",
            font=('Segoe UI', 10),
            bg=frame_bg, fg=fg,
            padx=6, pady=4,
            relief='groove', bd=1,
            labelanchor='nw',
        )
        log_frame.pack(fill='both', expand=True, padx=12, pady=(8, 10))

        self.log_text = ScrolledText(
            log_frame,
            font=('Consolas', 9),
            bg=self.colors['log_bg'],
            fg=self.colors['log_fg'],
            insertbackground=fg,
            relief='flat',
            bd=0,
            state='disabled',
            wrap='word',
            height=12,
        )
        self.log_text.pack(fill='both', expand=True)

        # ---- Status bar ----
        self.status_bar = tk.Label(
            root,
            text="Ready",
            font=('Segoe UI', 9),
            bg=self.colors['log_bg'],
            fg=self.colors['log_fg'],
            anchor='w',
            padx=10, pady=3,
        )
        self.status_bar.pack(fill='x', side='bottom')

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------
    def log(self, msg, level='info'):
        tag = level if level in ('success', 'warning', 'error') else 'info'
        color = self.colors.get(tag, self.colors['log_fg'])

        self.log_text.configure(state='normal')
        self.log_text.insert('end', msg + '\n', tag)
        self.log_text.tag_configure(tag, foreground=color)
        self.log_text.see('end')
        self.log_text.configure(state='disabled')
        self.root.update_idletasks()

    def set_status(self, msg):
        self.status_bar.configure(text=msg)
        self.root.update_idletasks()

    # ------------------------------------------------------------------
    # Drive refresh
    # ------------------------------------------------------------------
    def refresh_drives(self):
        drives = find_removable_drives()

        # Also check if a manual path was previously selected
        self.drive_combo['values'] = drives

        if drives:
            if not self.selected_path.get() or self.selected_path.get() not in drives:
                self.selected_path.set(drives[0])
            status = f"{len(drives)} drive(s) found"
        else:
            self.selected_path.set('')
            status = "No removable drives found — plug in USB and click Refresh, or type a path"

        self.set_status(status)
        self.log(f"[system] Drive scan: {len(drives)} removable volume(s) found")

    # ------------------------------------------------------------------
    # Run strip (called from button or Ctrl+S)
    # ------------------------------------------------------------------
    def run_strip(self):
        if self.running:
            self.log("Already running — wait for completion.", 'warning')
            return

        path = self.selected_path.get()
        if not path:
            messagebox.showwarning("No Drive", "Select a drive or enter a path first.", parent=self.root)
            return
        if not os.path.isdir(path):
            messagebox.showerror("Invalid Path", f"'{path}' does not exist or is not a directory.", parent=self.root)
            return

        # Confirm
        if not messagebox.askyesno(
            "Confirm",
            f"This will strip album art from MP3 files in:\n  {path}\n\n"
            f"{'Long filenames will also be truncated.' if self.trim_names_var.get() else ''}\n\n"
            "Continue?",
            parent=self.root
        ):
            return

        self.running = True
        self.cancelled = False
        self.strip_btn.configure(
            text="RUNNING...  (press Cancel to abort)",
            bg='#b91c1c',
            activebackground='#dc2626',
            command=self.cancel_strip,
        )
        self.log("=" * 60)
        self.log(f"[start] Processing: {path}")
        self.log(f"[start] Trim filenames: {'ON' if self.trim_names_var.get() else 'OFF'}")
        self.log("=" * 60)

        # Run in background thread so GUI stays responsive
        thread = threading.Thread(
            target=self._strip_worker,
            args=(path, self.trim_names_var.get()),
            daemon=True,
        )
        thread.start()

    def cancel_strip(self):
        self.cancelled = True
        self.log("[user] Cancelling... (will finish current file)", 'warning')

    def _strip_worker(self, path, trim_names):
        try:
            files = sorted(glob.glob(os.path.join(path, '*.mp3')))
            if not files:
                self.log(f"[scan] No .mp3 files found in '{path}'", 'warning')
                self._finish("No files to process")
                return

            self.log(f"[scan] Found {len(files)} MP3 files")
            self.set_status("Scanning files for album art...")

            # ---- Scan phase ----
            to_strip = []
            name_issues = []
            name_issue_files = []

            for f in files:
                if self.cancelled:
                    self._finish("Cancelled during scan")
                    return

                base = os.path.splitext(os.path.basename(f))[0]
                apic_sz = has_apic(f)
                if apic_sz > 0:
                    to_strip.append((f, apic_sz))

                ok, artist, title, issues = check_filename(base)
                if not ok:
                    name_issues.append(issues)
                    name_issue_files.append((f, issues, base))

            # ---- Report scan results ----
            self.log(f"\n[scan] Files with album art: {len(to_strip)}")
            if to_strip:
                total_kb = sum(sz for _, sz in to_strip) / 1024
                self.log(f"[scan] Total album art data: {total_kb:.0f} KB")
                # Top 5
                for f, sz in sorted(to_strip, key=lambda x: -x[1])[:5]:
                    self.log(f"  {sz/1024:>8.0f} KB  {os.path.basename(f)}", 'warning')
            else:
                self.log("[scan] No files with album art — nothing to strip!", 'success')

            if name_issues:
                self.log(f"\n[scan] Files with filename issues: {len(name_issues)}")
                for f, issues, base in name_issue_files[:10]:
                    fn = os.path.basename(f)
                    for issue in issues:
                        self.log(f"  ⚠ {fn}: {issue}", 'warning')
                if len(name_issues) > 10:
                    self.log(f"  ... and {len(name_issues) - 10} more")
            else:
                self.log("[scan] All filenames fit device limits.", 'success')

            # ---- Strip phase ----
            if to_strip:
                self.log(f"\n[strip] Removing album art from {len(to_strip)} files...")
                ok = fail = 0
                for i, (f, sz) in enumerate(to_strip):
                    if self.cancelled:
                        self._finish("Cancelled during strip")
                        return

                    fn = os.path.basename(f)
                    self.set_status(f"Stripping {i+1}/{len(to_strip)}: {fn[:50]}...")

                    if strip_apic(f):
                        ok += 1
                        if ok <= 5 or ok % 50 == 0:
                            self.log(f"[strip] ✓ ({ok}/{len(to_strip)}) {fn}", 'success')
                    else:
                        fail += 1
                        self.log(f"[strip] ✗ FAILED: {fn}", 'error')

                self.log(f"\n[strip] Result: {ok} OK, {fail} FAIL", 'success' if fail == 0 else 'warning')

            # ---- Trim names phase ----
            if trim_names and name_issue_files:
                self.log(f"\n[trim] Truncating {len(name_issue_files)} long filenames...")
                trimmed_count = 0
                for f, issues, base in name_issue_files:
                    if self.cancelled:
                        self._finish("Cancelled during trim")
                        return

                    new_base = trimmed_name(base)
                    new_name = new_base + '.mp3'
                    new_path = os.path.join(os.path.dirname(f), new_name)

                    if os.path.exists(new_path) and new_path != f:
                        self.log(f"[trim] SKIP (collision): {os.path.basename(f)}", 'warning')
                        continue

                    os.rename(f, new_path)
                    trimmed_count += 1
                    if trimmed_count <= 5:
                        self.log(f"[trim]  {os.path.basename(f)}")
                        self.log(f"       → {new_name}")

                self.log(f"[trim] Trimmed {trimmed_count} filenames", 'success')

            # ---- Final summary ----
            self.log("\n" + "=" * 60)
            self.log("[done] All done!", 'success')

            # Re-scan for summary
            files_now = sorted(glob.glob(os.path.join(path, '*.mp3')))
            still_art = sum(1 for f in files_now if has_apic(f) > 0)
            name_issues_now = 0
            for f in files_now:
                base = os.path.splitext(os.path.basename(f))[0]
                ok, _, _, _ = check_filename(base)
                if not ok:
                    name_issues_now += 1

            self.log(f"  Files total:          {len(files_now)}")
            self.log(f"  Still have album art: {still_art}")
            self.log(f"  Filename issues:      {name_issues_now}")
            self.log("=" * 60)

            self._finish(f"Done — {len(files_now)} files, {still_art} with art remaining")

        except Exception as e:
            self.log(f"[error] {e}", 'error')
            self._finish(f"Error: {e}")

    def _finish(self, status_text):
        self.running = False
        self.cancelled = False
        self.strip_btn.configure(
            text="STRIP ALBUM ART & CLEAN FILES",
            bg=self.colors['btn_green'],
            activebackground=self.colors['btn_green_hover'],
            command=self.run_strip,
        )
        self.set_status(status_text)


# =============================================================================
# Entry point
# =============================================================================
def main():
    root = tk.Tk()
    app = MP3CleanerApp(root)
    root.mainloop()


if __name__ == '__main__':
    main()