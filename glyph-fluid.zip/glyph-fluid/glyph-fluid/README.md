# Glyph Fluid

Particle fluid sim on the Nothing Phone (3) 25x25 Glyph Matrix, driven by the accelerometer
(tilt to pour, shake to slosh). The app also shows a mirror of the matrix on screen.

## Setup

1. Get the Glyph Matrix SDK `.aar` from Nothing's developer kit
   (github.com/Nothing-Developer-Programme/GlyphMatrix-Developer-Kit) and put it in `app/libs/`.
2. Enable Glyph debug access on the phone (lasts ~48 h, re-run when it expires):
   ```
   adb shell settings put global nt_glyph_interface_debug_enable 1
   ```
3. Open this folder in Android Studio, let it sync, run on the phone.

## Tuning (MainActivity.kt, top)

- `gravityScale`: how heavy the fluid feels.
- `flipX` / `flipY`: use if the fluid runs the wrong way (the matrix is on the back, so X is mirrored).

Particle count, stiffness and viscosity are constants in `FluidSim.kt`.

## New features (v1.1)

### Temporary volume display
Pressing the device volume up/down keys temporarily replaces the clock with the current
`STREAM_MUSIC` volume percentage (0-100). The percentage stays on screen for 2000 ms after the
most recent key press; each new press restarts the timer. When the timer expires, the normal
display (clock, or music visualizer if music is playing) is restored.

Detected via the public `ACTION_VOLUME_CHANGED` broadcast, filtered to `STREAM_MUSIC` only.

### Music visualizer (Stage 2)
When music is playing, the clock is replaced with a horizontal audio spectrum rendered across the
matrix: bass on the left, treble on the right, with 4 px horizontal margins (17 usable columns).
Bar heights respond to loudness with per-band attack/release smoothing and global rolling
normalization.

**Important platform limitation (verified on Nothing Phone (3)):** capturing the system output mix
via `android.media.audiofx.Visualizer` attached to audio session 0 **fails** on Nothing OS
(`AudioFlinger: no permission for AUDIO_SESSION_OUTPUT_MIX`, `Visualizer initCheck failed -3`).
The visualizer therefore degrades gracefully to silent (fluid background only) rather than
crashing. No microphone fallback is used, and no hidden/privileged APIs (`MODIFY_AUDIO_SETTINGS`)
are required. If Nothing enables output-mix capture in a future OS update, the visualizer will
activate automatically.

The visualizer requires `android.permission.RECORD_AUDIO`, requested at runtime on first launch.
Denial leaves the visualizer silent; granting it (and reopening the app) retries capture.

### Display priority
Volume percentage > music visualizer > clock. The fluid simulation is a persistent background
layer and runs uninterrupted under all three foreground states. There is a single rendering loop
(`FluidEngine`); no competing frame-update loops were added.

## Caveats

The SDK calls (`GlyphMatrixManager`, `Glyph.DEVICE_23112`, `setMatrixFrame`, `turnOff`) were written from
memory of Nothing's README and not compiled here. If the build complains, check names against the
SDK's own sample. Frames are sent as 0..255 brightness ints; if the display looks wrong, check how the
sample encodes pixel values.
