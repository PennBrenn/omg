package dev.glyphfluid

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.HandlerThread
import android.os.Process
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.atomic.AtomicBoolean

class AudioPlaybackCaptureTestActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var btnRequest: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    private var projectionManager: MediaProjectionManager? = null
    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: android.os.Handler? = null
    private val capturing = AtomicBoolean(false)

    private val REQUEST_MEDIA_PROJECTION = 1001
    private val REQUEST_RECORD_AUDIO = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            Log.e("APCTest", "=== UNCAUGHT EXCEPTION ===")
            Log.e("APCTest", "PID: ${Process.myPid()}")
            Log.e("APCTest", "Message: ${throwable.message}")
            throwable.printStackTrace()
            logToUi("CRASH: ${throwable.message}")
            throwable.stackTrace.forEach { Log.e("APCTest", "  at ${it.toString()}") }
            System.exit(1)
        }

        status = TextView(this).apply {
            textSize = 14f
            setPadding(16, 16, 16, 16)
            text = "AudioPlaybackCapture Diagnostic\n\nPID: ${Process.myPid()}\n\nNot started"
        }
        btnRequest = Button(this).apply {
            text = "1. Request MediaProjection"
            setOnClickListener { requestMediaProjection() }
        }
        btnStart = Button(this).apply {
            text = "2. Start AudioCapture"
            isEnabled = false
            setOnClickListener { startCapture() }
        }
        btnStop = Button(this).apply {
            text = "3. Stop Capture"
            isEnabled = false
            setOnClickListener { stopCapture() }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.BLACK)
            addView(status)
            addView(btnRequest)
            addView(btnStart)
            addView(btnStop)
        }
        setContentView(layout)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager?

        // Start foreground service immediately so it's running when getMediaProjection() is called
        logToUi("Starting foreground service in onCreate()...")
        val fsIntent = Intent(this, MediaProjectionForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            startForegroundService(fsIntent)
        } else {
            startService(fsIntent)
        }
        logToUi("Foreground service start requested in onCreate()")

        logToUi("=== ACTIVITY CREATED ===")
        logToUi("PID: ${Process.myPid()}")
        logToUi("RECORD_AUDIO granted: ${checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED}")
        logToUi("MediaProjectionManager available: ${projectionManager != null}")
        logToUi("")
    }

    override fun onPause() {
        super.onPause()
        logToUi("=== ON PAUSE ===")
        logToUi("PID: ${Process.myPid()}")
    }

    override fun onResume() {
        super.onResume()
        logToUi("=== ON RESUME ===")
        logToUi("PID: ${Process.myPid()}")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            logToUi("=== ON ACTIVITY RESULT ===")
            logToUi("PID: ${Process.myPid()}")
            logToUi("requestCode: $requestCode, resultCode: $resultCode")
            if (resultCode == Activity.RESULT_OK && data != null) {
                logToUi("MediaProjection granted")
                logToUi("Calling getMediaProjection()...")
                mediaProjection = projectionManager?.getMediaProjection(resultCode, data)
                logToUi("MediaProjection obtained: ${mediaProjection != null}")
                if (mediaProjection != null) {
                    logToUi("MediaProjection class: ${mediaProjection?.javaClass?.name}")
                }
                btnStart.isEnabled = true
                logToUi("Start button enabled")
            } else {
                logToUi("MediaProjection DENIED by user")
            }
        }
    }

    private fun requestMediaProjection() {
        logToUi("=== REQUEST MEDIAPROJECTION ===")
        logToUi("PID: ${Process.myPid()}")
        try {
            logToUi("Calling createScreenCaptureIntent()...")
            val intent = projectionManager?.createScreenCaptureIntent()
            if (intent == null) {
                logToUi("createScreenCaptureIntent() returned NULL")
            } else {
                logToUi("Intent created, launching startActivityForResult...")
                startActivityForResult(intent, REQUEST_MEDIA_PROJECTION)
            }
        } catch (e: Exception) {
            logToUi("requestMediaProjection FAILED: ${e.message}")
            e.printStackTrace()
        }
    }

    private fun startCapture() {
        logToUi("=== START CAPTURE ===")
        logToUi("PID: ${Process.myPid()}")
        val mp = mediaProjection
        if (mp == null) {
            logToUi("MediaProjection not available")
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            logToUi("RECORD_AUDIO not granted")
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQUEST_RECORD_AUDIO)
            return
        }

        try {
            logToUi("Step 1: Building AudioPlaybackCaptureConfiguration...")
            val config = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .build()
            logToUi("Step 1 done: Config created, usages: ${config.matchingUsages.contentToString()}")

            logToUi("Step 2: Building AudioFormat...")
            val audioFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            logToUi("Step 2 done: AudioFormat created")

            logToUi("Step 3: Building AudioRecord with playback capture config...")
            audioRecord = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(config)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(4096)
                .build()
            logToUi("Step 3 done: AudioRecord state: ${audioRecord!!.state} (${AudioRecord.STATE_INITIALIZED}=init)")

            if (audioRecord!!.state == AudioRecord.STATE_INITIALIZED) {
                logToUi("Step 4: Starting recording...")
                audioRecord!!.startRecording()
                logToUi("Step 4 done: Recording STARTED")
                btnStart.isEnabled = false
                btnStop.isEnabled = true
                capturing.set(true)
                startCaptureThread()
            } else {
                logToUi("AudioRecord FAILED to initialize (state: ${audioRecord!!.state})")
            }
        } catch (e: Exception) {
            logToUi("Capture FAILED at exception: ${e.message}")
            e.printStackTrace()
        }
    }

    private fun startCaptureThread() {
        logToUi("=== START CAPTURE THREAD ===")
        logToUi("PID: ${Process.myPid()}")
        captureThread = HandlerThread("apc-test").apply { start() }
        captureHandler = android.os.Handler(captureThread!!.looper)
        val buf = ShortArray(1024)
        var reads = 0
        var nonZeroReads = 0
        var maxRms = 0

        captureHandler!!.post(object : Runnable {
            override fun run() {
                if (!capturing.get()) return
                val read = audioRecord!!.read(buf, 0, buf.size)
                if (read > 0) {
                    reads++
                    var sumSquares = 0L
                    var hasNonZero = false
                    var peak = 0
                    for (i in 0 until read) {
                        val sample = buf[i].toInt()
                        sumSquares += sample.toLong() * sample
                        if (sample != 0) hasNonZero = true
                        val abs = if (sample < 0) -sample else sample
                        if (abs > peak) peak = abs
                    }
                    if (hasNonZero) nonZeroReads++
                    val rms = Math.sqrt(sumSquares.toDouble() / read).toInt()
                    if (rms > maxRms) maxRms = rms
                    if (reads % 10 == 0) {
                        logToUi("Reads: $reads, NonZero: $nonZeroReads, RMS: $rms, Peak: $peak, MaxRMS: $maxRms, Last: $read")
                    }
                }
                captureHandler!!.postDelayed(this, 50)
            }
        })
    }

    private fun stopCapture() {
        logToUi("=== STOP CAPTURE ===")
        logToUi("PID: ${Process.myPid()}")
        capturing.set(false)
        captureHandler?.removeCallbacksAndMessages(null)
        captureThread?.quitSafely()
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
        mediaProjection?.stop()
        mediaProjection = null
        // Stop foreground service
        try {
            stopService(Intent(this, MediaProjectionForegroundService::class.java))
        } catch (e: Exception) {
            logToUi("stopService failed: ${e.message}")
        }
        btnStart.isEnabled = true
        btnStop.isEnabled = false
        logToUi("STOPPED")
    }

    private fun logToUi(msg: String) {
        Log.d("APCTest", msg)
        runOnUiThread {
            val current = status.text.toString()
            val updated = current + "\n[$msg]"
            val lines = updated.split("\n")
            val finalText = if (25 < lines.size) lines.drop(lines.size - 25).joinToString("\n") else updated
            status.text = finalText
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        logToUi("=== ON DESTROY ===")
        logToUi("PID: ${Process.myPid()}")
        stopCapture()
    }
}
