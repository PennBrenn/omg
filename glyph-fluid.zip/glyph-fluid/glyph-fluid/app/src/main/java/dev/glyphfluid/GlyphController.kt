package dev.glyphfluid

import android.content.ComponentName
import android.content.Context
import android.util.Log
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphMatrixManager

/**
 * Thin wrapper around Nothing's Glyph Matrix SDK for the Phone (3).
 * appMode = true for a normal app (setAppMatrixFrame), false when running as a Glyph Toy (setMatrixFrame).
 */
class GlyphController(context: Context, private val appMode: Boolean) {

    private val appContext = context.applicationContext
    private var gm: GlyphMatrixManager? = null

    @Volatile var ready = false
        private set

    fun start(onReady: (Boolean) -> Unit = {}) {
        val callback = object : GlyphMatrixManager.Callback {
            override fun onServiceConnected(name: ComponentName?) {
                try {
                    gm?.register(Glyph.DEVICE_23112) // Phone (3)
                    ready = true
                    onReady(true)
                } catch (e: Exception) {
                    Log.e("GlyphController", "register failed", e)
                    onReady(false)
                }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                ready = false
                onReady(false)
            }
        }
        gm = GlyphMatrixManager.getInstance(appContext).also { it.init(callback) }
    }

    /** frame: 625 brightness values (0..255), row-major. */
    fun push(frame: IntArray) {
        if (!ready) return
        try {
            if (appMode) gm?.setAppMatrixFrame(frame) else gm?.setMatrixFrame(frame)
        } catch (e: Exception) {
            Log.e("GlyphController", "push failed", e)
        }
    }

    fun stop() {
        val wasReady = ready
        ready = false
        try {
            if (wasReady) { if (appMode) gm?.closeAppMatrix() else gm?.turnOff() }
            gm?.unInit()
        } catch (e: Exception) {
            Log.e("GlyphController", "stop failed", e)
        }
        gm = null
    }
}
