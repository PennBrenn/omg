package dev.glyphfluid

/**
 * Renders a volume percentage (0-100) plus a '%' mark in a 3x5 pixel font,
 * centered on the matrix with the same placement as [PixelClock].
 *
 * Drawn flat over whatever the fluid simulation already rendered into the frame.
 * Stateless and thread-safe: safe to call from the FluidEngine sim thread.
 */
object PixelVolume {

    private const val LEVEL = 255

    // 3 wide x 5 tall, rows top to bottom, '1' = lit. Same digit font as PixelClock.
    private val GLYPHS = arrayOf(
        "111101101101111", // 0
        "010110010010111", // 1
        "111001111100111", // 2
        "111001111001111", // 3
        "101101111001001", // 4
        "111100111001111", // 5
        "111100111101111", // 6
        "111001001001001", // 7
        "111101111101111", // 8
        "111101111001111", // 9
    )

    // 3x5 '%' mark: corner dots top/bottom, centre dot.
    private val PCT = "101010000010101"

    fun draw(frame: IntArray, percent: Int) {
        val n = FluidSim.SIZE
        val y0 = (n - 5) / 2
        // Right-justify into 3 digit slots then a '%' slot: fixed 12 px wide, centered.
        val text = "%3d%%".format(percent.coerceIn(0, 100))
        val totalW = 4 * 3
        val x0 = (n - totalW) / 2
        for (i in text.indices) {
            val ch = text[i]
            val gx = when {
                ch == '%' -> PCT
                ch == ' ' -> continue
                else -> GLYPHS[ch.digitToInt()]
            }
            val sx = x0 + i * 3
            for (r in 0 until 5) {
                for (c in 0 until 3) {
                    if (gx[r * 3 + c] == '1') {
                        frame[(y0 + r) * n + (sx + c)] = LEVEL
                    }
                }
            }
        }
    }
}