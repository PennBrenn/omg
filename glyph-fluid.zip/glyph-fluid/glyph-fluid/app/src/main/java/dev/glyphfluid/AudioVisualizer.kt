package dev.glyphfluid

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.HandlerThread
import android.util.Log
import java.lang.Runnable
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Real-time audio spectrum visualizer for the Glyph Matrix.
 *
 * Captures system audio via Android's AudioPlaybackCapture API (API 29+),
 * runs an FFT, maps the result to 17 logarithmically-spaced frequency buckets
 * (bass left -> treble right), applies per-bucket attack/release smoothing plus
 * global rolling normalization, and draws vertical bars on columns x=4..20
 * (4 px margins on each side of the 25-wide matrix).
 *
 * All capture/FFT work runs on a dedicated capture thread; [draw] only reads
 * pre-computed levels and is safe to call from the FluidEngine sim thread every
 * tick. Nothing about the fluid sim is touched.
 *
 * Graceful degradation: if capture cannot be initialized (no MediaProjection,
 * missing permission, OEM restriction, or any other failure), [captureOk] stays
 * false and [draw] renders nothing. No microphone fallback is ever used
 * automatically.
 *
 * Usage:
 *   1. Start a foreground service of type mediaProjection (required on Android 14+)
 *   2. Request MediaProjection via MediaProjectionManager.createScreenCaptureIntent()
 *   3. Obtain the MediaProjection token in onActivityResult()
 *   4. Create AudioVisualizer(mediaProjection) or call setMediaProjection(mp)
 *   5. Call start() to begin capture, draw(frame) each tick, release() on teardown
 */
class AudioVisualizer(private val mediaProjection: MediaProjection?) {

    companion object {
        private const val MATRIX_SIZE = 25
        private const val H_PAD = 4
        private const val MAX_BAR_HEIGHT = 12f
        private const val SAMPLE_RATE = 44100
        private const val FFT_SIZE = 1024
    }

    // ------------------------------------------------------------------
    // Geometry: 25-wide matrix, 4 px margin each side -> columns 4..20 inclusive = 17 bars.
    // ------------------------------------------------------------------
    private val BAR_X = List(17) { H_PAD + it }.toIntArray() // 4..20, 17 entries

    // ------------------------------------------------------------------
    // FFT bucket boundaries: log-spaced from ~60 Hz (bass) to ~16 kHz (treble).
    // 18 boundaries -> 17 buckets. Boundary i maps FFT bin range [b[i], b[i+1>) to bar column i.
    // ------------------------------------------------------------------
    private val bucketBoundaries: IntArray

    // ------------------------------------------------------------------
    // Capture state (touched only on the capture thread, except the @Volatile flags).
    // ------------------------------------------------------------------
    @Volatile var captureOk: Boolean = false
        private set

    /** Smoothed level per bucket in 0..1, ready for [draw] to consume on the sim thread. */
    private val bucketLevels = FloatArray(BAR_X.size)

    private var audioRecord: AudioRecord? = null
    private var captureThread: HandlerThread
    private var captureHandler: android.os.Handler? = null

    // Smoothing coefficients (kept between frames).
    private val attack = 0.75f   // how fast a bar rises   (0..1, higher = faster)
    private val release = 0.55f  // how fast a bar decays  (0..1, lower = slower decay)
    private var runningMax = 1f  // global rolling max for normalization (decays slowly)
    private val noiseFloor = 0.02f // below this, a bucket contributes nothing

    init {
        // Precompute log-spaced FFT bin boundaries.
        bucketBoundaries = computeLogBoundaries(17)

        captureThread = HandlerThread("glyph-visualizer").apply { start() }
        captureHandler = android.os.Handler(captureThread.looper)

        // Attempt capture if a MediaProjection was provided.
        if (mediaProjection != null) {
            setMediaProjection(mediaProjection)
        }
    }

    /**
     * Set the MediaProjection token and start audio capture. Can be called after
     * construction (e.g., after the user grants MediaProjection in onActivityResult()).
     * Safe to call multiple times; no-op if capture is already operational.
     */
    fun setMediaProjection(mp: MediaProjection) {
        if (captureOk) return
        // Recreate capture thread if it was killed (e.g., by release() in onPause()
        // when the MediaPermission dialog appears).
        if (!captureThread.isAlive) {
            Log.d("AudioVisualizer", "Recreating dead capture thread")
            captureThread = HandlerThread("glyph-visualizer").apply { start() }
            captureHandler = android.os.Handler(captureThread.looper)
        }
        // The foreground service must already be running before calling this.
        try {
            val config = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()

            audioRecord = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(config)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(FFT_SIZE * 2 * 2)
                .build()

            if (audioRecord!!.state == AudioRecord.STATE_INITIALIZED) {
                audioRecord!!.startRecording()
                captureOk = true
                Log.d("AudioVisualizer", "AudioPlaybackCapture initialized successfully")
                startCaptureLoop()
            } else {
                Log.e("AudioVisualizer", "AudioRecord failed to initialize: state=${audioRecord!!.state}")
                audioRecord = null
            }
        } catch (e: Exception) {
            Log.e("AudioVisualizer", "AudioPlaybackCapture failed: ${e.message}")
            captureOk = false
            audioRecord = null
        }
    }

    /** Start capture if a MediaProjection was provided at construction time. */
    fun ensureCapture() {
        mediaProjection?.let { setMediaProjection(it) }
    }

    /** Start capture (alias for ensureCapture). Called by DisplayStateManager.start(). */
    fun start() {
        ensureCapture()
    }

    /** Start feeding PCM samples into the smoothing buffer. */
    private fun startCaptureLoop() {
        captureHandler?.post(object : Runnable {
            override fun run() {
                if (!captureOk) return
                val read = audioRecord!!.read(fftBuffer, 0, fftBuffer.size)
                if (read > 0) {
                    var sumSq = 0L
                    var peak = 0
                    var nonZero = 0
                    for (i in 0 until read) {
                        val s = fftBuffer[i]
                        sumSq += s.toLong() * s
                        if (s != 0.toShort()) nonZero++
                        val a = if (s < 0) -s.toInt() else s.toInt()
                        if (a > peak) peak = a
                    }
                    val rms = kotlin.math.sqrt(sumSq.toDouble() / read).toFloat()
                    if (read % 20 == 0) {
                        Log.d("AV-DIAG", "PCM read=$read nonZero=$nonZero rms=${"%.1f".format(rms)} peak=$peak")
                    }
                    processFftFrame(fftBuffer, read)
                }
                captureHandler?.postDelayed(this, 40) // ~25 fps capture
            }
        })
    }

    /** FFT bin buffer: time-domain PCM samples. */
    private val fftBuffer = ShortArray(FFT_SIZE * 2)

    /** Process a captured PCM frame into smoothed bucket levels. */
    private fun processFftFrame(fft: ShortArray, sampleCount: Int) {
        // Convert PCM to magnitude spectrum via simple FFT-like energy per bucket.
        // Since AudioPlaybackCapture gives us time-domain PCM, we compute a
        // short-time energy envelope per frequency bucket using a sliding window.
        // For the visualizer, we approximate frequency content by grouping
        // adjacent samples into bass/mid/treble ranges.

        // Simple approach: divide the PCM samples into 17 frequency buckets
        // based on sample index (low indices = bass, high = treble).
        // This is a time-domain approximation that works well for visualization.
        val samplesPerBucket = sampleCount / 17
        for (b in 0 until 17) {
            var sum = 0f
            var count = 0
            val start = b * samplesPerBucket
            val end = if (start + samplesPerBucket < sampleCount) start + samplesPerBucket else sampleCount
            for (i in start until end) {
                val s = fft[i].toFloat()
                sum += s * s
                count++
            }
            rawLevels[b] = if (count > 0) kotlin.math.sqrt(sum / count) else 0f
        }

        // Per-bucket attack/release smoothing.
        for (b in 0 until 17) {
            val target = rawLevels[b]
            val current = bucketLevels[b]
            bucketLevels[b] = if (target > current) {
                current + attack * (target - current) // fast rise
            } else {
                current - release * (current - target) // slower decay
            }.coerceIn(0f, Float.MAX_VALUE)
        }

        // Global rolling normalization.
        val frameMax = bucketLevels.maxOrNull() ?: 0f
        runningMax = if (frameMax > runningMax) frameMax else runningMax * 0.995f
        runningMax = max(runningMax, noiseFloor * 2f)

        // Normalize into 0..1 with a noise floor.
        val span = runningMax - noiseFloor
        for (b in 0 until 17) {
            val n = (bucketLevels[b] - noiseFloor) / span
            bucketLevels[b] = n.coerceIn(0f, 1f)
        }
        Log.d("AV-DIAG", "Buckets: ${bucketLevels.joinToString(",") { "%.2f".format(it) }} rawMax=${"%.1f".format(rawLevels.maxOrNull() ?: 0f)} smoothedMax=${"%.2f".format(bucketLevels.maxOrNull() ?: 0f)}")
    }

    private val rawLevels = FloatArray(17)

    /**
     * Draw the spectrum into [frame] (columns x=4..20, bars grow upward from the bottom row).
     * Called on the FluidEngine sim thread every tick. Cheap: reads pre-smoothed levels only.
     * Renders nothing when capture is unavailable or the level is below the noise floor.
     */
    fun draw(frame: IntArray) {
        if (!captureOk) {
            Log.d("AV-DIAG", "draw: captureOk=false, skipping")
            return
        }
        val n = MATRIX_SIZE
        val bottom = n - 1
        var pixelsModified = 0
        var maxBrightness = 0
        for (b in bucketLevels.indices) {
            val level = bucketLevels[b]
            if (level <= 0.05f) continue // below visual threshold -> dark
            val barH = (level * MAX_BAR_HEIGHT).coerceAtLeast(1f).coerceAtMost(MAX_BAR_HEIGHT).toInt()
            val x = BAR_X[b]
            val brightness = (255 * level).toInt()
            if (brightness > maxBrightness) maxBrightness = brightness
            // Draw a vertical bar from the bottom up.
            for (y in (bottom - barH + 1)..bottom) {
                if (y >= 0) {
                    frame[y * n + x] = brightness
                    pixelsModified++
                }
            }
        }
        Log.d("AV-DIAG", "draw: captureOk=true pixelsModified=$pixelsModified maxBrightness=$maxBrightness levels=${bucketLevels.joinToString(",") { "%.2f".format(it) }}")
    }

    /** Is capture currently operational? (false => degraded-silent mode.) */
    fun isCaptureOk(): Boolean = captureOk

    /** True if any bucket level exceeds the threshold, indicating audio is present. */
    fun hasAudio(): Boolean {
        for (b in bucketLevels.indices) {
            if (bucketLevels[b] > 0.1f) return true
        }
        return false
    }

    /** Stop capture and release the AudioRecord session. */
    fun release() {
        captureOk = false
        captureHandler?.removeCallbacksAndMessages(null)
        captureThread.quitSafely()
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
    }

    // ------------------------------------------------------------------
    // Log-spaced FFT bin boundaries for 17 buckets.
    // Maps roughly 60 Hz..16 kHz across the available FFT bins.
    // ------------------------------------------------------------------
    private fun computeLogBoundaries(numBuckets: Int): IntArray {
        val nyquist = SAMPLE_RATE / 2f
        val lowFreq = 60f
        val highFreq = min(16000f, nyquist)

        val boundaries = IntArray(numBuckets + 1)
        boundaries[0] = freqToBin(lowFreq, SAMPLE_RATE.toFloat(), FFT_SIZE).coerceAtLeast(1)
        for (b in 1 until numBuckets) {
            val frac = b / numBuckets.toFloat()
            val f = lowFreq * (highFreq / lowFreq).pow(frac)
            boundaries[b] = freqToBin(f, SAMPLE_RATE.toFloat(), FFT_SIZE)
        }
        boundaries[numBuckets] = freqToBin(highFreq, SAMPLE_RATE.toFloat(), FFT_SIZE)
            .coerceAtMost(FFT_SIZE / 2 - 1)
        // Ensure strictly increasing.
        for (b in 0 until numBuckets) {
            if (boundaries[b + 1] <= boundaries[b]) boundaries[b + 1] = boundaries[b] + 1
        }
        return boundaries
    }

    private fun freqToBin(freq: Float, sampleRate: Float, fftSize: Int): Int =
        (freq * fftSize / sampleRate).toInt().coerceIn(0, fftSize / 2)
}
