package dev.glyphfluid

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.HandlerThread
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.atomic.AtomicBoolean

class RemoteSubmixTestActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var btnStartRemix: Button
    private lateinit var btnStartMic: Button
    private lateinit var btnStop: Button

    private var audioRecord: AudioRecord? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: android.os.Handler? = null
    private val capturing = AtomicBoolean(false)

    private val REQUEST_RECORD_AUDIO = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply {
            textSize = 16f
            setPadding(24, 24, 24, 24)
            text = "Audio Source Test\n\nInitializing..."
        }
        btnStartRemix = Button(this).apply {
            text = "Try REMOTE_SUBMIX (no MP)"
            setOnClickListener { tryRemix(MediaRecorder.AudioSource.REMOTE_SUBMIX, "REMOTE_SUBMIX") }
        }
        btnStartMic = Button(this).apply {
            text = "Try MIC (earbuds - won't work)"
            setOnClickListener { tryRemix(MediaRecorder.AudioSource.MIC, "MIC") }
        }
        btnStop = Button(this).apply {
            text = "Stop"
            isEnabled = false
            setOnClickListener { stopRemix() }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.BLACK)
            addView(status)
            addView(btnStartRemix)
            addView(btnStartMic)
            addView(btnStop)
        }
        setContentView(layout)

        log("RECORD_AUDIO: ${checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED}")
        log("REMOTE_SUBMIX value: ${MediaRecorder.AudioSource.REMOTE_SUBMIX}")
        log("MIC value: ${MediaRecorder.AudioSource.MIC}")

        val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        try {
            val policy = am.getAllowedCapturePolicy()
            log("Our app capture policy: $policy (0=ALL, 1=SYSTEM, 2=NONE)")
        } catch (e: Exception) {
            log("getAllowedCapturePolicy failed: ${e.message}")
        }

        // Try REMOTE_SUBMIX automatically on startup
        log("Auto-testing REMOTE_SUBMIX on startup...")
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ tryRemix(MediaRecorder.AudioSource.REMOTE_SUBMIX, "REMOTE_SUBMIX-auto") }, 1500)
    }

    private fun tryRemix(source: Int, label: String) {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQUEST_RECORD_AUDIO); return
        }

        try {
            val sampleRate = 44100
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            log("[$label] Min buffer size: $bufferSize")

            audioRecord = AudioRecord(source, sampleRate, channelConfig, audioFormat, bufferSize * 2)
            log("[$label] AudioRecord state: ${audioRecord!!.state} (${AudioRecord.STATE_INITIALIZED}=init)")

            if (audioRecord!!.state == AudioRecord.STATE_INITIALIZED) {
                audioRecord!!.startRecording()
                log("[$label] Recording STARTED")
                btnStartRemix.isEnabled = false
                btnStartMic.isEnabled = false
                btnStop.isEnabled = true
                capturing.set(true)
                startThread()
            } else {
                log("[$label] AudioRecord FAILED to initialize")
            }
        } catch (e: Exception) {
            log("[$label] FAILED: ${e.message}")
            e.printStackTrace()
        }
    }

    private fun startThread() {
        captureThread = HandlerThread("remix-test").apply { start() }
        captureHandler = android.os.Handler(captureThread!!.looper)
        val buf = ShortArray(1024)
        var reads = 0; var nonZero = 0
        captureHandler!!.post(object : Runnable {
            override fun run() {
                if (!capturing.get()) return
                val read = audioRecord!!.read(buf, 0, buf.size)
                if (0 < read) {
                    reads++
                    var hasNZ = false; var maxA = 0
                    for (i in 0 until read) {
                        val a = Math.abs(buf[i].toInt())
                        if (a != 0) hasNZ = true
                        if (maxA < a) maxA = a
                    }
                    if (hasNZ) nonZero++
                    if (reads % 10 == 0) log("Reads: $reads, NonZero: $nonZero, MaxAmp: $maxA, Last: $read")
                }
                captureHandler!!.postDelayed(this, 50)
            }
        })
    }

    private fun stopRemix() {
        capturing.set(false)
        captureHandler?.removeCallbacksAndMessages(null)
        captureThread?.quitSafely()
        audioRecord?.stop(); audioRecord?.release(); audioRecord = null
        btnStartRemix.isEnabled = true
        btnStartMic.isEnabled = true
        btnStop.isEnabled = false
        log("STOPPED")
    }

    private fun log(msg: String) {
        android.util.Log.d("RemixTest", msg)
        runOnUiThread {
            val current = status.text.toString()
            val updated = current + "\n[$msg]"
            val lines = updated.split("\n")
            val finalText = if (25 < lines.size) lines.drop(lines.size - 25).joinToString("\n") else updated
            status.text = finalText
        }
    }

    override fun onDestroy() { super.onDestroy(); stopRemix() }
}
