package dev.glyphfluid

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var glyph: GlyphController
    private lateinit var engine: FluidEngine
    private lateinit var stateManager: DisplayStateManager
    private lateinit var visualizer: AudioVisualizer
    private lateinit var preview: PreviewView
    private lateinit var status: TextView

    private var projectionManager: MediaProjectionManager? = null
    private var mediaProjection: MediaProjection? = null

    private val REQUEST_MEDIA_PROJECTION = 1001
    private val REQUEST_RECORD_AUDIO = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager?

        // Start foreground service immediately so it's running when getMediaProjection() is called
        Log.d("MainActivity", "Starting foreground service in onCreate() PID: ${Process.myPid()}")
        val fsIntent = Intent(this, MediaProjectionForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            startForegroundService(fsIntent)
        } else {
            startService(fsIntent)
        }
        Log.d("MainActivity", "Foreground service start requested in onCreate()")

        preview = PreviewView(this)
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; setPadding(32, 64, 32, 16)
            text = "Connecting to Glyph Matrix…"
        }
        val toys = Button(this).apply {
            text = "Add as Glyph Toy (runs with the app closed)"
            setOnClickListener {
                try {
                    startActivity(Intent().setComponent(ComponentName(
                        "com.nothing.thirdparty",
                        "com.nothing.thirdparty.matrix.toys.manager.ToysManagerActivity")))
                } catch (e: Exception) {
                    status.text = "Couldn't open Glyph Toys manager: ${e.message}"
                }
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(status)
            addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(toys, LinearLayout.LayoutParams(-1, -2).apply { setMargins(32, 16, 32, 48) })
        })

        glyph = GlyphController(this, appMode = true)
        // Create visualizer without MediaProjection yet (silent mode). Capture starts
        // when the user grants MediaProjection and setMediaProjection() is called.
        visualizer = AudioVisualizer(null)
        stateManager = DisplayStateManager(this, visualizer)
        var tick = 0
        engine = FluidEngine(this, foregroundDrawer = stateManager::drawForeground) { frame ->
            if (tick++ % 2 == 0) glyph.push(frame) // Glyph at ~30 fps
            preview.setFrame(frame)
        }
        // Request audio capture permission at runtime.
        requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQUEST_RECORD_AUDIO)
        // Request MediaProjection consent.
        requestMediaProjection()
    }

    private fun requestMediaProjection() {
        Log.d("MainActivity", "Requesting MediaProjection PID: ${Process.myPid()}")
        try {
            val intent = projectionManager?.createScreenCaptureIntent()
            if (intent == null) {
                Log.e("MainActivity", "createScreenCaptureIntent() returned NULL")
            } else {
                Log.d("MainActivity", "Intent created, launching startActivityForResult...")
                startActivityForResult(intent, REQUEST_MEDIA_PROJECTION)
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "requestMediaProjection FAILED: ${e.message}")
            e.printStackTrace()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            Log.d("MainActivity", "=== ON ACTIVITY RESULT ===")
            Log.d("MainActivity", "PID: ${Process.myPid()}")
            Log.d("MainActivity", "requestCode: $requestCode, resultCode: $resultCode")
            if (resultCode == Activity.RESULT_OK && data != null) {
                Log.d("MainActivity", "MediaProjection granted")
                val mp = projectionManager?.getMediaProjection(resultCode, data)
                mediaProjection = mp
                Log.d("MainActivity", "MediaProjection obtained: ${mp != null}")
                if (mp != null) {
                    Log.d("MainActivity", "MediaProjection class: ${mp.javaClass.name}")
                    // Start audio capture with the MediaProjection token
                    visualizer.setMediaProjection(mp)
                    Log.d("MainActivity", "Visualizer capture started")
                }
            } else {
                Log.d("MainActivity", "MediaProjection DENIED by user")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        glyph.start { ok ->
            runOnUiThread {
                status.text = if (ok) "Glyph Matrix connected" else
                    "Glyph Matrix not connected (is nt_glyph_interface_debug_enable on? see README)"
            }
        }
        engine.start()
        stateManager.start()
        val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        Log.d("MA-DIAG", "onResume: isMusicActive=${am.isMusicActive} captureOk=${visualizer.isCaptureOk()}")
    }

    override fun onPause() {
        super.onPause()
        stateManager.stop()
        engine.stop()
        glyph.stop()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_RECORD_AUDIO && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Log.d("MainActivity", "RECORD_AUDIO granted")
            visualizer.ensureCapture()
        }
    }

    /** On-screen copy of what the matrix shows, handy for debugging. */
    private class PreviewView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        @Volatile private var pixels = IntArray(FluidSim.SIZE * FluidSim.SIZE)

        fun setFrame(f: IntArray) { pixels = f; postInvalidate() }

        override fun onDraw(canvas: Canvas) {
            val n = FluidSim.SIZE
            val cell = minOf(width, height) / n.toFloat()
            val ox = (width - cell * n) / 2f
            val oy = (height - cell * n) / 2f
            val p = pixels
            for (y in 0 until n) for (x in 0 until n) {
                val b = p[y * n + x].coerceIn(0, 255)
                paint.color = Color.rgb(b, b, b)
                canvas.drawCircle(ox + (x + 0.5f) * cell, oy + (y + 0.5f) * cell, cell * 0.38f, paint)
            }
        }
    }
}
