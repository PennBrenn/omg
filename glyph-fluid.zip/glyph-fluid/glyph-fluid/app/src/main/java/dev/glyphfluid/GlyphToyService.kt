package dev.glyphfluid

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.nothing.ketchum.GlyphToy

/**
 * Glyph Toy: the system binds this when the user selects the toy with the Glyph Button, so it runs
 * with the app closed (and with the screen off). Long-press the Glyph Button to re-pour the fluid.
 */
class GlyphToyService : Service() {

    private var glyph: GlyphController? = null
    private var engine: FluidEngine? = null
    private lateinit var stateManager: DisplayStateManager
    private lateinit var visualizer: AudioVisualizer

    private val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            if (msg.what == GlyphToy.MSG_GLYPH_TOY) {
                val event = msg.data.getString(GlyphToy.MSG_GLYPH_TOY_DATA)
                when (event) {
                    GlyphToy.EVENT_CHANGE -> engine?.reset()
                    GlyphToy.EVENT_AOD -> engine?.aodTick()
                }
            } else super.handleMessage(msg)
        }
    }
    private val messenger = Messenger(handler)

    override fun onBind(intent: Intent?): IBinder? {
        val g = GlyphController(this, appMode = false)
        // The system shows toys at a lower brightness than apps, so the fluid needs to be brighter (50%).
        visualizer = AudioVisualizer(null)
        stateManager = DisplayStateManager(this, visualizer)
        var tick = 0
        val e = FluidEngine(
            this,
            fluidLevel = 128,
            foregroundDrawer = stateManager::drawForeground,
        ) { frame ->
            // In AOD mode every frame is the once-a-minute update, so always push it.
            if (engine?.aod == true || tick++ % 2 == 0) g.push(frame)
        }
        glyph = g; engine = e
        g.start()
        e.start()
        stateManager.start()
        return messenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stateManager.stop()
        engine?.stop(); engine = null
        glyph?.stop(); glyph = null
        return false
    }
}
