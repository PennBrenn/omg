package dev.glyphfluid

import java.time.LocalTime

/** 24h "HH:MM" in a 3x5 pixel font in the middle of the matrix. */
object PixelClock {

    /** Clock brightness: 100%, flat over whatever is underneath. */
    private const val CLOCK_LEVEL = 255

    // 3 wide x 5 tall, rows top to bottom, '1' = lit.
    private val GLYPHS = arrayOf(
        "111101101101111", // 0
        "010110010010111", // 1
        "111001111100111", // 2
        "111001111001111", // 3
        "101101111001001", // 4
        "111100111001111", // 5
        "111100111101111", // 6
        "111001001001001", // 7
        "111101111101111", // 8
        "111101111001111", // 9
    )

    fun draw(frame: IntArray, time: LocalTime = LocalTime.now()) {
        val n = FluidSim.SIZE
        val h = time.hour
        val m = time.minute
        // Layout: d d : d d  ->  3+1+3+1+1+1+3+1+3 = 17 wide, 5 tall, centered.
        val x0 = (n - 17) / 2
        val y0 = (n - 5) / 2
        glyph(frame, h / 10, x0, y0)
        glyph(frame, h % 10, x0 + 4, y0)
        set(frame, x0 + 8, y0 + 1)
        set(frame, x0 + 8, y0 + 3)
        glyph(frame, m / 10, x0 + 10, y0)
        glyph(frame, m % 10, x0 + 14, y0)
    }

    private fun glyph(frame: IntArray, digit: Int, x0: Int, y0: Int) {
        val g = GLYPHS[digit]
        for (r in 0 until 5) for (c in 0 until 3) {
            if (g[r * 3 + c] == '1') set(frame, x0 + c, y0 + r)
        }
    }

    private fun set(frame: IntArray, x: Int, y: Int) {
        frame[y * FluidSim.SIZE + x] = CLOCK_LEVEL
    }
}
