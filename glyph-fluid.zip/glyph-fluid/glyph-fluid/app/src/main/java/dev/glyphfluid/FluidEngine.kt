package dev.glyphfluid

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import java.time.LocalTime
import android.util.Log
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Owns the fluid sim, the IMU listeners and the ~60 fps loop. Shared by the activity and the Glyph Toy
 * service. [onFrame] is called on the sim thread with 625 brightness values every tick.
 */
class FluidEngine(
    context: Context,
    /** Fluid pixel brightness 0..255. The toy runs at a lower system brightness than the app, so it uses more. */
    private val fluidLevel: Int = FluidSim.FLUID_LEVEL,
    /** Foreground layer drawn on top of the fluid each tick. Defaults to the existing clock. */
    private val foregroundDrawer: (IntArray) -> Unit = { frame -> PixelClock.draw(frame) },
    private val onFrame: (IntArray) -> Unit,
) : SensorEventListener {

    companion object {
        /** Cells/s^2 per 1 g. Higher = heavier fluid. */
        const val GRAVITY_SCALE = 55f
        /** Multiplier on the fast (non-gravity) part of the accelerometer: the inertia / "yank" response. */
        const val INERTIA_GAIN = 2.5f
        /** Centrifugal / Euler / Coriolis strength from the gyro. 0 disables. */
        const val FI_GAIN = 0.1f
        /** Matrix is viewed from the back, so device-x is mirrored. Flip if the fluid moves the wrong way. */
        const val FLIP_X = false
        const val FLIP_Y = false
        /** Experiment: if true, AOD events are ignored and the live sim keeps running with the screen off. */
        const val AOD_KEEP_RUNNING = true
        private const val GRAVITY_TAU = 0.3f   // seconds: how slowly "gravity" is tracked vs. shakes
    }

    private val appContext = context.applicationContext
    private val sensors = appContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sim = FluidSim()
    private val frame = IntArray(FluidSim.SIZE * FluidSim.SIZE)

    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    // All fields below are only touched on the sim thread.
    private var sumX = 0f; private var sumY = 0f; private var n = 0
    private var tickCounter = 0
    private var lastX = 0f; private var lastY = 0f
    private var lowX = 0f; private var lowY = 0f; private var lowInit = false
    private var wz = 0f; private var alphaZ = 0f; private var lastGyroNs = 0L
    private var lastNs = 0L

    private val loop = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtimeNanos()
            val dt = ((now - lastNs) / 1e9f).coerceIn(0.001f, 0.033f)
            lastNs = now

            // Average every accelerometer sample since the last tick so a short yank is never missed.
            val ax: Float
            val ay: Float
            if (n > 0) { ax = sumX / n; ay = sumY / n; lastX = ax; lastY = ay } else { ax = lastX; ay = lastY }
            sumX = 0f; sumY = 0f; n = 0

            // The accelerometer is gravity-reaction minus the phone's own acceleration, i.e. exactly the
            // effective gravity inside the phone's frame. Split it into slow (gravity) and fast (inertia)
            // parts so the fast part can be exaggerated.
            if (!lowInit) { lowX = ax; lowY = ay; lowInit = true }
            val k = (dt / GRAVITY_TAU).coerceAtMost(1f)
            lowX += k * (ax - lowX)
            lowY += k * (ay - lowY)
            val ex = lowX + INERTIA_GAIN * (ax - lowX)
            val ey = lowY + INERTIA_GAIN * (ay - lowY)

            // Axes: cols mirrored (viewing from the back), rows grow downward -> fall direction is (+x, +y).
            var gx = ex / SensorManager.GRAVITY_EARTH * GRAVITY_SCALE
            var gy = ey / SensorManager.GRAVITY_EARTH * GRAVITY_SCALE
            if (FLIP_X) gx = -gx
            if (FLIP_Y) gy = -gy
            val mag = sqrt(gx * gx + gy * gy)
            val maxMag = GRAVITY_SCALE * 7f
            if (mag > maxMag) { gx *= maxMag / mag; gy *= maxMag / mag }

            sim.step(dt, gx, gy, wz, alphaZ, FI_GAIN)
            sim.render(frame, fluidLevel)
            foregroundDrawer(frame)
            // Frame analysis diagnostics
            var nonZeroPixels = 0
            var maxBrightness = 0
            for (i in frame.indices) {
                if (frame[i] > 0) {
                    nonZeroPixels++
                    if (frame[i] > maxBrightness) maxBrightness = frame[i]
                }
            }
            if (tickCounter++ % 60 == 0) {
                Log.d("FE-DIAG", "Frame: nonZeroPixels=$nonZeroPixels maxBrightness=$maxBrightness totalPixels=${frame.size}")
            }
            onFrame(frame)

            handler?.postDelayed(this, 16)
        }
    }

    fun start() {
        if (thread != null) return
        val t = HandlerThread("fluid-sim").also { it.start() }
        val h = Handler(t.looper)
        thread = t; handler = h
        lowInit = false; lastGyroNs = 0L; wz = 0f; alphaZ = 0f
        val periodUs = 5000 // 200 Hz, the cap without HIGH_SAMPLING_RATE_SENSORS
        sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensors.registerListener(this, it, periodUs, h)
        }
        sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let {
            sensors.registerListener(this, it, periodUs, h)
        }
        lastNs = SystemClock.elapsedRealtimeNanos()
        h.post(loop)
    }

    fun stop() {
        sensors.unregisterListener(this)
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        thread = null; handler = null
    }

    /** Re-pour the fluid at the bottom. */
    fun reset() { handler?.post { sim.reset(FluidSim.DEFAULT_COUNT) } }

    /** True once we've switched to always-on mode (one static frame per EVENT_AOD, no sim loop/sensors). */
    @Volatile var aod = false
        private set

    /**
     * Called on each EVENT_AOD (once a minute). The first call stops the 60 fps loop and the sensors,
     * lets the fluid settle into a puddle under the last known gravity, then every call redraws the
     * frame with the current time.
     */
    fun aodTick() {
        if (AOD_KEEP_RUNNING) return // the live loop is already drawing
        handler?.post {
            if (!aod) {
                aod = true
                handler?.removeCallbacks(loop)
                sensors.unregisterListener(this)
                var gx = 0f
                var gy = GRAVITY_SCALE // default: fall toward the bottom
                if (lowInit) {
                    gx = lowX / SensorManager.GRAVITY_EARTH * GRAVITY_SCALE
                    gy = lowY / SensorManager.GRAVITY_EARTH * GRAVITY_SCALE
                    if (FLIP_X) gx = -gx
                    if (FLIP_Y) gy = -gy
                }
                repeat(180) { sim.step(1f / 60f, gx, gy) }
            }
            sim.render(frame, fluidLevel)
            PixelClock.draw(frame, LocalTime.now())
            onFrame(frame)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_GYROSCOPE) {
            var w = e.values[2]
            if (abs(w) < 0.05f) w = 0f // deadzone for gyro bias
            w = w.coerceIn(-15f, 15f)
            if (lastGyroNs != 0L) {
                val dt = (e.timestamp - lastGyroNs) / 1e9f
                if (dt > 0f) {
                    val raw = ((w - wz) / dt).coerceIn(-200f, 200f)
                    alphaZ += 0.2f * (raw - alphaZ)
                }
            }
            lastGyroNs = e.timestamp
            wz = w
        } else {
            sumX += e.values[0]; sumY += e.values[1]; n++
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
