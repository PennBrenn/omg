package dev.glyphfluid

import android.app.Service
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log

class MediaProjectionForegroundService : Service() {

    override fun onCreate() {
        super.onCreate()
        Log.d("APCTest", "MediaProjectionForegroundService onCreate PID: ${android.os.Process.myPid()}")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "apc_channel",
                "AudioPlaybackCapture Test",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("APCTest", "MediaProjectionForegroundService onStartCommand PID: ${android.os.Process.myPid()}")
        startForeground(1, android.app.Notification.Builder(this, "apc_channel")
            .setContentTitle("AudioPlaybackCapture Test")
            .setContentText("Capturing system audio")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build())
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("APCTest", "MediaProjectionForegroundService onDestroy PID: ${android.os.Process.myPid()}")
        stopForeground(true)
    }
}
