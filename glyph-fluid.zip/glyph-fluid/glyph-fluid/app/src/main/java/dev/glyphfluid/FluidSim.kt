package dev.glyphfluid

import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Small position-based particle fluid inside a circular container on a SIZE x SIZE grid.
 * Units are matrix cells; gravity is passed in cells/s^2 each step.
 * The number of active particles ([count]) can change at runtime (see [setFill]).
 */
class FluidSim {

    companion object {
        const val SIZE = 25
        /** Particle count that fills the container (100%). */
        const val CAPACITY = 320
        private const val REST = 1.25f        // preferred particle spacing
        private const val SUBSTEPS = 2
        private const val ITERATIONS = 3
        private const val MAX_SPEED = 50f
        private const val VISCOSITY = 0.03f
        private const val SPLAT_R = 1.7f

        /** Particle count of the fluid. */
        const val DEFAULT_COUNT = 120
        /** Single fluid brightness (25%) for any pixel with enough fluid in it. */
        const val FLUID_LEVEL = 64
        private const val THRESHOLD = 0.2f
    }

    private val c = (SIZE - 1) / 2f
    private val wallR = SIZE / 2f - 0.6f

    var count = 0
        private set

    private val px = FloatArray(CAPACITY)
    private val py = FloatArray(CAPACITY)
    private val vx = FloatArray(CAPACITY)
    private val vy = FloatArray(CAPACITY)
    private val ox = FloatArray(CAPACITY)
    private val oy = FloatArray(CAPACITY)
    private val density = FloatArray(SIZE * SIZE)
    private val rnd = Random(1)

    init { reset(DEFAULT_COUNT) }

    /** Re-pour n particles at the bottom of the circle (row index grows downward). */
    fun reset(n: Int = count) {
        val target = n.coerceIn(0, CAPACITY)
        var placed = 0
        var y = c + wallR - 0.5f
        var row = 0
        while (placed < target && y > c - wallR) {
            var x = c - wallR + (if (row % 2 == 0) 0f else REST / 2)
            while (placed < target && x < c + wallR) {
                val dx = x - c
                val dy = y - c
                if (dx * dx + dy * dy < (wallR - 0.5f) * (wallR - 0.5f)) {
                    px[placed] = x + rnd.nextFloat() * 0.1f
                    py[placed] = y + rnd.nextFloat() * 0.1f
                    vx[placed] = 0f; vy[placed] = 0f
                    placed++
                }
                x += REST
            }
            y -= REST * 0.87f
            row++
        }
        count = placed
        while (count < target) spawnOne()
    }

    /** Grow or shrink to n particles without disturbing the rest. */
    fun setFill(n: Int) {
        val target = n.coerceIn(0, CAPACITY)
        while (count < target) spawnOne()
        if (count > target) count = target
    }

    /** Add a particle at the emptiest of a few random spots inside the container. */
    private fun spawnOne() {
        if (count >= CAPACITY) return
        var bestX = c
        var bestY = c
        var bestD = -1f
        repeat(16) {
            val a = rnd.nextFloat() * 6.2831855f
            val r = sqrt(rnd.nextFloat()) * (wallR - 0.6f)
            val x = c + r * kotlin.math.cos(a)
            val y = c + r * kotlin.math.sin(a)
            var minD = Float.MAX_VALUE
            for (j in 0 until count) {
                val dx = px[j] - x
                val dy = py[j] - y
                val d = dx * dx + dy * dy
                if (d < minD) minD = d
            }
            if (minD > bestD) { bestD = minD; bestX = x; bestY = y }
        }
        px[count] = bestX; py[count] = bestY
        vx[count] = 0f; vy[count] = 0f
        count++
    }

    /**
     * Advance by dt seconds. gx/gy: effective gravity in cells/s^2 (x = columns, y = rows, +y = down).
     * w / alpha: angular velocity and acceleration about the screen normal; fiGain scales the
     * resulting centrifugal / Euler / Coriolis forces.
     */
    fun step(dt: Float, gx: Float, gy: Float, w: Float = 0f, alpha: Float = 0f, fiGain: Float = 0f) {
        val h = dt / SUBSTEPS
        val w2 = w * w
        repeat(SUBSTEPS) {
            for (i in 0 until count) {
                val rx = px[i] - c
                val ry = py[i] - c
                val fx = w2 * rx + alpha * ry + 2f * w * vy[i]
                val fy = w2 * ry - alpha * rx - 2f * w * vx[i]
                vx[i] += (gx + fx * fiGain) * h
                vy[i] += (gy + fy * fiGain) * h
                ox[i] = px[i]; oy[i] = py[i]
                px[i] += vx[i] * h
                py[i] += vy[i] * h
            }
            repeat(ITERATIONS) {
                solvePairs()
                solveWalls()
            }
            for (i in 0 until count) {
                var nvx = (px[i] - ox[i]) / h
                var nvy = (py[i] - oy[i]) / h
                val sp = sqrt(nvx * nvx + nvy * nvy)
                if (sp > MAX_SPEED) {
                    val k = MAX_SPEED / sp
                    nvx *= k; nvy *= k
                }
                vx[i] = nvx * 0.9995f
                vy[i] = nvy * 0.9995f
            }
            applyViscosity()
        }
    }

    private fun solvePairs() {
        for (i in 0 until count) {
            for (j in i + 1 until count) {
                val dx = px[j] - px[i]
                val dy = py[j] - py[i]
                val d2 = dx * dx + dy * dy
                if (d2 >= REST * REST || d2 < 1e-8f) continue
                val d = sqrt(d2)
                val push = (REST - d) * 0.5f * 0.9f / d
                px[i] -= dx * push; py[i] -= dy * push
                px[j] += dx * push; py[j] += dy * push
            }
        }
    }

    private fun solveWalls() {
        for (i in 0 until count) {
            val dx = px[i] - c
            val dy = py[i] - c
            val r2 = dx * dx + dy * dy
            if (r2 > wallR * wallR) {
                val k = wallR / sqrt(r2)
                px[i] = c + dx * k
                py[i] = c + dy * k
            }
        }
    }

    private fun applyViscosity() {
        for (i in 0 until count) {
            for (j in i + 1 until count) {
                val dx = px[j] - px[i]
                val dy = py[j] - py[i]
                if (dx * dx + dy * dy >= 1.6f * 1.6f) continue
                val dvx = (vx[j] - vx[i]) * VISCOSITY
                val dvy = (vy[j] - vy[i]) * VISCOSITY
                vx[i] += dvx; vy[i] += dvy
                vx[j] -= dvx; vy[j] -= dvy
            }
        }
    }

    /** Render to SIZE*SIZE brightness values, row-major: 0 or FLUID_LEVEL (25%). */
    fun render(out: IntArray, fluidLevel: Int = FLUID_LEVEL) {
        density.fill(0f)
        for (i in 0 until count) {
            val x0 = (px[i] - SPLAT_R).toInt().coerceAtLeast(0)
            val x1 = (px[i] + SPLAT_R).toInt().coerceAtMost(SIZE - 1)
            val y0 = (py[i] - SPLAT_R).toInt().coerceAtLeast(0)
            val y1 = (py[i] + SPLAT_R).toInt().coerceAtMost(SIZE - 1)
            for (yy in y0..y1) for (xx in x0..x1) {
                val dx = xx - px[i]
                val dy = yy - py[i]
                val t = 1f - (dx * dx + dy * dy) / (SPLAT_R * SPLAT_R)
                if (t > 0f) density[yy * SIZE + xx] += t * t
            }
        }
        val maskR = SIZE / 2f + 0.2f
        for (yy in 0 until SIZE) for (xx in 0 until SIZE) {
            val dx = xx - c
            val dy = yy - c
            val idx = yy * SIZE + xx
            if (dx * dx + dy * dy > maskR * maskR) { out[idx] = 0; continue }
            out[idx] = if (density[idx] >= THRESHOLD) fluidLevel else 0
        }
    }
}
