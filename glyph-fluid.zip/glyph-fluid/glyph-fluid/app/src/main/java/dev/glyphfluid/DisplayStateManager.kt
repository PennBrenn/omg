package dev.glyphfluid

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.util.Log

/**
 * Selects which foreground layer is drawn on top of the persistent fluid simulation.
 *
 * Priority (high to low): volume percentage > music visualizer > clock.
 *
 * State transitions are self-correcting: [drawForeground] is evaluated every frame, so a stale
 * timeout can never leave a volume display "stuck on" — it is evaluated on the sim thread each
 * tick, not via a deferred restore that could race with the fluid loop.
 *
 * Music-active polling runs on the main thread via AudioManager.isMusicActive(); volume changes
 * arrive on the main thread via a context-registered ACTION_VOLUME_CHANGED receiver. Both write
 * @Volatile fields read by drawForeground on the sim thread — no locks needed.
 *
 * NOTE: Audio capture (Visualizer) is deliberately NOT owned here. It is owned by
 * [AudioVisualizer] (Stage 2) and referenced only via [visualizer]. This class never initializes
 * or releases audio hardware, keeping the fluid sim thread free of audio operations.
 */
class DisplayStateManager(
    context: Context,
    private val visualizer: AudioVisualizer?,
) {

    private val ctx = context.applicationContext
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    enum class Mode { CLOCK, VOLUME, MUSIC }

    /** The currently selected foreground layer, evaluated fresh every frame in drawForeground. */
    @Volatile var mode: Mode = Mode.CLOCK
        private set

    /** Last reported STREAM_MUSIC volume percentage (0-100). */
    @Volatile var volumePercent: Int = 0
        private set

    /** True when system music playback is reported active. */
    @Volatile var musicPlaying: Boolean = false
        private set

    @Volatile private var volumeWindowCloseMs: Long = 0L

    private val volumeReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: android.content.Intent?) {
            val action = intent?.action
            if (action != "android.media.VOLUME_CHANGED_ACTION") return
            val stream = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
            if (stream != AudioManager.STREAM_MUSIC) return
            val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            volumePercent = if (max > 0) (cur * 100 / max) else 0
            volumeWindowCloseMs = System.currentTimeMillis() + VOLUME_WINDOW_MS
            mode = Mode.VOLUME
            visualizer?.release() // hide visualizer while volume window is open
            scheduleMusicPoll()
        }
    }

    private val volumeFilter = android.content.IntentFilter("android.media.VOLUME_CHANGED_ACTION")

    private val musicPollHandler = Handler(Looper.getMainLooper())

    private fun scheduleMusicPoll() {
        musicPollHandler.removeCallbacksAndMessages(null)
        musicPollHandler.postDelayed(object : Runnable {
            override fun run() {
            // Use PCM data from the visualizer rather than AudioManager.isMusicActive(),
            // which can be unreliable on some devices (e.g., Nothing OS).
            musicPlaying = visualizer?.hasAudio() == true
            Log.d("DSM-DIAG", "isMusicActive=${musicPlaying} mode=${mode} volumeWindowCloseMs=$volumeWindowCloseMs nowMs=${System.currentTimeMillis()}")
            scheduleMusicPoll()
        }
        }, MUSIC_POLL_MS)
    }

    companion object {
        private const val VOLUME_WINDOW_MS = 2000L
        private const val MUSIC_POLL_MS = 500L
    }

    init {
        // Seed initial volume so the percentage is correct from the first frame.
        volumePercent = currentVolumePercent()
        // Receiver registration and music polling are deferred to start() so they are tied to the
        // host's foreground lifecycle and never leak.
    }

    /** Call once when the host enters the foreground (Activity.onResume / Service.onBind). */
    fun start() {
        ctx.registerReceiver(volumeReceiver, volumeFilter, android.content.Context.RECEIVER_NOT_EXPORTED)
        scheduleMusicPoll()
        // Begin audio capture (best-effort; silent if Visualizer(0) unavailable or permission denied).
        visualizer?.ensureCapture()
        visualizer?.start()
    }

    /** Call once when the host stops. Stops music polling and unregisters receiver.
     * Does NOT release the visualizer - the visualizer manages its own lifecycle
     * and needs to stay alive across pause/resume cycles (e.g., when the
     * MediaPermission dialog appears and dismisses).
     */
    fun stop() {
        musicPollHandler.removeCallbacksAndMessages(null)
        ctx.unregisterReceiver(volumeReceiver)
        // Note: visualizer.release() is NOT called here. The visualizer owns its
        // AudioRecorder and capture thread and manages their lifecycle independently.
        // Releasing here would kill the capture thread just as the user grants
        // MediaPermission, preventing audio capture from ever working.
    }

    private fun currentVolumePercent(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max > 0) {
            val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            cur * 100 / max
        } else 0
    }

    /**
     * Evaluate the foreground layer for the current frame. Called from FluidEngine's sim thread
     * every tick; does not touch audio hardware, only reads @Volatile state and draws into frame.
     */
    fun drawForeground(frame: IntArray) {
        val nowMs = System.currentTimeMillis()
        if (nowMs < volumeWindowCloseMs) {
            mode = Mode.VOLUME
            Log.d("DSM-DIAG", "drawForeground: MODE=VOLUME (window open, remainingMs=${volumeWindowCloseMs - nowMs})")
            PixelVolume.draw(frame, volumePercent)
            return
        }
        if (musicPlaying) {
            mode = Mode.MUSIC
            Log.d("DSM-DIAG", "drawForeground: MODE=MUSIC (musicPlaying=true)")
            visualizer?.draw(frame)
            return
        }
        mode = Mode.CLOCK
        Log.d("DSM-DIAG", "drawForeground: MODE=CLOCK (no music, no volume window)")
        PixelClock.draw(frame)
    }

    /** Current mode, exposed for debugging/preview mirroring. */
    fun currentMode(): Mode = mode
}